CREATE package body slvw_partition as
function handle_table (i_table_name VARCHAR2,i_end_date DATE,i_part_type VARCHAR2,i_data_type VARCHAR2,i_lenth NUMBER default 0) return PLS_INTEGER;
function init_table (i_table_name VARCHAR2,i_end_date DATE,i_part_type VARCHAR2,i_data_type VARCHAR2,i_lenth NUMBER default 0) return PLS_INTEGER;
function handle_table (i_table_name VARCHAR2,i_end_date DATE,i_part_type VARCHAR2,i_data_type VARCHAR2,i_lenth NUMBER default 0) return PLS_INTEGER as
l_part_date date;
l_part_name varchar2(30);
l_high_value varchar2(50);
l_stmt varchar2(500);
l_day number;

l_err_string varchar2(500);
l_partition_error EXCEPTION;
begin
l_stmt := '???????????' ;
/*???????????*/
select max(partition_name) into l_part_name
from user_tab_partitions
where table_name = i_table_name ;

if (l_part_name is null) then
l_stmt := '?????' ;
raise l_partition_error ;
end if;

l_stmt := '????' || l_part_name ;
/*????????????????????P_yyyymmdd*/
select to_date(substr(l_part_name,3),'yyyymmdd') into l_part_date from dual;

while l_part_date < i_end_date loop
/*????????????????*/
l_stmt := '?????' || i_part_type ;
/*????*/
if (i_part_type = 'YEAR') then
l_part_date := to_date(to_char(l_part_date+1,'yyyy') || '1231','yyyymmdd') ;
/*????*/
elsif (i_part_type = 'MONTH') then
l_part_date := last_day(l_part_date+1) ;
/*?????*/
elsif (i_part_type = 'HALFMONTH') then
l_day := to_number(to_char(l_part_date+1,'DD'));
if (l_day<=15) then
l_part_date := l_part_date + (15 - l_day) + 1 ;
else
l_part_date := last_day(l_part_date+1) ;
end if;
/*????*/
elsif (i_part_type = 'TENDAYS') then
l_day := to_number(to_char(l_part_date+1,'DD'));
if (l_day<=10) then
l_part_date := l_part_date + (10 - l_day) + 1 ;
elsif (l_day<=20) then
l_part_date := l_part_date + (20 - l_day) + 1 ;
else
l_part_date := last_day(l_part_date+1) ;
end if;
/*????*/
elsif (i_part_type = 'WEEK') then
l_day := to_number(to_char(l_part_date+1,'D'));
l_part_date := l_part_date + (7 - l_day) + 1 ;
/*????*/
elsif (i_part_type = 'DAY') then
l_part_date := l_part_date + 1 ;
else
raise l_partition_error ;
end if;

l_part_name := 'P_'||to_char(l_part_date,'yyyymmdd') ;

/*?????????????*/
l_stmt := '???????' || i_data_type ;
/*???*/
if (i_data_type = 'CHAR' or i_data_type like 'VARCHAR%') then
l_high_value := '''' || substr(to_char(l_part_date+1,'yyyymmdd'),1,i_lenth) || '''';
elsif (i_data_type = 'DATE') then
l_high_value := 'to_date(''' || to_char(l_part_date+1,'yyyymmdd') || ''',''yyyymmdd'')' ;
else
raise l_partition_error ;
end if;

/*???????*/
l_stmt := 'alter table ' || i_table_name || ' add partition ' || l_part_name || ' values less than ('|| l_high_value || ')';

execute immediate l_stmt ;
insert into partitionoperlog(table_name,partition_name,oper_type,oper_detail,log_time)
values (i_table_name,l_part_name,'ADD',l_stmt,sysdate);
commit;
end loop;
return 1;
exception
when others then
l_err_string := '??????->' || l_stmt || '->' || substrb(sqlerrm,1,100) ;
insert into partitionerrorlog(table_name,error_detail,log_time)
values(i_table_name,l_err_string,sysdate) ;
commit;
return 0;
end;
function init_table (i_table_name VARCHAR2,i_end_date DATE,i_part_type VARCHAR2,i_data_type VARCHAR2,i_lenth NUMBER default 0) return PLS_INTEGER as
l_old_part_date date;
l_new_part_date date;
l_old_part_name varchar2(30);
l_new_part_name varchar2(30);
l_old_high_value varchar2(50);
l_new_high_value varchar2(50);
l_stmt varchar2(500);
l_day number;

l_err_string varchar2(500);
l_partition_error exception;
begin

/*?????????*/
l_stmt := 'select 1 from dual where not exists (select * from ' || i_table_name || ' where rownum = 1)';
execute immediate l_stmt ;

l_stmt := '?????????' ;
/*?????????*/
select partition_name into l_old_part_name
from user_tab_partitions
where table_name = i_table_name ;

l_stmt := '????' || l_old_part_name ;
/*????????????????????P_yyyymmdd*/
select to_date(substr(l_old_part_name,3),'yyyymmdd') into l_old_part_date from dual;

l_new_part_date := i_end_date;
/*??????????????*/
l_stmt := '?????' || i_part_type ;
/*????*/
if (i_part_type = 'YEAR') then
l_new_part_date := to_date(to_char(l_new_part_date,'yyyy') || '1231','yyyymmdd') ;
/*????*/
elsif (i_part_type = 'MONTH') then
l_new_part_date := last_day(l_new_part_date) ;
/*?????*/
elsif (i_part_type = 'HALFMONTH') then
l_day := to_number(to_char(l_new_part_date,'DD'));
if (l_day<=15) then
l_new_part_date := l_new_part_date + (15 - l_day) ;
else
l_new_part_date := last_day(l_new_part_date) ;
end if;
/*????*/
elsif (i_part_type = 'TENDAYS') then
l_day := to_number(to_char(l_new_part_date,'DD'));
if (l_day<=10) then
l_new_part_date := l_new_part_date + (10 - l_day) ;
elsif (l_day<=20) then
l_new_part_date := l_new_part_date + (20 - l_day) ;
else
l_new_part_date := last_day(l_new_part_date) ;
end if;
/*????*/
elsif (i_part_type = 'WEEK') then
l_day := to_number(to_char(l_new_part_date,'D'));
l_new_part_date := l_new_part_date + (7 - l_day) ;
/*????*/
elsif (i_part_type = 'DAY') then
l_new_part_date := l_new_part_date ;
else
raise l_partition_error ;
end if;

l_new_part_name := 'P_'||to_char(l_new_part_date,'yyyymmdd') ;

/*?????????????*/
l_stmt := '???????' || i_data_type ;
/*???*/
if (i_data_type = 'CHAR'or i_data_type like 'VARCHAR%') then
l_new_high_value := '''' || substr(to_char(l_new_part_date+1,'yyyymmdd'),1,i_lenth) || '''';
l_old_high_value := '''' || substr(to_char(l_old_part_date+1,'yyyymmdd'),1,i_lenth) || '''';
elsif (i_data_type = 'DATE') then
l_new_high_value := 'to_date(''' || to_char(l_new_part_date+1,'yyyymmdd') || ''',''yyyymmdd'')' ;
l_old_high_value := 'to_date(''' || to_char(l_old_part_date+1,'yyyymmdd') || ''',''yyyymmdd'')' ;
else
raise l_partition_error ;
end if;

/*??????????????????????????*/
if l_old_high_value < l_new_high_value then
l_stmt := 'alter table ' || i_table_name || ' add partition ' || l_new_part_name || ' values less than ('|| l_new_high_value || ')';
execute immediate l_stmt ;
insert into partitionoperlog(table_name,partition_name,oper_type,oper_detail,log_time)
values (i_table_name,l_new_part_name,'ADD',l_stmt,sysdate);
commit;

l_stmt := 'alter table ' || i_table_name || ' drop partition ' || l_old_part_name ;
execute immediate l_stmt ;
insert into partitionoperlog(table_name,partition_name,oper_type,oper_detail,log_time)
values (i_table_name,l_old_part_name,'DROP',l_stmt,sysdate);
commit;
/*??????????????????????????*/
elsif l_old_high_value > l_new_high_value then
l_stmt := 'alter table ' || i_table_name || ' split partition ' || l_old_part_name
|| ' at ('|| l_new_high_value || ') into (partition ' || l_new_part_name
|| ',partition ' || l_old_part_name || ')';
execute immediate l_stmt ;
insert into partitionoperlog(table_name,partition_name,oper_type,oper_detail,log_time)
values (i_table_name,l_old_part_name,'SPLIT',l_stmt,sysdate);
commit;

l_stmt := 'alter table ' || i_table_name || ' drop partition ' || l_old_part_name ;
execute immediate l_stmt ;
insert into partitionoperlog(table_name,partition_name,oper_type,oper_detail,log_time)
values (i_table_name,l_old_part_name,'DROP',l_stmt,sysdate);
commit;

l_stmt := 'alter table ' || i_table_name || ' modify partition ' || l_new_part_name || ' rebuild unusable local indexes';
execute immediate l_stmt ;
insert into partitionoperlog(table_name,partition_name,oper_type,oper_detail,log_time)
values (i_table_name,l_new_part_name,'REINDEX',l_stmt,sysdate);
commit;
end if;
return 1;
exception
when others then
l_err_string := '???????->' || l_stmt || '->' || substrb(sqlerrm,1,100) ;
insert into partitionerrorlog(table_name,error_detail,log_time)
values(i_table_name,l_err_string,sysdate) ;
commit;
return 0;
end;
procedure add_partition (i_end_date DATE,i_tname VARCHAR2 default 'ALL') as
BEGIN
add_partition(to_char(i_end_date,'yyyymmdd'),i_tname) ;
END;
procedure init_partition (i_end_date VARCHAR2,i_tname VARCHAR2 default 'ALL') as
l_result pls_integer;
l_ret_value pls_integer;
l_end_date date;
l_data_type user_tab_columns.data_type%type;
l_data_length user_tab_columns.data_length%type;

l_err_string varchar2(200);
l_date_error EXCEPTION;

BEGIN
/*?????????*/
BEGIN
/*????????*/
if i_end_date is null then
raise l_date_error ;
end if ;

/*???????????????*/
l_end_date := to_date(i_end_date,'yyyymmdd');
EXCEPTION
WHEN OTHERS THEN
l_err_string := '?????????(YYYYMMDD)->' || i_end_date ;
insert into partitionerrorlog(table_name,error_detail,log_time)
values('PROC-ADDPARTITION',l_err_string,sysdate) ;
commit;
raise_application_error(-20100, l_err_string) ;
END ;

l_result := 0;

/*????????????*/
for l_rec in (select b.table_name,nvl(a.partitiontype,'MONTH') partitiontype
from partitioncleancfg a,user_part_tables b
where b.table_name = a.table_name (+)
and (i_tname = 'ALL' or b.table_name = upper(i_tname))
and b.partitioning_type <> 'LIST') loop
begin
/*????????*/
select a.data_type,a.data_length
into l_data_type,l_data_length
from user_tab_columns a,user_part_key_columns b
where a.table_name = b.name
and a.table_name = l_rec.table_name
and a.column_name = b.column_name;

/*????*/
l_ret_value := init_table(l_rec.table_name,l_end_date,l_rec.partitiontype,l_data_type,l_data_length);
if (l_ret_value <> 1) then
l_result := 1;
end if;
EXCEPTION
WHEN OTHERS THEN
l_err_string := '???????->' || substrb(sqlerrm,1,100) ;
insert into partitionerrorlog(table_name,error_detail,log_time)
values(l_rec.table_name,l_err_string,sysdate) ;
commit;
l_result := 1;
END ;
end loop;


if (l_result != 0) then
raise_application_error(-20100, '??????????') ;
else
insert into partitionerrorlog(table_name,error_detail,log_time)
values('PROC-INITPARTITION','???????->'||i_end_date||'->'||i_tname,sysdate) ;
commit;
end if;

END;
procedure trunc_partition (i_end_date DATE,i_tname VARCHAR2 default 'ALL') as
BEGIN
trunc_partition(to_char(i_end_date,'yyyymmdd'),i_tname) ;
END;
procedure trunc_partition (i_end_date VARCHAR2,i_tname VARCHAR2 default 'ALL') as
l_result pls_integer;
l_part_exist pls_integer;
l_end_date date;

l_err_string varchar2(500);
l_date_error EXCEPTION;

l_stmt varchar2(500);

BEGIN
/*?????????*/
BEGIN
/*????????*/
if i_end_date is null then
raise l_date_error ;
end if ;

/*???????????????*/
l_end_date := to_date(i_end_date,'yyyymmdd');

/*??????????????*/
if (l_end_date > sysdate) then
raise l_date_error ;
end if ;

EXCEPTION
WHEN OTHERS THEN
l_err_string := '??????(YYYYMMDD)->' || i_end_date ;
insert into partitionerrorlog(table_name,error_detail,log_time)
values('PROC-TRUNCPARTITION',l_err_string,sysdate) ;
commit;
raise_application_error(-20100, l_err_string) ;
END ;

/*?????*/
l_result := 0;
for l_rec in (select upper(a.table_name) table_name,'P_'||to_char(l_end_date - a.holddays,'yyyymmdd') partition_name
from partitioncleancfg a
where (holddays > 0) and (i_tname = 'ALL' or upper(a.table_name) = upper(i_tname))) loop
begin
l_stmt := '????->'||l_rec.table_name||'->'||l_rec.partition_name ;
/*????????*/
begin
l_part_exist := 0 ;
select 1 into l_part_exist
from dual
where exists (select partition_name from user_tab_partitions
where table_name = l_rec.table_name
and partition_name = l_rec.partition_name) ;
exception
when no_data_found then
l_part_exist := 0;
end ;

/*??????TRUNCATE???*/
if (l_part_exist=1) then
l_stmt := 'alter table ' || l_rec.table_name || ' truncate partition ' || l_rec.partition_name ;
execute immediate l_stmt ;
insert into partitionoperlog(table_name,partition_name,oper_type,oper_detail,log_time)
values (l_rec.table_name,l_rec.partition_name ,'TRUNC',l_stmt,sysdate);
commit;
end if;
exception
when others then
l_err_string := '??????->' || l_stmt || '->' || substrb(sqlerrm,1,100) ;
insert into partitionerrorlog(table_name,error_detail,log_time)
values(l_rec.table_name,l_err_string,sysdate) ;
commit;
l_result := 1;
end;
end loop;

if (l_result != 0) then
raise_application_error(-20100, '?????????') ;
else
insert into partitionerrorlog(table_name,error_detail,log_time)
values('PROC-TRUNCPARTITION','??????->'||i_end_date||'->'||i_tname,sysdate) ;
commit;
end if;

END;
procedure drop_partition (i_end_date DATE,i_tname VARCHAR2 default 'ALL') as
BEGIN
drop_partition(to_char(i_end_date,'yyyymmdd'),i_tname) ;
END;
procedure drop_partition (i_end_date VARCHAR2,i_tname VARCHAR2 default 'ALL') as
l_result pls_integer;
l_part_exist pls_integer;
l_end_date date;

l_err_string varchar2(500);
l_date_error EXCEPTION;

l_stmt varchar2(500);

BEGIN
/*?????????*/
BEGIN
/*????????*/
if i_end_date is null then
raise l_date_error ;
end if ;

/*???????????????*/
l_end_date := to_date(i_end_date,'yyyymmdd');

/*??????????????*/
if (l_end_date > sysdate) then
raise l_date_error ;
end if ;
EXCEPTION
WHEN OTHERS THEN
l_err_string := '??????(YYYYMMDD)->' || i_end_date ;
insert into partitionerrorlog(table_name,error_detail,log_time)
values('PROC-DROPPARTITION',l_err_string,sysdate) ;
commit;
raise_application_error(-20100, l_err_string) ;
END ;

/*?????*/
l_result := 0;
for l_rec in (select upper(a.table_name) table_name,'P_'||to_char(l_end_date - a.holddays,'yyyymmdd') partition_name
from partitioncleancfg a
where (holddays > 0) and (i_tname = 'ALL' or upper(a.table_name) = upper(i_tname))) loop
begin
l_stmt := '????->'||l_rec.table_name||'->'||l_rec.partition_name ;
/*????????*/
begin
l_part_exist := 0 ;
select 1 into l_part_exist
from dual
where exists (select partition_name from user_tab_partitions
where table_name = l_rec.table_name
and partition_name = l_rec.partition_name) ;
exception
when no_data_found then
l_part_exist := 0;
end ;

/*??????DROP???*/
if (l_part_exist=1) then
l_stmt := 'alter table ' || l_rec.table_name || ' drop partition ' || l_rec.partition_name ;
execute immediate l_stmt ;
insert into partitionoperlog(table_name,partition_name,oper_type,oper_detail,log_time)
values (l_rec.table_name,l_rec.partition_name ,'DROP',l_stmt,sysdate);
commit;
end if;
exception
when others then
l_err_string := '??????->' || l_stmt || '->' || substrb(sqlerrm,1,100) ;
insert into partitionerrorlog(table_name,error_detail,log_time)
values(l_rec.table_name,l_err_string,sysdate) ;
commit;
l_result := 1;
end;
end loop;

if (l_result != 0) then
raise_application_error(-20100, '?????????') ;
else
insert into partitionerrorlog(table_name,error_detail,log_time)
values('PROC-DROPPARTITION','??????->'||i_end_date||'->'||i_tname,sysdate) ;
commit;
end if;

END;
procedure add_partition (i_end_date VARCHAR2,i_tname VARCHAR2 default 'ALL') as
l_result pls_integer;
l_ret_value pls_integer;
l_end_date date;
l_data_type user_tab_columns.data_type%type;
l_data_length user_tab_columns.data_length%type;

l_err_string varchar2(200);
l_date_error EXCEPTION;

BEGIN
/*?????????*/
BEGIN
/*????????*/
if i_end_date is null then
raise l_date_error ;
end if ;

/*???????????????*/
l_end_date := to_date(i_end_date,'yyyymmdd');
EXCEPTION
WHEN OTHERS THEN
l_err_string := '?????????(YYYYMMDD)->' || i_end_date ;
insert into partitionerrorlog(table_name,error_detail,log_time)
values('PROC-ADDPARTITION',l_err_string,sysdate) ;
commit;
raise_application_error(-20100, l_err_string) ;
END ;

l_result := 0;

/*????????????*/
for l_rec in (select b.table_name,nvl(a.partitiontype,'MONTH') partitiontype
from partitioncleancfg a,user_part_tables b
where b.table_name = a.table_name (+)
and (i_tname = 'ALL' or b.table_name = upper(i_tname))
and b.partitioning_type <> 'LIST') loop
begin
/*????????*/
select a.data_type,a.data_length
into l_data_type,l_data_length
from user_tab_columns a,user_part_key_columns b
where a.table_name = b.name
and a.table_name = l_rec.table_name
and a.column_name = b.column_name;

/*????*/
l_ret_value := handle_table(l_rec.table_name,l_end_date,l_rec.partitiontype,l_data_type,l_data_length);
if (l_ret_value <> 1) then
l_result := 1;
end if;
EXCEPTION
WHEN OTHERS THEN
l_err_string := '??????->' || substrb(sqlerrm,1,100) ;
insert into partitionerrorlog(table_name,error_detail,log_time)
values(l_rec.table_name,l_err_string,sysdate) ;
commit;
l_result := 1;
END ;

end loop;

if (l_result != 0) then
raise_application_error(-20100, '?????????') ;
else
insert into partitionerrorlog(table_name,error_detail,log_time)
values('PROC-ADDPARTITION','??????->'||i_end_date||'->'||i_tname,sysdate) ;
commit;
end if;
END;
end slvw_partition;
/
