CREATE package slvw_partition as
procedure add_partition (i_end_date DATE,i_tname VARCHAR2 default 'ALL');
procedure init_partition (i_end_date VARCHAR2,i_tname VARCHAR2 default 'ALL');
procedure trunc_partition (i_end_date DATE,i_tname VARCHAR2 default 'ALL');
procedure trunc_partition (i_end_date VARCHAR2,i_tname VARCHAR2 default 'ALL');
procedure drop_partition (i_end_date DATE,i_tname VARCHAR2 default 'ALL');
procedure drop_partition (i_end_date VARCHAR2,i_tname VARCHAR2 default 'ALL');
procedure add_partition (i_end_date VARCHAR2,i_tname VARCHAR2 default 'ALL');
end slvw_partition;
/
