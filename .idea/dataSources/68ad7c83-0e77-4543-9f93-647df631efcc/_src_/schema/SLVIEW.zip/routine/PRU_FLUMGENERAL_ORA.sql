CREATE procedure pru_flumgeneral_ora(i_dayflu_flag varchar2,
                                                i_group_id    number,
                                                i_begin_date  date,
                                                i_end_date    date,
                                                rtn_code      out number,
                                                rtn_info      out varchar2)

 is
  /*
  -----------------------????--------------------------------
  ????????????????????????????
  ?????2011-11-21
  ????: naym
  ???????????pl???????????????????????????
  */
  /*????*/
  --I_GROUP_ID ????????  ?????????????
  --????????????? ??? ??????
  --I_minth_id  ???? ?????YYYYMM ????
  /*RTN_CODE   NUMBER(2);
  RTN_INFO   VARCHAR2(100);*/
  /*??????????*/
  v_status  number(2);
  v_step    number(2) := 0;
  v_sp_name varchar2(40) := 'PRU_FLUMGeneral_ORA';

  /*??????????,????????*/
  --V_NUM        NUMBER;
  v_begin_date varchar2(6) := to_char(i_begin_date, 'YYYYMM');
  v_end_date   varchar2(6) := to_char(i_end_date, 'YYYYMM');
  v_groupstart varchar2(10);
  v_groupend   varchar2(10);
begin
  ----------------------??????-----------------------------
  /*??????????*/
  --I_DAYFLU_FLAG ??? B M L ???
  --?????? ?date??? ??????
  --??????
  v_status := fun_get_process_status(v_sp_name || '-' || i_dayflu_flag,
                                     v_begin_date || '-' ||
                                     substr(v_end_date, 5, 2),
                                     3);
  if v_status = 8 then
    rtn_code := -2;
    rtn_info := '??????';
    return;
  end if;

  -- ?????????
  sp_set_process_status(v_sp_name || '-' || i_dayflu_flag,
                        v_begin_date || '-' || substr(v_end_date, 5, 2),
                        3,
                        8,
                        v_step);

  v_step := 1;

  --????????
  case
    when i_group_id <> 0 then
      select restype || groupstart, restype || groupend
        into v_groupstart, v_groupend
        from flusumgroup fp
       where fp.groupnum = i_group_id;
    when i_group_id = 0 then
      select to_char(min(ct.circuitid)), to_char(max(ct.circuitid))
        into v_groupstart, v_groupend
        from circuit ct;
  end case;
  v_step := 2;
  if i_dayflu_flag in ('G') then
    --????????????
    delete from fluxm fm
     where fm.fluxtime >= v_begin_date
       and fm.fluxtime < v_end_date
       and fm.circuitid >= v_groupstart
       and fm.circuitid <= v_groupend;
    commit;
    v_step := 3;

    --???????
    insert into fluxm
      (circuitid,
       fluxtime,
       inavgvec,
       outavgvec,
       inmaxvec,
       outmaxvec,
       inminvec,
       outminvec,
       innonbmaxvec,
       outnonbmaxvec,
       inminvecavg,
       outminvecavg,
       inmaxvecavg,
       outmaxvecavg,
       inbusiavgvec,
       outbusiavgvec,
       inavgratio,
       outavgratio,
       inmaxratio,
       outmaxratio,
       inminratio,
       outminratio,
       innonbmaxratio,
       outnonbmaxratio,
       inbusiavgratio,
       outbusiavgratio,
       inminratioavg,
       outminratioavg,
       inmaxratioavg,
       outmaxratioavg /*,
                                                                    INFLOW,
                                                                    OUTFLOW*/)
      select fd.circuitid,
             substr(fd.fluxtime, 1, 6),
             round(avg(fd.inavgvec), 3),
             round(avg(fd.outavgvec), 3),
             round(max(fd.inmaxvec), 3),
             round(max(fd.outmaxvec), 3),
             round(min(inminvec), 3),
             round(min(outminvec), 3),
             round(max(innonbmaxvec), 3),
             round(max(outnonbmaxvec), 3),
             round(avg(inminvec), 3),
             round(avg(outminvec), 3),
             round(avg(inmaxvec), 3),
             round(avg(outmaxvec), 3),
             round(avg(fd.inbusiavgvec), 3),
             round(avg(fd.outbusiavgvec), 3),
             round(avg(fd.inavgratio), 2),
             round(avg(fd.outavgratio), 2),
             round(max(fd.inmaxratio), 2),
             round(max(fd.outmaxratio), 2),
             round(min(inminratio), 2),
             round(min(outminratio), 2),
             round(max(innonbmaxratio), 2),
             round(max(outnonbmaxratio), 2),
             round(avg(fd.inbusiavgratio), 2),
             round(avg(fd.outbusiavgratio), 2),
             round(avg(inminratio), 2),
             round(avg(outminratio), 2),
             round(avg(inmaxratio), 2),
             round(avg(outmaxratio), 2) /*,
                                                                 ROUND(SUM(FD.INFLOW), 3),
                                                                 ROUND(SUM(FD.OUTFLOW), 3)*/
        from fluxd fd
       where fd.fluxtime > v_begin_date
         and fd.fluxtime < v_end_date
         and fd.circuitid >= v_groupstart
         and fd.circuitid <= v_groupend
       group by fd.circuitid, substr(fd.fluxtime, 1, 6);

    commit;

    --????????????
    delete from flusumbp
     where sumperiodtype = 'M'
       and sumtype = i_dayflu_flag
       and groupnum = i_group_id;
    insert into flusumbp
      (sumperiodtype, sumtype, groupnum, bpdate)
      select 'M',
             upper(i_dayflu_flag),
             i_group_id,
             to_char(add_months(i_end_date, -1), 'YYYYMM')
        from dual;
    commit;
  end if;
  --??2
  v_step := 4;
  if i_dayflu_flag = 'B' then
    /*?????????*/
    --???????????
    execute immediate 'truncate table flux_num';
    execute immediate 'truncate table TEMP_NON_FLUXM';
    --????????????
    insert into flux_num
      (circuitid, num, fluxdate)
      select circuitid,
             trunc(count(*) * 0.05 - 1),
             substr(f.fluxtime, 1, 6) as fluxdate
        from flux f
       where f.fluxtime > v_begin_date
         and f.fluxtime < v_end_date
         and f.circuitid >= v_groupstart
         and f.circuitid <= v_groupend
       group by f.circuitid, substr(f.fluxtime, 1, 6);
    commit;

    v_step := 5;
    /*?????????????*/
    --?????
    insert into temp_flux
      (circuitid,
       fluxtime,
       interval,
       inavgvec,
       outavgvec,
       inavgratio,
       outavgratio)
      select f.circuitid,
             fluxtime,
             interval,
             inavgvec,
             outavgvec,
             (f.inavgvec * 8 / 1000) /
             decode(ct.bandwidth, null, 1, 0, 1, ct.bandwidth) * 100,
             (f.outavgvec * 8 / 1000) /
             decode(ct.bandwidth, null, 1, 0, 1, ct.bandwidth) * 100
        from flux f, circuit ct
       where ct.circuitid = f.circuitid
         and ct.changetype=0
         and f.fluxtime > v_begin_date
         and f.fluxtime < v_end_date
         and f.circuitid >= v_groupstart
         and f.circuitid <= v_groupend;

    v_step := v_step + 1;
    --?????????
    insert into temp_non_fluxm
      (circuitid, fluxtime, result_value, result_type)
      select a1.circuitid, substr(fluxtime, 1, 6), inavgvec, 'INAVGVEC'
        from (select p.*,
                     substr(p.fluxtime, 1, 6) as fluxdate,
                     row_number() over(partition by circuitid, substr(p.fluxtime, 1, 6) order by inavgvec desc) as num_id
                from temp_flux p) a1,
             flux_num fn
       where fn.circuitid = a1.circuitid
         and fn.num = a1.num_id
         and fn.fluxdate = a1.fluxdate;

    insert into temp_non_fluxm
      (circuitid, fluxtime, result_value, result_type)
      select a1.circuitid, substr(fluxtime, 1, 6), outavgvec, 'OUTAVGVEC'
        from (select p.*,
                     substr(p.fluxtime, 1, 6) as fluxdate,
                     row_number() over(partition by circuitid, substr(p.fluxtime, 1, 6) order by outavgvec desc) as num_id
                from temp_flux p) a1,
             flux_num fn
       where fn.circuitid = a1.circuitid
         and fn.num = a1.num_id
         and fn.fluxdate = a1.fluxdate;
    commit;
    --?????
    insert into temp_fluxd
      (circuitid,
       fluxtime,
       innonbmaxvec,
       outnonbmaxvec,
       innonbmaxratio,
       outnonbmaxratio,
       state_flag)
      select circuitid,
             fluxtime,
             nvl(innonbmaxvec, 0),
             nvl(outnonbmaxvec, 0),
             innonbmaxratio,
             outnonbmaxratio,
             'O'
        from fluxm fm
       where fm.fluxtime >= v_begin_date
         and fm.fluxtime < v_end_date
         and fm.circuitid >= v_groupstart
         and fm.circuitid <= v_groupend;

    insert into temp_fluxd
      (circuitid,
       fluxtime,
       innonbmaxvec,
       outnonbmaxvec,
       innonbmaxratio,
       outnonbmaxratio,
       state_flag)
      select tf.circuitid,
             tf.fluxtime,
             nvl(tnf1.result_value, 0),
             nvl(tnf2.result_value, 0),
             '',
             '',
             'B'
        from temp_fluxd tf
        left join temp_non_fluxm tnf1 on tnf1.circuitid = tf.circuitid
                                     and tnf1.fluxtime = tf.fluxtime
                                     and tnf1.result_type = 'INAVGVEC'
        left join temp_non_fluxm tnf2 on tnf2.circuitid = tf.circuitid
                                     and tnf2.fluxtime = tf.fluxtime
                                     and tnf2.result_type = 'OUTAVGVEC';
    delete from temp_fluxd fd where fd.state_flag = 'O';
    --????????
    update fluxm fm
       set (fm.innonbmaxvec, fm.outnonbmaxvec, fm.innonbmaxratio, fm.outnonbmaxratio) = (select innonbmaxvec,
                                                                                                outnonbmaxvec,
                                                                                                innonbmaxratio,
                                                                                                outnonbmaxratio
                                                                                           from temp_fluxd tf
                                                                                          where tf.circuitid =
                                                                                                fm.circuitid
                                                                                            and tf.fluxtime =
                                                                                                fm.fluxtime)
     where fm.circuitid >= v_groupstart
       and fm.circuitid <= v_groupend
       and fm.fluxtime >= v_begin_date
       and fm.fluxtime < v_end_date
       and exists (select *
              from temp_fluxd tfd
             where fm.circuitid = tfd.circuitid
               and fm.fluxtime = tfd.fluxtime);
    commit;
    --????????????
    delete from flusumbp
     where sumperiodtype = 'M'
       and sumtype = i_dayflu_flag
       and groupnum = i_group_id;

    insert into flusumbp
      (sumperiodtype, sumtype, groupnum, bpdate)
      select 'M',
             upper(i_dayflu_flag),
             i_group_id,
             substr(v_end_date, 1, 6)
        from dual;
    commit;
  else
    null;
  end if;

  --????
  sp_set_process_status(v_sp_name || '-' || i_dayflu_flag,
                        v_begin_date || '-' || substr(v_end_date, 5, 2),
                        3,
                        0,
                        v_step);
  rtn_code := 0;
  rtn_info := v_sp_name || '?????????';
  ---------------------????--------------------------------
exception
  when others then
    rollback;
    --??????
    sp_set_process_status(v_sp_name || '-' || i_dayflu_flag,
                          v_begin_date || '-' || substr(v_end_date, 5, 2),
                          3,
                          -1,
                          v_step);
    rtn_code := -1;
    rtn_info := '????????(??' || to_char(v_step) || ')?' || sqlcode ||
                substr(sqlerrm, 1, 200);

end pru_flumgeneral_ora;
/
