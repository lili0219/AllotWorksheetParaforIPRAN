CREATE PROCEDURE alarmbenchmarkcom
IS
   l_start       NUMBER;
   executetime   NUMBER;
   l_err         NUMBER;
   l_status      VARCHAR (20);
   l_date        date;
BEGIN
   l_start := DBMS_UTILITY.get_time;
   l_date:=SYSDATE;
   EXECUTE IMMEDIATE 'truncate table alarmComLog';

   BEGIN
      INSERT INTO alarmcomschedulelog
                  (scheduletime
                  )
           VALUES (l_date
                  );

      COMMIT;
   EXCEPTION
      WHEN OTHERS
      THEN
         DBMS_OUTPUT.put_line ('time sql' || SQLERRM);
   END;

   alarmbenchcomallhis;
   alarmbenchcommoving;
   alarmbenchcomdayofweek;
   l_err := 0;
   l_status := '??';

   SELECT count(*)
    INTO l_err
    FROM alarmcomlog
   WHERE err IS NOT NULL;

   IF (l_err > 0)
   THEN
      l_status := '???';
   END IF;

   executetime := ROUND ((DBMS_UTILITY.get_time - l_start) / 100, 2);

   UPDATE alarmcomschedulelog
      SET status = l_status,
          exetime = executetime
      where scheduletime=l_date;
   COMMIT;
END;
/
