CREATE PROCEDURE PRU_RMDMax_ORA
(
   Method char,
   StartTimeStr char,
   EndTimeStr char
)
AS
StartTime date;
EndTime date;
tmpStartTime date;
tmpEndTime date;
gtmpEndTime date;
tmpStartStr varchar2(14);

BPTime varchar2(10);
BPCount number(1);
ifBP char(1);--????????
ifStat char(1); --????????????????????????????)
HourBP date; --???????????

---????
TYPE R_GROUP IS RECORD(value number(10));
TYPE T_GROUP IS TABLE OF R_GROUP INDEX BY BINARY_INTEGER;
resgroup T_GROUP;

num int;
---????????
StatSpan int;

sql_str varchar2(2000);
type_sql varchar2(500);
type_str varchar2(100);
tmptype varchar2(10);
group_start varchar2(10);
group_end varchar2(10);
group_num number(10);

BEGIN
EndTime := sysdate;
StartTime := to_date(to_char(EndTime-1,'yyyymmdd')||'0000','yyyymmddhh24miss');

---????????
select to_number(PARAVALUE) into StatSpan from syspara where PARANAME='PerfCollectDay';
StatSpan := StatSpan - 1;
if StatSpan < 1 then
   StatSpan := 1;
end if;

select count(1) into group_num from ResSumGroup where groupnum<>0;
if group_num=0 then    --???
    resgroup(1).value := 0;
else
    num := 1;
    for g in (select groupnum from ResSumGroup where groupnum<>0) loop
        resgroup(num).value := g.groupnum;
	num := num+1;
    end loop;
end if;
---???????
num := resgroup.first;
loop
    exit when num is null;
    group_num := resgroup(num).value;
    ifStat := 'Y';

    --????
    select count(*) into BPCount from ressumbp b where b.sumperiodtype='D' and b.sumtype='M' and b.groupnum=group_num;
    if BPCount=0 then
        BPTime := null;
	ifBP := 'I';
    else
        select b.bpdate into BPTime from ressumbp b where b.sumperiodtype='D' and b.sumtype='M' and b.groupnum=group_num;
	ifBP := 'U';
    end if;

    if Method='CRON' then
       if BPTime is null then
          tmpStartTime := StartTime;
          tmpEndTime := EndTime;
       else
           tmpStartTime := to_date(BPTime,'yyyymmdd');
           tmpEndTime := to_date(to_char(tmpStartTime+StatSpan,'yyyymmdd')||'235959','yyyymmddhh24miss');
	         if tmpEndTime>EndTime then
	            tmpEndTime := EndTime;
	         end if;
       end if;
    elsif Method='SUB' then
       tmpStartTime := to_date(StartTimeStr,'yyyymmdd');
       tmpEndTime := to_date(EndTimeStr||'235959','yyyymmddhh24miss');
       if tmpEndTime>tmpStartTime+StatSpan then
           tmpEndTime := to_date(to_char(tmpStartTime+StatSpan,'yyyymmdd')||'235959','yyyymmddhh24miss');
       end if;
       if tmpEndTime>EndTime then
	        tmpEndTime := EndTime;
       end if;

       ---????????????????????
       select count(*) into BPCount from ressumbp b where b.sumperiodtype='H' and b.sumtype='--' and b.groupnum=group_num;
       if BPCount=1 then
          select to_date(substr(b.bpdate,1,8)||'235959','yyyymmddhh24miss') into HourBP from ressumbp b where b.sumperiodtype='H' and b.sumtype='--' and b.groupnum=group_num;
          if HourBP<tmpStartTime then
              ifStat := 'N';
          else
              if HourBP<tmpEndTime then
                 tmpEndTime := HourBP;
              end if;
          end if;
       end if;

       if to_char(tmpEndTime,'yyyymmdd')<BPTime then
           ifBP := 'N';
       end if;
    end if;

    --??????
   if ifStat='Y' then
    if group_num = 0 then
        type_sql := '';
    else
        type_sql := ' AND (';
        select ResType,GroupStart,GroupEnd into type_str,group_start,group_end from ResSumGroup where groupnum=group_num;
        while instr(type_str,',',1)>0 loop
           tmptype := substr(type_str,1,instr(type_str,',',1)-1);
	         type_sql := type_sql||'R.ResID between '''||tmptype||group_start||''' and '''||tmptype||group_end||''' or ';

           type_str := substr(type_str,instr(type_str,',',1)+1,length(type_str)-1-length(tmptype));
        end loop;
	      type_sql := type_sql||'R.ResID between '''||type_str||group_start||''' and '''||type_str||group_end||''')';
    end if;

    ---????
    while tmpStartTime<tmpEndTime loop
         gtmpEndTime := to_date(to_char(tmpStartTime,'yyyymmdd')||'235959','yyyymmddhh24miss');
	       if gtmpEndTime>tmpEndTime then
	           gtmpEndTime := tmpEndTime;
	       end if;

	       --update
	       tmpStartStr := to_char(tmpStartTime,'yyyymmdd');
         sql_str := 'update resmonidailyinfo a set valuetime =
                           (select recordtime
                            from resmonirawinfo R, ResMoniDerivedItemCfg c
                            where  c.DerivedItemCode=a.DerivedItemCode
                               and R.resid=a.resid
			       and R.ItemPara=a.ItemPara
                               and R.MoniItemCode=c.MoniItemCode
                               and R.value=a.value
                               and R.recordtime>=to_date(a.dayid,''yyyymmdd'')
                               and R.recordtime<to_date(a.dayid,''yyyymmdd'')+1
                               and rownum=1'||type_sql||')
                    where  a.dayid='''||tmpStartStr||''' and a.DerivedItemCode in
					                     (select DerivedItemCode
					                      from ResMoniDerivedItemCfg
					                      where DerivedType in (''MAX'',''MIN''))';
         execute immediate sql_str;

         --????
	       if ifBP='I' then
	           insert into ressumbp(SumPeriodType,sumtype,groupnum,BPDate) values('D','M',group_num,to_char(tmpStartTime,'yyyymmdd'));
	           ifBP := 'U';
	       elsif ifBP='U' then
                   if Method='CRON' or (Method='SUB' and to_char(tmpStartTime,'yyyymmdd')>BPTime) then
	               update ressumbp set BPDate=to_char(tmpStartTime,'yyyymmdd') where sumperiodtype='D' and sumtype='M' and groupnum=group_num;
	           end if;
         end if;
	 select b.bpdate into BPTime from ressumbp b where b.sumperiodtype='D' and b.sumtype='M' and b.groupnum=group_num;

         commit;  --??
	       tmpStartTime := tmpStartTime+1;
   end loop; --??????
  end if; --??????
   num := resgroup.next(num);
end loop;--??????

END;
/
