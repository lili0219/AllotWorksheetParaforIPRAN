CREATE FUNCTION f_bin_to_dec(p_str IN VARCHAR2) RETURN VARCHAR2
IS
   v_return  VARCHAR2(4000);
BEGIN
    SELECT SUM(data1) INTO v_return
      FROM (SELECT substr(p_str, rownum, 1) * power(2, length(p_str) - rownum) data1
              FROM dual
            CONNECT BY rownum <= length(p_str));
    RETURN v_return;
EXCEPTION
   WHEN OTHERS THEN
      RETURN NULL;
END f_bin_to_dec;
/
