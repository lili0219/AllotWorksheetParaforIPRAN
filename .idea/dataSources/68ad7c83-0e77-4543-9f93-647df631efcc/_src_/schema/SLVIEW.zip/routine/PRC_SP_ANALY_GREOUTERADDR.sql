CREATE procedure prc_sp_analy_greouteraddr
(
    o_retdesc out varchar2
)
as
begin
    -- apntunnelinfo???outeraddrdetail????outeraddrdetail?????
    update outeraddrdetail g
    set    g.status = 'free', g.deviceid = '', g.custid = '', g.wsnbr = '', g.updatetime = sysdate
    where  g.status = 'used'
    and    not exists (select 1 from apntunnelinfo a where a.outeripseg = g.ipsegment);

    -- apntunnelinfo??outeraddrdetail?????outeraddrdetail?????
    -- apntunnelinfo??outeraddrdetail????outeraddrdetail???????
    merge  into outeraddrdetail g
    using  (with tmp_apntunnelinfo as (
                     select outeripseg, deviceid, custid,
                            fun_transipmask(outeripseg, 1) str_ip_seg,
                            fun_transipmask(outeripseg, 2) int_ip_seg,
                            row_number()over(partition by outeripseg order by custid, wsnbr nulls last) rn
                     from   apntunnelinfo ai
                     where  outeripseg is not null)
            select /*+ materialize*/ distinct outeripseg, deviceid, custid,
                   substr(str_ip_seg, 1, instr(str_ip_seg, '-')-1) startip,
                   substr(str_ip_seg, instr(str_ip_seg, '-')+1) endip,
                   substr(int_ip_seg, 1, instr(int_ip_seg, '-')-1) nstartip,
                   substr(int_ip_seg, instr(int_ip_seg, '-')+1) nendip
            from   tmp_apntunnelinfo
            where  rn = 1) a
    on     (a.outeripseg = g.ipsegment)
    when   matched then
    update
    set    g.status = 'used', g.deviceid = a.deviceid, g.custid = a.custid, g.updatetime = sysdate
    when   not matched then
    insert (g.deviceid, g.custid, g.ipsegment, g.ipnum, g.startip, g.endip,
            g.nstartip, g.nendip, g.status, g.updatetime)
    values (a.deviceid, a.custid, a.outeripseg, a.nendip-a.nstartip+1, a.startip, a.endip,
            a.nstartip, a.nendip, 'used', sysdate);

    commit;
    o_retdesc := 'Succeed';

exception when others then
    o_retdesc := 'Failed ORA-'||sqlcode;
    rollback;
end prc_sp_analy_greouteraddr;
/
