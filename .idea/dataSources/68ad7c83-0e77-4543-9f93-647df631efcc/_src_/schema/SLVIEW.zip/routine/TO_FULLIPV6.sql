CREATE FUNCTION to_fullipv6
(p_ipv6addr IN varchar2)
RETURN varchar2 IS
--Purpose: ?IPv6???0???????????????00FF:FFFF:0000:0000:0000:FFFF:FFFF:FFFF?
--????32??ipv4???????
--??IPv6???????null
l_return   varchar2(45);          /*???IP???*/
l_convert  constant varchar2(16) :='0123456789ABCDEF';
l_upper    varchar2(45);          /*????????????*/
l_length   integer;               /*?????*/
l_begin    integer;
l_end      integer;
l_position integer;
l_count    integer;
l_temp     integer;
l_replace  varchar2(45);          /*?????*/
l_sub      varchar2(45);          /*??*/
BEGIN
    /*?????????*/
    l_upper:=UPPER(LTRIM(RTRIM(p_ipv6addr)));

    if l_upper is null
    then return null;
    end if;


    /*??????IPv4??*/
    if INSTR(l_upper,'.')>0  then
        l_position:=INSTR(l_upper,':',-1);
        if l_position=0 then
            return null;/*IPv4??*/
        else
            /*???32??v4??*/
            l_sub:=SUBSTR(l_upper,l_position+1)||'.';

            if LTRIM(l_sub,'0123456789.') is not null
            then return null;
            end if;

            l_replace:='';
            l_count:=0;
            l_begin:=1;
            l_length:=LENGTH(l_sub);
            while l_begin<=l_length
            loop
                l_end:=INSTR(l_sub,'.',l_begin);
                if l_end=0 or l_begin=l_end then return null;end if;

                l_temp:=to_Number(SUBSTR(l_sub,l_begin,l_end-l_begin));
                if l_temp<0 or l_temp>255 then
                     return null;
                end if;

                l_replace:=l_replace||SUBSTR(l_convert,FLOOR(l_temp/16)+1,1)||SUBSTR(l_convert,FLOOR(MOD(l_temp,16))+1,1);
                l_count:=l_count+1;
                l_begin:=l_end+1;
            end loop;

            if l_count!=4 then return null;end if;

            l_replace:=SUBSTR(l_replace,1,4)||':'||SUBSTR(l_replace,5,4);
            l_upper:=SUBSTR(l_upper,1,l_position)||l_replace;
        end if;
    end if;

    /*?????????*/
    if LTRIM(l_upper,l_convert||':') is not null
    then return null;
    end if;

    /*?"::"????*/
    if l_upper='::'
    then return '0000:0000:0000:0000:0000:0000:0000:0000';
    end if;

    l_return:='';
    l_begin:=1;
    l_end:=1;
    l_count:=0;

    while INSTR(l_upper,':',l_begin)>0
    loop
        l_count:=l_count+1;
        l_begin:=INSTR(l_upper,':',l_begin)+1;
    end loop;

    l_position:=INSTR(l_upper,'::');

    /*??????*/
    if l_position>0
    then
        l_count:=l_count-2;
        l_replace:=':';

        if l_position!=1 and l_position!=LENGTH(l_upper)-1
        then l_count:=l_count+1;
        end if;

        while l_count<7
        loop
           l_replace:=l_replace||'0000:';
           l_count:=l_count+1;
        end loop;

         if l_replace=':' then
            return null;
        end if;

        if l_position=1
        then l_replace:=SUBSTR(l_replace,2);
            else if l_position=LENGTH(l_upper)-1
            then l_replace:=SUBSTR(l_replace,1,LENGTH(l_replace)-1);
            end if;
        end if;

        l_upper:=SUBSTR(l_upper,1,l_position-1)||l_replace||SUBSTR(l_upper,l_position+2);
    end if;

    /*????????*/
    if INSTR(l_upper,'::')>0
    then return null;
    end if;

    l_count:=0;
    l_begin:=1;
    l_upper:=l_upper||':';
    l_length:=LENGTH(l_upper);
    /*???????????*/
    while l_begin<=l_length
    loop
       l_count:=l_count+1;
       l_end:=INSTR(l_upper,':',l_begin);

       if l_begin=l_end or l_end=0
       then return null;
       end if;

       l_sub:=SUBSTR(l_upper,l_begin,l_end-l_begin);

       /*??????????4*/
       if LENGTH(l_sub)>4
       then return null;
       end if;

       l_sub:=LPAD(l_sub,4,'0');
       l_return:=l_return||':'||l_sub;

       l_begin:=l_end+1;
    end loop;

    if l_count!=8 then return null;end if;

    l_return:=SUBSTR(l_return,2);

    RETURN l_return;

EXCEPTION
   WHEN others THEN
       return null ;
END;
/
