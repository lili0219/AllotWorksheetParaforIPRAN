CREATE FUNCTION hxtoten (str_a IN VARCHAR2)
   RETURN NUMBER
IS
   str_b   NUMBER (10);
   str_c   VARCHAR2 (100);
BEGIN
   str_c := REPLACE (str_a, '0x', '');
   str_b := 0;

   WHILE LENGTH (str_c) IS NOT NULL
   LOOP
      str_b :=
           str_b * 16
         + CASE SUBSTR (str_c, 0, 1)
              WHEN 'A'
                 THEN 10
              WHEN 'B'
                 THEN 11
              WHEN 'C'
                 THEN 12
              WHEN 'D'
                 THEN 13
              WHEN 'E'
                 THEN 14
              WHEN 'F'
                 THEN 15
              ELSE CAST (SUBSTR (str_c, 0, 1) AS INT)
           END;
      str_c := SUBSTR (str_c, - (LENGTH (str_c) - 1), LENGTH (str_c) - 1);
   END LOOP;

   RETURN str_b;
END ;
/
