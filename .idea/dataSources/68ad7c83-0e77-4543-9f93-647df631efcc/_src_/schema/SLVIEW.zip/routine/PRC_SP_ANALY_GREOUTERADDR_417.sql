CREATE procedure prc_sp_analy_greouteraddr_417
(
    o_retdesc out varchar2
)
as
begin
    -- apntunnelinfo???outeraddrdetail????outeraddrdetail?????
    update outeraddrdetail g
    set    g.status = 'free', g.deviceid = '', g.custid = '', g.wsnbr = '', g.updatetime = sysdate
    where  g.status = 'used'
    and    not exists (select 1 from apntunnelinfo a where a.outeripseg = g.ipsegment);

    -- apntunnelinfo??outeraddrdetail?????outeraddrdetail?????
    -- apntunnelinfo??outeraddrdetail????outeraddrdetail???????
    merge  into outeraddrdetail g
    using  (with tmp_ip as(
                     select outeripseg ,count(*) cou
                     from apntunnelinfo
                     where outeripseg is not null
                     group by outeripseg having count(*) > 1),
                 tmp_apntunnelinfo as (
                     select ai.outeripseg, ai.deviceid, ai.custid,
                            fun_transipmask(ai.outeripseg, 1) str_ip_seg,
                            fun_transipmask(ai.outeripseg, 2) int_ip_seg
                     from   apntunnelinfo ai
                     where  ai.outeripseg is not null
                     and    not exists(select 1 from tmp_ip where ai.outeripseg = tmp_ip.outeripseg))
            select distinct outeripseg, deviceid, custid,
                   substr(str_ip_seg, 1, instr(str_ip_seg, '-')-1) startip,
                   substr(str_ip_seg, instr(str_ip_seg, '-')+1) endip,
                   substr(int_ip_seg, 1, instr(int_ip_seg, '-')-1) nstartip,
                   substr(int_ip_seg, instr(int_ip_seg, '-')+1) nendip
            from tmp_apntunnelinfo) a
    on     (a.outeripseg = g.ipsegment)
    when   matched then
    update
    set    g.status = 'used', g.deviceid = a.deviceid, g.custid = a.custid, g.updatetime = sysdate
    when   not matched then
    insert (g.deviceid, g.custid, g.ipsegment, g.ipnum, g.startip, g.endip,
            g.nstartip, g.nendip, g.status, g.updatetime)
    values (a.deviceid, a.custid, a.outeripseg, a.nendip-a.nstartip+1, a.startip, a.endip,
            a.nstartip, a.nendip, 'used', sysdate);

    commit;
    o_retdesc := 'Succeed';

exception when others then
    o_retdesc := 'Failed ORA-'||sqlcode;
    rollback;
end prc_sp_analy_greouteraddr;
/
