CREATE PROCEDURE clearresreladata
IS
BEGIN
   DELETE FROM resstattimerela
         WHERE resid NOT IN (SELECT resid
                               FROM res);

   DELETE FROM resstattime
         WHERE resid NOT IN (SELECT resid
                               FROM res);

   DELETE FROM restag
         WHERE resid NOT IN (SELECT resid
                               FROM res);

   DELETE FROM resparatag
         WHERE resid NOT IN (SELECT resid
                               FROM res);

   DELETE FROM resparatag a
         WHERE NOT EXISTS (
                       SELECT *
                         FROM cardinfo b
                        WHERE a.resid = b.deviceid
                              AND a.respara = b.cardindex ) and a.RESPARATYPE='CARD';

   DELETE FROM resparatag a
         WHERE NOT EXISTS (
                       SELECT *
                         FROM portinfo b
                        WHERE a.resid = b.deviceid
                              AND a.respara = b.portdescr ) and a.RESPARATYPE='PORT';

   COMMIT;
END;
/
