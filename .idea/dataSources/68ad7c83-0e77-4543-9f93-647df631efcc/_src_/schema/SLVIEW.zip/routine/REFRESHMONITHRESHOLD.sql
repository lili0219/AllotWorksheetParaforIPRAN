CREATE PROCEDURE refreshmonithreshold
IS
/*
??:
1.  ??????????????????
    ?????????
    (1).????????
    (2).?????? ? ??????'OR'
    (3).?????????'SRC',??????
    (4).?????'>='?'>'
2.  ?????????,??????????????
3.  ???????
*/
BEGIN
   EXECUTE IMMEDIATE 'truncate table resmonithreshold';

   INSERT INTO resmonithreshold
               (resid, moniitemcode, threshold)
      SELECT   a.resid, b.dataitemid, MIN (b.threshold)
          FROM resalarmcfg a,
               (SELECT a1.alarmcondid, a1.dataitemid, a1.threshold
                  FROM alarmconditionitem a1,
                       (SELECT   b2.alarmcondid, b2.logicsymbol
                            FROM alarmconditionitem a2, alarmcondition b2
                           WHERE a2.alarmcondid = b2.alarmcondid
                             AND b2.sourcedatetype = 'RealTime'
                        GROUP BY b2.alarmcondid, b2.logicsymbol
                          HAVING COUNT (*) = 1 OR b2.logicsymbol = 'OR') b1
                 WHERE a1.alarmcondid = b1.alarmcondid
                   AND a1.calctype = 'SRC'
                   AND a1.OPERATOR IN ('>=', '>')) b
         WHERE a.alarmcondid = b.alarmcondid
      GROUP BY a.resid, b.dataitemid
      UNION
      SELECT DISTINCT c.resid, b.dataitemid, MIN (b.threshold)
                 FROM restagalarmcfg a,
                      (SELECT a1.alarmcondid, a1.dataitemid, a1.threshold
                         FROM alarmconditionitem a1,
                              (SELECT   b2.alarmcondid, b2.logicsymbol
                                   FROM alarmconditionitem a2,
                                        alarmcondition b2
                                  WHERE a2.alarmcondid = b2.alarmcondid
                                    AND b2.sourcedatetype = 'RealTime'
                               GROUP BY b2.alarmcondid, b2.logicsymbol
                                 HAVING COUNT (*) = 1 OR b2.logicsymbol = 'OR') b1
                        WHERE a1.alarmcondid = b1.alarmcondid
                          AND a1.calctype = 'SRC'
                          AND a1.OPERATOR IN ('>=', '>')) b,
                      restag c
                WHERE a.alarmcondid = b.alarmcondid AND a.tag = c.tag
             GROUP BY c.resid, b.dataitemid;

   COMMIT;
END;
/
