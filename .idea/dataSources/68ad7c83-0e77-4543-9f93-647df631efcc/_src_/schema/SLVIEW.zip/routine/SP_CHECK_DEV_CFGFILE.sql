CREATE procedure sp_check_dev_cfgfile(rtn_code out number,
                                                 rtn_info out varchar2)

 is
  /*
  -----------------------????--------------------------------
  ???????????????DC_Check_DEV_CFGFILE
  ?????2012-7-21
  ????: naym
  ???
  */
  v_step number;
begin
  ----------------------??????-----------------------------
  v_step := 0;
  ---??????
  delete from dc_deverrortmp where checkitemcode = 'DEV_CFGFILE';
  commit;
  v_step := 1;
  ---?????Ip??????????
  insert into dc_deverrortmp
    select dv.deviceid,
           'DEV_CFGFILE',
           sysdate,
           pt.probeip,
           rp.groupno,
           '???????????',
           ''
      from device dv, resgroup rp, probehost pt
     where substr(dv.moniflag, 3, 1) = 'Y'
       and dv.deviceid = rp.resid(+)
       and rp.probeid = pt.probeid(+)
       and dv.changetype = '0'
       and nvl(rp.coltype(+), 'CFGFILE') = 'CFGFILE'
       and (rp.groupno is null or pt.probeid is null);
  v_step := 2;
  --?????????
  insert into dc_deverrortmp
    select deviceid,
           'DEV_CFGFILE',
           sysdate,
           probeip,
           groupno,
           '??????????',
           ''
      from (select d.deviceid,
                   r.groupno,
                   h.probeip,
                   c.colstatus,
                   c.errortype
              from device d, resgroup r, probehost h, cfgfilecolstatus c
             where d.changetype = 0
               and substr(d.moniflag, 3, 1) = 'Y'
               and d.deviceid = r.resid
               and r.groupno is not null
               and h.probeid is not null
               and nvl(r.coltype, 'CFGFILE') = 'CFGFILE'
               and r.probeid = h.probeid
               and d.deviceid = c.deviceid(+))
     where colstatus = 'F';

  commit;

  rtn_code := 0;
  rtn_info := '?????';

  ---------------------????--------------------------------
exception
  when others then
    rollback;
    rtn_code := -1;
    rtn_info := '????????(??' || to_char(v_step) || ')?' || sqlcode ||
                substr(sqlerrm, 1, 200);

end sp_check_dev_cfgfile;
/
