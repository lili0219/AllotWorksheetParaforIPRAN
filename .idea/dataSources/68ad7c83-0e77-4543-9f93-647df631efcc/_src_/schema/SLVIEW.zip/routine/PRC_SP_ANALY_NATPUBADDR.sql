CREATE procedure prc_sp_analy_natpubaddr
(--  NAT?????????????????????
o_retdesc out varchar2
)
as
begin
    --?? nataddrdetail.astartip?bstartip??????iviservdetail.nataddr?IP????nataddrdetail.status=used????
    update nataddrdetail nad
    set nad.status = 'free',nad.ippoolname = '',nad.adeviceid = '' ,nad.bdeviceid = '', nad.custid = '', nad.wsnbr = '', nad.updatetime = sysdate
    where nad.status = 'used'
    and not exists (select 1 from iviservdetail isd
                    where (func_trans_ip_str2int(nad.astartip) between func_trans_ip_str2int(substr(isd.nataddr,1,instr(isd.nataddr,'-',1,1) - 1)) and func_trans_ip_str2int(substr(isd.nataddr,instr(isd.nataddr,'-',1,1) + 1))
                        or func_trans_ip_str2int(nad.bstartip) between func_trans_ip_str2int(substr(isd.nataddr,1,instr(isd.nataddr,'-',1,1) - 1)) and func_trans_ip_str2int(substr(isd.nataddr,instr(isd.nataddr,'-',1,1) + 1))
                          )
                    );

    -- ?startip??????????
   merge into nataddrdetail nad
    using (with tmp as(select  ippoolname,custid,row_number()over(partition by ippoolname order by custid) rn
                       from iviserv),
              tmp2 as(
    select  isd.ippoolname, isd.deviceid, i.custid,
                  func_trans_ip_str2int(substr(isd.nataddr,1,instr(isd.nataddr,'-',1,1) - 1)) nstartip,
                  func_trans_ip_str2int(substr(isd.nataddr,instr(isd.nataddr,'-',1,1) + 1)) nendip,row_number()over(partition by isd.nataddr order by isd.ippoolname) rn
           from tmp i, iviservdetail isd
           where i.ippoolname(+) = isd.ippoolname
           and i.rn = 1)
      select  distinct ippoolname,deviceid,custid,nstartip,nendip from tmp2 where rn = 1) a
    on (func_trans_ip_str2int(nad.astartip) between a.nstartip and a.nendip)
     when matched then
       update set nad.status = 'used',nad.ippoolname = a.ippoolname,
       nad.adeviceid = a.deviceid,
       nad.custid = nvl(a.custid,nad.custid), updatetime = sysdate;

    merge into nataddrdetail nad
    using (with tmp as(select  ippoolname,custid,row_number()over(partition by ippoolname order by custid) rn
                       from iviserv),
              tmp2 as(
    select  isd.ippoolname, isd.deviceid, i.custid,
                  func_trans_ip_str2int(substr(isd.nataddr,1,instr(isd.nataddr,'-',1,1) - 1)) nstartip,
                  func_trans_ip_str2int(substr(isd.nataddr,instr(isd.nataddr,'-',1,1) + 1)) nendip,row_number()over(partition by isd.nataddr order by isd.ippoolname) rn
           from tmp i, iviservdetail isd
           where i.ippoolname(+) = isd.ippoolname
           and i.rn = 1)
      select  distinct ippoolname,deviceid,custid,nstartip,nendip from tmp2 where rn = 1) a
    on (func_trans_ip_str2int(nad.bstartip) between a.nstartip and a.nendip)
     when matched then
       update set nad.status = 'used',nad.ippoolname = a.ippoolname,
       nad.bdeviceid =  a.deviceid,
       nad.custid = nvl(a.custid,nad.custid), updatetime = sysdate;

       o_retdesc:= 'Succeed to analy !';
       commit;
exception when others then
       o_retdesc := 'Failed ORA-'||sqlcode;
       rollback;
end prc_sp_analy_natpubaddr;
/
