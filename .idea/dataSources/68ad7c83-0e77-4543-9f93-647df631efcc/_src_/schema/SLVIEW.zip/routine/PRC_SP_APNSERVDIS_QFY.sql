CREATE procedure prc_sp_apnservdis_qfy
(
    i_deviceid in varchar2,
    o_retdesc out varchar2
)
as
    v_cnt number(1);
begin
    -- ??qfy_portextinfo????qfy_portextinfo?????????????????
    -- ???????????????APN?????????
    select count(1) into v_cnt
    from   qfy_portextinfo p, device d
    where  d.deviceid = i_deviceid
    and    d.deviceid = p.deviceid
    and    d.changetype = 0
    and    d.devicetypecode = 'DEV_IP_G'
    and    d.devicepropcode = 'PRP012'
    and    p.porttype = 'Tunnel'
    and    rownum = 1;

    if v_cnt = 0 then
        o_retdesc := 'Device not found or is not GGSN dev';
        return;
    end if;

    -- ??????????disapntunnelinfo?????????????
    delete from qfy_disapntunnelinfo where deviceid = i_deviceid;

    -- ??
    insert into qfy_disapntunnelinfo
          (tunnelid,
           deviceid, vpninstance, vpnrd, apnname, gresource, gredestination,
           inneripseg, outeripseg,
           localaddr, remoteaddr,
           ippoolname, ippooltype, ippoolsection, masterdns, slavedns, updatetime, l2tpgroup,
           giif, l2tpremoteaddr, l2tplocaladdr, l2tpremoteflag, l2tplocalflag, passwd, pvlan, cevrrpvrid)
    with tmp_listagg as(
        select dc.deviceid, dc.vpninstance,dc.ippoolname,dc.ippooltype,
               listagg(nvl(ips.startip||'-'||nvl(ips.endip, ips.startip),';'),';')within group(order by dc.ippoolname) ippoolsection
        from   devcolippool dc, ippoolsection ips
        where  dc.deviceid = ips.deviceid
        and    dc.ippoolname = ips.ippoolname
        and    dc.vpninstance is not null
        group  by dc.deviceid, dc.vpninstance,dc.ippoolname,dc.ippooltype),
    tmp_devcolippool as (
        select deviceid, vpninstance,
               listagg(ippoolname,'#') within group(order by ippoolname) ippoolname,
               listagg(ippooltype,'#') within group(order by ippoolname) ippooltype,
               listagg(ippoolsection,'#') within group(order by ippoolname) ippoolsection
        from   tmp_listagg
        group  by deviceid, vpninstance),
    tmp_qfy_portextinfo as (
        select replace(regexp_substr(portdescr,'Tunnel\d*'), 'Tunnel', '') tunnelid,
               deviceid, portdescr, vpninstance, source, destination, destinationmode
        from   qfy_portextinfo
        where  deviceid = i_deviceid
        and    vpninstance is not null
        and    portdescr is not null),
    tmp_devportadd_t as (
        select da.deviceid, da.portdescr,
               da.ipaddress||'/'||func_trans_mask_str2int(da.netmask) inneripseg,
               pi.destination||case when pi.destination is null then '' else '/29' end outeriptmpseg,
               fun_transipmask(da.ipaddress||'/'||func_trans_mask_str2int(da.netmask), 2) int_ip_seg
        from   devportaddr da,tmp_qfy_portextinfo pi
        where  da.portdescr = pi.portdescr
        and    pi.deviceid = i_deviceid),
    tmp_devportaddr as (
        select deviceid, portdescr, inneripseg,
               func_trans_ip_int2str(func_trans_ip_str2int(substr(fun_transipmask(outeriptmpseg),1,instr(fun_transipmask(outeriptmpseg),'-',1,1)-1))+1) outerip,
               substr(int_ip_seg, 1, instr(int_ip_seg, '-')-1) nstartip,
               substr(int_ip_seg, instr(int_ip_seg, '-')+1) nendip
        from tmp_devportadd_t),
    tmp_devcoll2tpgrp as(
        select d.*, dpa.ipaddress||'/'||func_trans_mask_str2int(dpa.netmask) l2tplocaladdr
        from   devcoll2tpgrp d,devportaddr dpa
        where  d.deviceid = dpa.deviceid(+)
        and    d.portdescr = dpa.portdescr(+)),
    tmp_apninfo as (
        select a.deviceid, a.vpninstance, a.l2tpgroup, d.portdescr, d.lnsip, d.domain, d.local, d.passwd, d.l2tplocaladdr,
               -- TD108786????????????????#?modified by maoheng
               -- listagg(nvl(a.apnname,'#'),'#') within group( order by a.apnname) apnname,
               -- listagg(nvl(a.masterdns,'#'),'#') within group( order by a.apnname) masterdns,
               -- listagg(nvl(a.slavedns,'#'),'#') within group( order by a.apnname) slavedns
               listagg(a.apnname,'#') within group( order by a.apnname) apnname,
               listagg(a.masterdns,'#') within group( order by a.apnname) masterdns,
               listagg(a.slavedns,'#') within group( order by a.apnname) slavedns
        from   apninfo a,tmp_devcoll2tpgrp d
        where  a.vpninstance is not null
        and    a.deviceid = d.deviceid(+)
        and    a.l2tpgroup = d.l2tpgroup(+)
        group  by a.deviceid, a.vpninstance, a.l2tpgroup, d.portdescr, lnsip, d.domain, d.local, d.passwd, d.l2tplocaladdr),
   tmp_result as (
        select replace(regexp_substr(pi.portdescr,'Tunnel\d*'), 'Tunnel', '') tunnelid,
               pi.deviceid, pi.vpninstance, vrf.rd, ai.apnname, pi.source, pi.destination,
               da.inneripseg, decode(pi.destinationmode, 'vpn', da.outerip|| nvl2(da.outerip, '/29', ''), '') outeripseg,
               func_trans_ip_int2str(da.nstartip + 1) localaddr, func_trans_ip_int2str(da.nstartip + 2) remoteaddr,
               dc.ippoolname, dc.ippooltype, dc.ippoolsection, ai.masterdns, ai.slavedns, sysdate,ai.l2tpgroup,
               ai.portdescr, ai.lnsip, ai.l2tplocaladdr, ai.domain, ai.local, ai.passwd
        from   tmp_qfy_portextinfo pi, vrf, tmp_apninfo ai, tmp_devportaddr da, tmp_devcolippool dc
        where  pi.tunnelid is not null
        and    pi.deviceid = vrf.peid(+) and pi.vpninstance = vrf.vrfname(+)
        and    pi.deviceid = ai.deviceid(+) and pi.vpninstance = ai.vpninstance(+)
        and    pi.deviceid = da.deviceid(+) and pi.portdescr = da.portdescr(+)
        and    pi.deviceid = dc.deviceid(+) and pi.vpninstance = dc.vpninstance(+)),
   tmp_result1 as (
        select trs.*, fun_transipmask(trs.outeripseg,2) outeripseg_int
        from tmp_result trs
   )
    select distinct rs.tunnelid,
           i_deviceid, rs.vpninstance, rs.rd, rs.apnname, rs.source, rs.destination,
           rs.inneripseg, rs.outeripseg,
           rs.localaddr, rs.remoteaddr,
           rs.ippoolname, rs.ippooltype, rs.ippoolsection, rs.masterdns, rs.slavedns, sysdate, rs.l2tpgroup,
           rs.portdescr, rs.lnsip, rs.l2tplocaladdr, rs.domain, rs.local, rs.passwd,
           first_value(oi.vlan)over(partition by rs.outeripseg order by 1) vlan,
           first_value(oi.vrrpvrid)over(partition by rs.outeripseg order by 1) vrrpvrid
    from   tmp_result1 rs
  left   join  qfy_otherportextinfo oi
          on    func_trans_ip_str2int(oi.ipaddress) >= to_number(substr(rs.outeripseg_int, 1, instr(rs.outeripseg_int, '-')-1))
          and   func_trans_ip_str2int(oi.ipaddress) <= to_number(substr(rs.outeripseg_int, instr(rs.outeripseg_int, '-')+1))
     ;
    commit;
    o_retdesc := 'Succeed';
exception when others then
    o_retdesc := 'Failed ORA-'||sqlcode;
    rollback;
end prc_sp_apnservdis_qfy;
/
