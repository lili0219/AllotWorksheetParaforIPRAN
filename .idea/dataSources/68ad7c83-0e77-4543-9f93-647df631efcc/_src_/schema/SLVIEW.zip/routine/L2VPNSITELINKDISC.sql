CREATE PROCEDURE L2VPNSiteLinkDisc IS
begin
 delete from L2VPNSite2Site;
 insert into L2VPNSite2Site(ID,FromSite,ToSite)
select rownum,fromsite,tosite from
(select distinct c1.siteid fromsite,c2.siteid tosite
  from l2vpnlink l, ce c1,ce c2
 where l.aceid = c1.ceid
   and l.bceid = c2.ceid
   and c1.siteid <> c2.siteid);
end;
/
