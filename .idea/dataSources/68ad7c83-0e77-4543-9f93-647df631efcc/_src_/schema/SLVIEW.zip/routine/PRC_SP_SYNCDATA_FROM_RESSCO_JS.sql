CREATE procedure prc_sp_syncdata_from_ressco_js
(
    o_retdesc  out varchar2
)
as
    v_dblink   varchar2(50) := '@to_ressco';
begin
    o_retdesc := '['||to_char(sysdate, 'hh24:mi:ss')||']:  Work Start!';

    for info in (select 'spc_room_area' desttab, 'spc_room_area_4_curr_sync' tmptab,
                        'vw_spc_room_area'||v_dblink srctab,
                        'room_id, room_name, type_id, formal_type_id, access_area, converge_area' collist
                 from   dual
                 union  all
                 select 'spc_bldg_area' desttab, 'spc_bldg_area_4_curr_sync' tmptab,
                        'vw_spc_bldg_area'||v_dblink srctab,
                        'bldg_id, bldg_name, pos_x, pos_y, region_name, address, access_area, pair_num, '||
                        'user_pair_num, optical_addr, degree_level, man_name, man_link'
                 from   dual)
    loop
        o_retdesc := o_retdesc||chr(10)||'['||to_char(sysdate, 'hh24:mi:ss')||']:  try to sync table{'||info.desttab||'}: ';

        -- drop???
        begin
            execute immediate 'drop table '||info.tmptab;
        exception when others then
            -- ??????????????????????
            if sqlcode != '-942' then
                o_retdesc := o_retdesc||chr(10)||'['||to_char(sysdate, 'hh24:mi:ss')||']:  failed with sqlcode{'||SQLCODE||'}!';
                continue;
            end if;
        end;

        begin
            -- ?dblkink?????????
            execute immediate 'create table '||info.tmptab||' as select * from '||info.srctab;

            -- truncate ???
            execute immediate 'truncate table '||info.desttab;

            -- ???????????
            execute immediate 'insert into '||info.desttab||'('||info.collist||') '||
                              'select '||info.collist||' from '||info.tmptab;

            o_retdesc := o_retdesc||chr(10)||'['||to_char(sysdate, 'hh24:mi:ss')||']:  succeed with {'||sql%rowcount||'} rows!';
            commit;
        exception when others then
            o_retdesc := o_retdesc||chr(10)||'['||to_char(sysdate, 'hh24:mi:ss')||']:  failed with sqlcode{'||SQLCODE||'}!';
        end;
    end loop;

    o_retdesc := o_retdesc||chr(10)||'['||to_char(sysdate, 'hh24:mi:ss')||']:  Finished!';

    commit;
exception when others then
    o_retdesc := o_retdesc||chr(10)||'['||to_char(sysdate, 'hh24:mi:ss')||']:  unknown error with sqlcode{'||SQLCODE||'}!';
    rollback;
end prc_sp_syncdata_from_ressco_js;

/
