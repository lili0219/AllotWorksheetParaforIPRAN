CREATE FUNCTION to_ipsegment (iip VARCHAR2, imask VARCHAR2)
RETURN VARCHAR2
IS
-- Purpose: ip mask??startip?endip
--
-- MODIFICATION HISTORY
-- Person Date Comments
-- --------- ------ -------------------------------------------
l_return VARCHAR2 (33);
l_pos INTEGER;
tempip VARCHAR2 (3);
tempmask VARCHAR2 (3);
startip VARCHAR (20);
endip VARCHAR (20);
umask INTEGER;
ip VARCHAR2 (255);
MASK VARCHAR2 (255);
nstartip NUMBER (11);
nendip NUMBER (11);
BEGIN
nstartip:=0;
nendip:=0;
IF iip IS NULL OR imask IS NULL
THEN
RETURN NULL;
END IF;

ip := iip;
MASK := imask;

FOR i IN 1 .. 3
LOOP
l_pos := INSTRB (ip, '.');
tempip := SUBSTR (ip, 1, l_pos - 1);
ip := SUBSTR (ip, l_pos + 1);

IF (l_pos = 0)
THEN
RETURN NULL;
END IF;

l_pos := INSTRB (MASK, '.');
tempmask := SUBSTR (MASK, 1, l_pos - 1);
MASK := SUBSTR (MASK, l_pos + 1);

IF (l_pos = 0)
THEN
RETURN NULL;
END IF;

IF (tempip < 0 OR tempip > 255 OR tempmask < 0 OR tempmask > 255)
THEN
RETURN NULL;
END IF;

umask := (255 + tempmask) - BITAND (255, tempmask) * 2;

startip := startip || '.' || (BITAND (tempip, tempmask));
--DBMS_OUTPUT.PUT_LINE(power(256,4-i)*(BITAND (tempip, tempmask)));
nstartip := nstartip+power(256,4-i)*(BITAND (tempip, tempmask));
DBMS_OUTPUT.PUT_LINE('nstartip'||nstartip);

endip := endip || '.' || ((tempip + umask) - BITAND (tempip, umask));
nendip := nendip+power(256,4-i)*((tempip + umask) - BITAND (tempip, umask));

END LOOP;

IF (ip < 0 OR ip > 255 OR MASK < 0 OR MASK > 255)
THEN
RETURN NULL;
END IF;

umask := (255 + MASK) - BITAND (255, MASK) * 2;

startip := startip || '.' || (BITAND (ip, MASK));
nstartip := nstartip+(BITAND (ip, MASK));

endip := endip || '.' || ((ip + umask) - BITAND (ip, umask));
nendip := nendip+((ip + umask) - BITAND (ip, umask));

RETURN substr(startip,2) || '-' || substr(endip,2)||'***'||nstartip||'-'||nendip;

EXCEPTION
WHEN OTHERS
THEN
RETURN NULL;
END;
/
