CREATE procedure sp_check_fluxsum(rtn_code out number,
rtn_info out varchar2)

is
/*
-----------------------????--------------------------------
?????????????DC_Check_FLUXSUM
?????2012-7-21
????: naym
???
*/
v_step number;
v_amount number;
v_status number;
v_oldstatus number;
v_begindate date;
begin
----------------------??????-----------------------------
v_step := 0;
--????????
select count(*)
into v_amount
from circuit ct, fluxd fd
where ct.circuitid = fd.circuitid(+)
and fluxtime = to_char(sysdate - 1, 'YYYYMMDD');

--????????
if (v_amount = 0) then
v_status := 0;
else
v_status := 1;
end if;

--??DC_FuncError?
select count(status)
into v_amount
from dc_funcerror
where checkitemcode = 'FLUXSUM';

--????????
if (v_amount = 0) then
insert into dc_funcerror
values
('FLUXSUM',
sysdate,
sysdate,
v_status,
decode(v_status, 1, '????????', '????????'),
0);
commit;
else
select status, starttime
into v_oldstatus, v_begindate
from dc_funcerror
where checkitemcode = 'FLUXSUM';

if (v_oldstatus = v_status) then
update dc_funcerror
set lastchecktime = sysdate,
duration = (sysdate - nvl(v_begindate, sysdate)) * 24 * 60
where checkitemcode = 'FLUXSUM';
else
update dc_funcerror
set starttime = sysdate,
lastchecktime = sysdate,
status = v_status,
checkresult = decode(v_status,
1,
'????????',
'????????'),
duration = 0
where checkitemcode = 'FLUXSUM';
end if;
end if;

commit;

rtn_code := 0;
rtn_info := '?????';


---------------------????--------------------------------
exception
when others then
rollback;
rtn_code := -1;
rtn_info := '????????(??' || to_char(v_step) || ')?' || sqlcode ||
substr(sqlerrm, 1, 200);

end sp_check_fluxsum;
/
