CREATE FUNCTION GETNEXTID(seqName        varchar2,
                                     columnType     varchar2,
                                     resClass       varchar2,
                                     glideNumLength int) RETURN varchar2 IS
  l_return    varchar2(15);
  dividend    int;
  residue     int;
  format_zero varchar2(15);
BEGIN
  execute immediate 'select ' || seqName || '.nextval   from dual'
    into dividend;
  if upper(columnType) = 'INT' then
    FOR I IN 1 .. glideNumLength LOOP
      format_zero := '0' || format_zero;
    end loop;
    l_return := resClass || trim(to_char(dividend, format_zero));
    return l_return;
  elsif upper(columnType) = 'STRING' then
    FOR I IN 1 .. glideNumLength LOOP
      if dividend != 0 then
        residue  := mod(dividend, 36);
        dividend := trunc(dividend / 36);
        if residue >= 0 and residue <= 9 then
          l_return := to_char(residue) || l_return;
        else
          l_return := chr(87 + residue) || l_return;
        end if;
      else
        l_return := '0' || l_return;
      end if;
    end loop;
    l_return := resClass || l_return;
    return l_return;
  end if;

  RETURN l_return;
EXCEPTION
  WHEN others THEN
    return null;
END;
/
