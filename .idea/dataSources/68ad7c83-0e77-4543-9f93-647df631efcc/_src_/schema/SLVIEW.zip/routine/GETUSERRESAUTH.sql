CREATE FUNCTION GETUSERRESAUTH (
   i_netuserid   IN   VARCHAR2,
   i_resid       IN   VARCHAR2
)
   RETURN VARCHAR2
IS
    /* ??????????????????????????????????CFG-???? VIEW-????? NONE-??? */
   l_result     VARCHAR2 (20);
   l_res        res%ROWTYPE;
   l_authtype   VARCHAR2 (20);
   l_fullnode   VARCHAR2(500) ;
   l_resproptype VARCHAR2(20) ;
BEGIN

    /*??????*/
    SELECT restypeid, nodecodea, nodecodeb,resprop,vendor,b.nodefullcode||'.'||c.nodefullcode
    INTO l_res.restypeid, l_res.nodecodea, l_res.nodecodeb,l_res.resprop,l_res.vendor,l_fullnode
    FROM res a,node b,node c
    WHERE resid = i_resid and a.nodecodea=b.nodecode(+) and a.nodecodeb=c.nodecode(+);

    IF (i_resid like 'DEV%') THEN
        l_resproptype := 'DEVPROP' ;
    ELSIF (i_resid like 'CIR%') THEN
        l_resproptype := 'CIRPROP' ;
    ELSIF (i_resid like 'HOS%') THEN
        l_resproptype := 'HOSTPROP' ;
    ELSE
        l_resproptype := NULL ;
    END IF ;

    l_result := 'NONE' ;

    /*???????????*/
    SELECT min(authtype)
    INTO l_authtype
    FROM userresauth a
    WHERE netuserid=i_netuserid and instr(l_fullnode,a.nodecode)>0 and a.restypeid='ALL';

    /* ??????????????.??????????VIEW??*/
    IF (l_authtype='CFG') THEN
        RETURN 'CFG' ;
    ELSIF (l_authtype='VIEW') THEN
        l_result := 'VIEW' ;
    END IF;

    /* ?????????????*/
    SELECT min(a.authtype)
    INTO l_authtype
    FROM userresauth a
    WHERE a.netuserid=i_netuserid and instr(l_fullnode,a.nodecode)>0
        and l_res.restypeid LIKE a.restypeid||'%' and a.resid='ALL';

    IF (l_authtype='CFG') THEN
        RETURN 'CFG' ;
    ELSIF (l_authtype='VIEW') THEN
        l_result := 'VIEW' ;
    END IF;

    /*??????*/
    SELECT min(a.authtype)
    INTO l_authtype
    FROM userresauth a
    WHERE a.netuserid=i_netuserid and a.resid=i_resid and a.restypeid=l_res.restypeid ;

    IF (l_authtype='CFG') THEN
        RETURN 'CFG' ;
    ELSIF (l_authtype='VIEW') THEN
        l_result := 'VIEW' ;
    END IF;

    /*?TAG????????*/
    SELECT min(a.authtype)
    INTO l_authtype
    FROM userresauth a,restag d
    WHERE a.netuserid=i_netuserid and instr(l_fullnode,a.nodecode)>0
        and  a.resid=d.tag and d.resid=i_resid and a.restypeid='TAG' ;

    IF (l_authtype='CFG') THEN
        RETURN 'CFG' ;
    ELSIF (l_authtype='VIEW') THEN
        l_result := 'VIEW' ;
    END IF;

    /*?????????????*/
    IF (l_resproptype IS NOT NULL) THEN
        SELECT min(a.authtype)
        INTO l_authtype
        FROM userresauth a
        WHERE a.netuserid=i_netuserid and instr(l_fullnode,a.nodecode)>0
            and a.restypeid = l_resproptype
            and a.resid=l_res.resprop ;

        IF (l_authtype='CFG') THEN
            RETURN 'CFG' ;
        ELSIF (l_authtype='VIEW') THEN
            l_result := 'VIEW' ;
        END IF;
    END IF ;

    /*???????????*/
    SELECT min(a.authtype)
    INTO l_authtype
    FROM userresauth a
    WHERE a.netuserid=i_netuserid and instr(l_fullnode,a.nodecode)>0
        and a.restypeid = 'VENDOR' and a.resid=l_res.vendor ;

    IF (l_authtype='CFG') THEN
        RETURN 'CFG' ;
    ELSIF (l_authtype='VIEW') THEN
        l_result := 'VIEW' ;
    END IF;

    RETURN l_result;

EXCEPTION
      WHEN OTHERS THEN
         RETURN ('NONE');

END;
/
