CREATE function func_trans_mask_int2str
(
    i_netmask_int    in number
)
return varchar2 deterministic
is
begin
    return func_trans_ip_int2str(power(2, 32) - power(2, 32 - i_netmask_int));
exception when others then
    return '0.0.0.0';
end func_trans_mask_int2str;

/
