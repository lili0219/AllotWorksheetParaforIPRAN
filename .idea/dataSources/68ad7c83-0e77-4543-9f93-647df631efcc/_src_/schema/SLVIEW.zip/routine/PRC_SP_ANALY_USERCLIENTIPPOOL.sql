CREATE procedure prc_sp_analy_userclientippool
(   --  ????????????????????????
o_retdesc out varchar2
)
as
begin
    -- ?? iviservdetail ????? free?
    delete from ippooladdrdetail ipad
    where ipad.status = 'free'
    or not exists (select 1 from iviservdetail isd where ipad.ipsegment = isd.ipsegment and ipad.status = 'used');
    --  ipad.ipsegment = a.ipsegment ???????????
    merge into ippooladdrdetail ipad
    using (with tmp as(select  ippoolname,custid,row_number()over(partition by ippoolname order by custid) rn
                       from iviserv)
            select distinct isd.ipsegment,
                   substr(fun_transipmask(isd.ipsegment),1,instr(fun_transipmask(isd.ipsegment),'-',1,1) - 1) startip,
                   substr(fun_transipmask(isd.ipsegment),instr(fun_transipmask(isd.ipsegment),'-',1,1) + 1,15) endip,
                   substr(fun_transipmask(isd.ipsegment,2),1,instr(fun_transipmask(isd.ipsegment,2),'-',1,1) - 1) nstartip,
                   substr(fun_transipmask(isd.ipsegment,2),instr(fun_transipmask(isd.ipsegment,2),'-',1,1) + 1,15) nendip,
                   isd.ippoolname,isd.nataddr,isd.deviceid,i.custid
            from iviservdetail isd, tmp i
            where isd.ippoolname = i.ippoolname
            and i.rn = 1
          ) a
    on(ipad.ipsegment =a.ipsegment)
    when matched then
      update set ipad.status = 'used',ipad.ippoolname = a.ippoolname, ipad.nataddr = a.nataddr, ipad.deviceid = a.deviceid,ipad.custid = nvl(a.custid,ipad.custid), ipad.updatetime = sysdate
    when not matched then
      insert (ipad.ipsegment, ipad.ipnum, ipad.startip, ipad.endip, ipad.nstartip, ipad.nendip, ipad.status, ipad.ippoolname, ipad.nataddr, ipad.deviceid, ipad.custid, updatetime)
      values(a.ipsegment,a.nendip - a.nstartip + 1, a.startip, a.endip, a.nstartip, a.nendip, 'used', a.ippoolname, a.nataddr, a.deviceid,a.custid, sysdate
      );
  /*    --??/15???
    merge into ippooladdrdetail b
    using (
    with tmp_secd as(
                      select iad.ipsegment,substr(iad.ipsegment,1,instr(iad.ipsegment,'.',1,1)-1) firstip,substr(iad.ipsegment,instr(iad.ipsegment,'.',1,1)+1,instr(iad.ipsegment,'.',1,2)-instr(iad.ipsegment,'.',1,1)-1) secdip
                      from ippooladdrdetail iad, ippooladdr ia
                      where ia.nstartip <= iad.nstartip
                      and   iad.nendip <=ia.nendip
                      and   iad.ipsegment like '%'||'/15'||'%'
                      ),
            tmp_ip as(
                      select firstip||'.'||case when mod(secdip,2) = 0 then secdip + 1 else secdip - 1 end||'.0.0/16' ipsegment
                      from tmp_secd
                      )
             select i.ipsegment,
                    substr(fun_transipmask(i.ipsegment,2),instr(fun_transipmask(i.ipsegment,2),'-',1,1) + 1) - substr(fun_transipmask(i.ipsegment,2),1,instr(fun_transipmask(i.ipsegment,2),'-',1,1) - 1) + 1 ipnum,
                    substr(fun_transipmask(i.ipsegment),1,instr(fun_transipmask(i.ipsegment),'-',1,1) - 1) startip,
                    substr(fun_transipmask(i.ipsegment),instr(fun_transipmask(i.ipsegment),'-',1,1) + 1) endip,
                    substr(fun_transipmask(i.ipsegment,2),1,instr(fun_transipmask(i.ipsegment,2),'-',1,1) - 1) nstartip,
                    substr(fun_transipmask(i.ipsegment,2),instr(fun_transipmask(i.ipsegment,2),'-',1,1) + 1) nendip
              from  tmp_ip i
           ) a
       on (a.ipsegment = b.ipsegment)
       when not matched then
         insert (b.ipsegment,b.ipnum,b.startip,b.endip,b.nstartip,b.nendip,b.status,b.updatetime)
         values (a.ipsegment,a.ipnum,a.startip,a.endip,a.nstartip,a.nendip,'used',sysdate);
*/
      --?????(status=free)?????????1B?/16??????????ippooladdrdetail?
      merge into ippooladdrdetail b
      using (  with tmp_secd as(
                      select iad.ipsegment,substr(iad.ipsegment,1,instr(iad.ipsegment,'.',1,1)-1) firstip,substr(iad.ipsegment,instr(iad.ipsegment,'.',1,1)+1,instr(iad.ipsegment,'.',1,2)-instr(iad.ipsegment,'.',1,1)-1) secdip
                      from ippooladdrdetail iad, ippooladdr ia
                      where ia.nstartip <= iad.nstartip
                      and   iad.nendip <=ia.nendip
                      and   iad.ipsegment like '%'||'/15'||'%'
                      ),
               tmp_ip as(
                      select secdip firip , case when mod(secdip,2) = 0 then secdip + 1 else secdip - 1 end secdip
                      from tmp_secd
                      ),
      tmp_row as(select rownum - 1 rn from dual connect by rownum <257),
          tmp_ipseg as(
                        select substr(ipa.ipsegment,1,instr(ipa.ipsegment,'.',1,1))||tr.rn  ipflag,
                               substr(ipa.ipsegment,1,instr(ipa.ipsegment,'.',1,1))||tr.rn||'.0.0/16' ipsegment
                        from ippooladdr ipa,tmp_row tr
                        where tr.rn  not in (select secdip from tmp_ip)
                        and tr.rn not in (select firip from tmp_ip)
                        )
       select i.ipflag,i.ipsegment,
              substr(fun_transipmask(i.ipsegment,2),instr(fun_transipmask(i.ipsegment,2),'-',1,1) + 1) - substr(fun_transipmask(i.ipsegment,2),1,instr(fun_transipmask(i.ipsegment,2),'-',1,1) - 1) + 1 ipnum,
              substr(fun_transipmask(i.ipsegment),1,instr(fun_transipmask(i.ipsegment),'-',1,1) - 1) startip,
              substr(fun_transipmask(i.ipsegment),instr(fun_transipmask(i.ipsegment),'-',1,1) + 1) endip,
              substr(fun_transipmask(i.ipsegment,2),1,instr(fun_transipmask(i.ipsegment,2),'-',1,1) - 1) nstartip,
              substr(fun_transipmask(i.ipsegment,2),instr(fun_transipmask(i.ipsegment,2),'-',1,1) + 1) nendip
       from tmp_ipseg i ) a
       on (substr(b.ipsegment,1,instr(b.ipsegment,'.',1,2)-1) = a.ipflag)
       when not matched then
        insert (b.ipsegment,b.ipnum,b.startip,b.endip,b.nstartip,b.nendip,b.status,b.updatetime)
        values (a.ipsegment,a.ipnum,a.startip,a.endip,a.nstartip,a.nendip,'free',sysdate);

 /*     insert into ippooladdrdetail(ipsegment,ipnum,startip,endip,nstartip,nendip,status,updatetime)
      with tmp_row as(select rownum - 1 rn from dual connect by rownum <257),
          tmp_ipseg as(
                        select substr(ipa.ipsegment,1,instr(ipa.ipsegment,'.',1,1))||tr.rn  ipflag,
                               substr(ipa.ipsegment,1,instr(ipa.ipsegment,'.',1,1))||tr.rn||'.0.0/16' ipsegment
                        from ippooladdr ipa,tmp_row tr
                        )
       select i.ipsegment,
              substr(fun_transipmask(i.ipsegment,2),instr(fun_transipmask(i.ipsegment,2),'-',1,1) + 1) - substr(fun_transipmask(i.ipsegment,2),1,instr(fun_transipmask(i.ipsegment,2),'-',1,1) - 1) + 1,
              substr(fun_transipmask(i.ipsegment),1,instr(fun_transipmask(i.ipsegment),'-',1,1) - 1) startip,
              substr(fun_transipmask(i.ipsegment),instr(fun_transipmask(i.ipsegment),'-',1,1) + 1) endip,
              substr(fun_transipmask(i.ipsegment,2),1,instr(fun_transipmask(i.ipsegment,2),'-',1,1) - 1) nstartip,
              substr(fun_transipmask(i.ipsegment,2),instr(fun_transipmask(i.ipsegment,2),'-',1,1) + 1) nendip,
              'free',
              sysdate
       from tmp_ipseg i
       where  not exists(select 1 from ippooladdrdetail ipad where substr(ipad.ipsegment,1,instr(ipad.ipsegment,'.',1,2)-1) = i.ipflag);
 */   
       --??ippooladdr?
       update ippooladdr b set (b.ipsegment,b.ipusednum,b.ippreusednum,b.ipfreenum) =
           (select  a.ipsegment,a.ipusednum,a.ippreusednum,a.ipfreenum
             from (
                  select ipa.ipsegment,
                         sum(case when ipad.status = 'used' then ipad.ipnum else 0 end)  ipusednum,
                         sum(case when ipad.status = 'preused' then ipad.ipnum else 0 end)  ippreusednum,
                         sum(case when ipad.status = 'free' then ipad.ipnum else 0 end)  ipfreenum
                   from ippooladdr ipa, ippooladdrdetail ipad
                   where ipa.nstartip <= ipad.nstartip
                   and   ipad.nendip <= ipa.nendip
                   group by ipa.ipsegment
                   ) a
             where a.ipsegment = b.ipsegment);
       commit;
       o_retdesc:='Succees to analysis !';
exception when others then 
       o_retdesc:= 'Failed ORA--'||sqlcode;
       rollback;
end prc_sp_analy_userclientippool;
/
