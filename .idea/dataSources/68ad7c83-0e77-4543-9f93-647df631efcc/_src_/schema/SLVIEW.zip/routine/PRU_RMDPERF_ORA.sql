CREATE PROCEDURE PRU_RMDPerf_ORA
(
   Method char,
   StartTimeStr char,
   EndTimeStr char
)
AS
StartTime date;
EndTime date;
tmpStartTime date;
tmpEndTime date;
gtmpEndTime date;
tmpStartStr varchar2(14);
tmpEndStr varchar2(14);

BPTime varchar2(10);
BPCount number(1);
ifBP char(1);--????????
ifStat char(1); --????????????????????????????)
HourBP date; --???????????

LastResID char(8);
LastItem varchar(24);
LastPara varchar(255);
LastDayID char(8);

CurResID char(8);
CurItem varchar(24);
CurPara varchar(255);
CurDayID char(8);
ValueData number;
---????
TYPE R_REC IS RECORD(value number(20,4));
TYPE T_REC IS TABLE OF R_REC INDEX BY BINARY_INTEGER;
tmp_value T_REC;

---????
TYPE R_GROUP IS RECORD(value number(10));
TYPE T_GROUP IS TABLE OF R_GROUP INDEX BY BINARY_INTEGER;
resgroup T_GROUP;

num int;
---????????
StatSpan int;

groupindex int;
IndexNum int;
NonBValue numeric;

sql_str varchar2(2000);
type_sql varchar2(500);
type_str varchar2(100);
tmptype varchar2(100);
group_start varchar2(10);
group_end varchar2(10);
group_num number(10);

--??
TYPE tcursor IS REF CURSOR;
cur_record tcursor;

BEGIN
EndTime := sysdate;
StartTime := to_date(to_char(EndTime-1,'yyyymmdd')||'0000','yyyymmddhh24miss');

---????????
select to_number(PARAVALUE) into StatSpan from syspara where PARANAME='PerfCollectDay';
StatSpan := StatSpan - 1;
if StatSpan < 1 then
   StatSpan := 1;
end if;

select count(1) into group_num from ResSumGroup where groupnum<>0;
if group_num=0 then    --???
    resgroup(1).value := 0;
else
    num := 1;
    for g in (select groupnum from ResSumGroup where groupnum<>0) loop
        resgroup(num).value := g.groupnum;
	      num := num+1;
    end loop;
end if;
---???????
groupindex := resgroup.first;
loop
    exit when groupindex is null;
    group_num := resgroup(groupindex).value;
    ifStat := 'Y';
    --????
    select count(*) into BPCount from ressumbp b where b.sumperiodtype='D' and b.sumtype='P' and b.groupnum=group_num;
    if BPCount=0 then
        BPTime := null;
	      ifBP := 'I';
    else
        select b.bpdate into BPTime from ressumbp b where b.sumperiodtype='D' and b.sumtype='P' and b.groupnum=group_num;
	ifBP := 'U';
    end if;

    if Method='CRON' then
       if BPTime is null then
          tmpStartTime := StartTime;
          tmpEndTime := EndTime;
       else
           tmpStartTime := to_date(BPTime,'yyyymmdd');
           tmpEndTime := to_date(to_char(tmpStartTime+StatSpan,'yyyymmdd')||'235959','yyyymmddhh24miss');
	         if tmpEndTime>EndTime then
	            tmpEndTime := EndTime;
	         end if;
       end if;
    elsif Method='SUB' then
       tmpStartTime := to_date(StartTimeStr,'yyyymmdd');
       tmpEndTime := to_date(EndTimeStr||'235959','yyyymmddhh24miss');
       if tmpEndTime>tmpStartTime+StatSpan then
           tmpEndTime := to_date(to_char(tmpStartTime+StatSpan,'yyyymmdd')||'235959','yyyymmddhh24miss');
       end if;
       if tmpEndTime>EndTime then
	         tmpEndTime := EndTime;
       end if;

       ---????????????????????
       select count(*) into BPCount from ressumbp b where b.sumperiodtype='H' and b.sumtype='--' and b.groupnum=group_num;
       if BPCount=1 then
          select to_date(substr(b.bpdate,1,8)||'235959','yyyymmddhh24miss') into HourBP from ressumbp b where b.sumperiodtype='H' and b.sumtype='--' and b.groupnum=group_num;
          if HourBP<tmpStartTime then
              ifStat := 'N';
          else
              if HourBP<tmpEndTime then
                 tmpEndTime := HourBP;
              end if;
          end if;
       end if;

       if to_char(tmpEndTime,'yyyymmdd')<BPTime then
           ifBP := 'N';
       end if;
    end if;

     --??????
   if ifStat='Y' then
    if group_num=0 then
        type_sql := '';
    else
        type_sql := ' AND (';
        select ResType,GroupStart,GroupEnd into type_str,group_start,group_end from ResSumGroup where groupnum=group_num;
        while instr(type_str,',',1)>0 loop
           tmptype := substr(type_str,1,instr(type_str,',',1)-1);
	         type_sql := type_sql||'R.ResID between '''||tmptype||group_start||''' and '''||tmptype||group_end||''' or ';

           type_str := substr(type_str,instr(type_str,',',1)+1,length(type_str)-1-length(tmptype));
        end loop;
	      type_sql := type_sql||'R.ResID between '''||type_str||group_start||''' and '''||type_str||group_end||''')';
    end if;

     ---????
    while tmpStartTime<tmpEndTime loop
        gtmpEndTime := to_date(to_char(tmpStartTime,'yyyymmdd')||'235959','yyyymmddhh24miss');
	      if gtmpEndTime>tmpEndTime then
	         gtmpEndTime := tmpEndTime;
	      end if;

        --??????
	      tmpStartStr := to_char(tmpStartTime,'yyyymmdd');
        sql_str := 'delete from ResMoniDailyInfo R WHERE R.DayID='''||tmpStartStr||''''||type_sql;
	      execute immediate sql_str;

        --??????
	      tmpStartStr := to_char(tmpStartTime,'yyyymmddhh24miss');
	      tmpEndStr := to_char(gtmpEndTime,'yyyymmddhh24miss');
        sql_str := 'INSERT INTO ResMoniDailyInfo(ResID,DerivedItemCode,ItemPara,DayID,Value)
		                (SELECT R.ResID,D.DerivedItemCode,R.ItemPara,to_char(R.RecordTime,''yyyymmdd''),
			                     case D.DerivedType
                           when ''SUM'' then ROUND(SUM(R.Value),4)
                           when ''AVG'' then ROUND(AVG(R.Value),4)
                           when ''MAX'' then ROUND(MAX(R.Value),4)
                           else ROUND(MIN(R.VALUE),4) END
	                   FROM ResMoniRawInfo R,ResMoniDerivedItemCfg D
		                 WHERE R.MoniItemCode=D.MoniItemCode AND D.MinDerivedUnit=''D''
			                 AND D.DerivedType IN (''SUM'',''AVG'',''MAX'',''MIN'')
			                 AND D.moniitemcode NOT IN (''B_CIR_COMValid'',''B_CIR_ATMValid'')
			                 AND R.RecordTime>=to_date('''||tmpStartStr||''',''yyyymmddhh24miss'')
			                 and R.RecordTime<=to_date('''||tmpEndStr||''',''yyyymmddhh24miss'')'||type_sql||'
	                 GROUP BY D.DerivedItemCode,D.MoniItemCode,D.DerivedType,R.ResID,R.ItemPara,to_char(R.RecordTime,''yyyymmdd''))';
	     execute immediate sql_str;

       --????????????
       tmpStartStr := to_char(tmpStartTime,'yyyymmddhh24');
       tmpEndStr := to_char(gtmpEndTime,'yyyymmddhh24');
       sql_str := 'INSERT INTO ResMoniDailyInfo(ResID,DerivedItemCode,ItemPara,DayID,Value)
			            (SELECT R.ResID,D.DerivedItemCode,R.ItemPara,substr(R.HourID,1,8),
			                  case D.DerivedType
                        when ''SUM'' then ROUND(SUM(R.Value),4)
                        when ''AVG'' then ROUND(AVG(R.Value),4)
                        when ''MAX'' then ROUND(MAX(R.Value),4)
                        else ROUND(MIN(R.VALUE),4) END
			             FROM ResMoniHourlyInfo R,ResMoniDerivedItemCfg D
			             WHERE R.DerivedItemCode=D.DerivedItemCode AND R.Value>=0 AND D.MinDerivedUnit=''H''
			              AND D.DerivedType IN (''SUM'',''AVG'',''MAX'',''MIN'')
			              AND D.moniitemcode NOT IN (''B_CIR_COMValid'',''B_CIR_ATMValid'')
			             AND R.HourID>='''||tmpStartStr||''' and R.HourID<='''||tmpEndStr||''''||type_sql||'
                  GROUP BY D.DerivedItemCode,D.DerivedType,R.ResID,R.ItemPara,substr(R.HourID,1,8))';
	      execute immediate sql_str;

        --??????????
	      tmpStartStr := to_char(tmpStartTime,'yyyymmddhh24miss');
	      tmpEndStr := to_char(gtmpEndTime,'yyyymmddhh24miss');
        sql_str := 'INSERT INTO ResMoniDailyInfo(ResID,DerivedItemCode,ItemPara,DayID,Value)
                   ( SELECT R.Resid,
                            D.DerivedItemCode,
                            R.ItemPara,
                            to_char(R.RecordTime,''yyyymmdd''),
                            round(avg(R.Value),4)
  	                 FROM ResMoniRawInfo R,ResMoniDerivedItemCfg D
 	                   WHERE R.MoniItemCode=D.MoniItemCode
                         AND R.Moniitemcode IN (''B_CIR_COMValid'',''B_CIR_ATMValid'')
                         AND R.RecordTime>=to_date('''||tmpStartStr||''',''yyyymmddhh24miss'')
                         AND R.RecordTime<=to_date('''||tmpEndStr||''',''yyyymmddhh24miss'')'||type_sql||'
                      GROUP BY  R.Resid,D.DerivedItemCode,R.ItemPara,to_char(R.RecordTime,''yyyymmdd''))';
         execute immediate sql_str;

         --?????????
         sql_str := 'SELECT R.ResID,D.DerivedItemCode,R.ItemPara,to_char(R.RecordTime,''yyyymmdd''),R.VALUE
		                 FROM ResMoniRawInfo R,ResMoniDerivedItemCfg D
                     WHERE R.MoniItemCode=D.MoniItemCode AND D.MinDerivedUnit=''D''
		                   AND R.Value>=0 AND D.DerivedType=''NONB''
		                   AND R.RecordTime>=to_date('''||tmpStartStr||''',''yyyymmddhh24miss'') AND R.RecordTime<=to_date('''||tmpEndStr||''',''yyyymmddhh24miss'')'||type_sql||'
		                 ORDER BY D.DerivedItemCode,R.ResID,R.ItemPara,to_char(R.RecordTime,''yyyymmdd''),R.VALUE';

         LastResID := 'forbegin';
         open cur_record for sql_str;
         loop
            fetch cur_record into CurResID,CurItem,CurPara,CurDayID,ValueData;
            EXIT WHEN cur_record%NOTFOUND;
            if LastResID = 'forbegin' then --?????
                 num := 1 ;
                 LastResID := CurResID;
                 LastItem := CurItem;
                 LastPara := CurPara;
                 LastDayID := CurDayID;

                 tmp_value(num).value := ValueData;
            elsif LastResID <> CurResID or LastItem <> CurItem or LastPara <> CurPara or LastDayID <> CurDayID then
                  indexNum := round(num*0.95);
                  NonBValue := tmp_value(IndexNum).value;
                  insert into ResMoniDailyInfo(ResID,DerivedItemCode,ItemPara,DayID,Value)
                  values (LastResID,LastItem,LastPara,LastDayID,NonBValue);

                  num := 1 ;
                  LastResID := CurResID;
                  LastItem := CurItem;
                  LastPara := CurPara;
                  LastDayID := CurDayID;

                  tmp_value.delete;
                  tmp_value(num).value := ValueData;
             else
                  num := num + 1;
                  tmp_value(num).value := ValueData;

             end if;

          end loop;
          close cur_record;

          --???????
          if LastResID <> 'forbegin' then
              IndexNum := round(num*0.95);
              NonBValue := tmp_value(IndexNum).value;
              insert into ResMoniDailyInfo(ResID,DerivedItemCode,ItemPara,DayID,Value)
              values (LastResID,LastItem,LastPara,LastDayID,NonBValue);
          end if;

         --????
	       if ifBP='I' then
	           insert into ressumbp(SumPeriodType,sumtype,groupnum,BPDate) values('D','P',group_num,to_char(tmpStartTime,'yyyymmdd'));
	           ifBP := 'U';
	       elsif ifBP='U' then
                   if Method='CRON' or (Method='SUB' and to_char(tmpStartTime,'yyyymmdd')>BPTime) then
	               update ressumbp set BPDate=to_char(tmpStartTime,'yyyymmdd') where sumperiodtype='D' and sumtype='P' and groupnum=group_num;
                   end if;
	       end if;
	       select b.bpdate into BPTime from ressumbp b where b.sumperiodtype='D' and b.sumtype='P' and b.groupnum=group_num;

         commit;  --??
	       tmpStartTime := tmpStartTime+1;
    end loop; --??????
  end if; --??????
    groupindex := resgroup.next(groupindex);
end loop;--??????

END;
/
