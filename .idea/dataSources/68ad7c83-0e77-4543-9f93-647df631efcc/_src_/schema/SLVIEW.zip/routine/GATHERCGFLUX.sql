CREATE procedure GATHERCGFLUX(
myCGNAME in VARCHAR2,
BEGINDATE in VARCHAR2,
MAXGATHERHOUR in VARCHAR2,
acStartTime in out varchar2,
cgBandWidth in out varchar2
)

is

startTime varchar2(12);
endTime varchar2(12);
maxCGTime date;
tempEndTime date;
cginratio number(6,2);
cgoutratio number(6,2);

begin
--??????????????
if length(BEGINDATE) = 12 then
--????????
startTime := BEGINDATE;
endTime := to_char(to_date(startTime, 'yyyymmddhh24mi')+MAXGATHERHOUR/24, 'yyyymmddhh24mi');

delete from flux where circuitid = myCGNAME and fluxtime >= startTime and fluxtime <= endTime;

insert into flux (circuitid, fluxtime, interval, inavgvec, outavgvec, inavgratio, outavgratio)
(select myCGNAME as cgid, f.fluxtime, f.interval,
sum(case when n.nodefullcode like '%'||c3.nodecodea||'%' then f.inavgvec else f.outavgvec end) as cginavg,
sum(case when n.nodefullcode like '%'||c3.nodecodea||'%' then f.outavgvec else f.inavgvec end) as cgoutavg,
sum(case when n.nodefullcode like '%'||c3.nodecodea||'%' then f.inavgvec else f.outavgvec end)/sum(c2.bandwidth)*0.8,
sum(case when n.nodefullcode like '%'||c3.nodecodea||'%' then f.outavgvec else f.inavgvec end)/sum(c2.bandwidth)*0.8
from flux f, cgrelacircuit c, circuit c2, device d, node n, cg c3
where c.cgid = myCGNAME
and c.circuitid = c2.circuitid and c2.changetype = 0
and c.enddate = to_date('21000101000000','yyyymmddhh24miss')
and d.deviceid = c2.adeviceid and d.changetype = 0
and n.nodecode = d.nodecode
and c.cgid = c3.cgid
and c.circuitid = f.circuitid
and f.fluxtime >= startTime and f.fluxtime <= endTime
group by f.fluxtime, f.interval);
else
--????????
tempEndTime := sysdate;
endTime := to_char((tempEndTime - BEGINDATE/(24*3600)), 'yyyymmddhh24mi');

select to_date(max(f.fluxtime), 'yyyymmddhh24mi') into maxCGTime from flux f, cg c
where c.cgid = myCGNAME and f.circuitid = c.cgid;
dbms_output.put_line(maxCGTime);
if maxCGTime is NULL then
--acStartTime := '190001010000';
startTime := '190001010000';
else
startTime := to_char(maxCGTime, 'yyyymmddhh24mi');
end if;

--????????????????????????????
if startTime > endTime then
acStartTime := '';
else
dbms_output.put_line(startTime);
if (to_date(endTime, 'yyyymmddhh24mi') - to_date(startTime, 'yyyymmddhh24mi')) > MAXGATHERHOUR/24 then
endTime := to_char(to_date(startTime, 'yyyymmddhh24mi') + MAXGATHERHOUR/24, 'yyyymmddhh24mi');
end if;

delete from flux where circuitid = myCGNAME and fluxtime >= startTime and fluxtime <= endTime;

for v_result in (select myCGNAME as cgid, f.fluxtime, f.interval,
sum(case when n.nodefullcode like '%'||c3.nodecodea||'%' then f.inavgvec else f.outavgvec end) as cginavg,
sum(case when n.nodefullcode like '%'||c3.nodecodea||'%' then f.outavgvec else f.inavgvec end) as cgoutavg,
sum(c2.bandwidth) as bandwidth
from flux f, cgrelacircuit c, circuit c2, device d, node n, cg c3
where c.cgid = myCGNAME
and c.circuitid = c2.circuitid and c2.changetype = 0
and c.enddate = to_date('21000101000000','yyyymmddhh24miss')
and d.deviceid = c2.adeviceid and d.changetype = 0
and n.nodecode = d.nodecode
and c.cgid = c3.cgid
and c.circuitid = f.circuitid
and f.fluxtime >= startTime
and f.fluxtime <= endTime
group by f.fluxtime, f.interval) loop

begin

cgBandWidth := v_result.bandwidth;
cginratio := v_result.cginavg/v_result.bandwidth*0.8;
cgoutratio := v_result.cgoutavg/v_result.bandwidth*0.8;

insert into flux (circuitid, fluxtime, interval, inavgvec, outavgvec, inavgratio, outavgratio)
values (v_result.cgid,v_result.fluxtime, v_result.interval, v_result.cginavg, v_result.cgoutavg,
cginratio,cgoutratio);
end;
end loop;

acStartTime := startTime;

end if;
end if;

commit;
end GATHERCGFLUX;
/
