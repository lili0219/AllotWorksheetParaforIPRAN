CREATE procedure sp_check_dev_perf(rtn_code out number,
                                              rtn_info out varchar2)

 is
  /*
  -----------------------????--------------------------------
  ?????????????DC_Check_DEV_PERF
  ?????2012-7-21
  ????: naym
  ???
  */
  v_step         number;
  v_cross        number;
  v_sql          varchar2(4000);
  v_moniitemcode varchar2(4000);
begin
  ----------------------??????-----------------------------
  v_step := 0;

  ---??????
  delete from dc_deverrortmp where checkitemcode = 'DEV_PERF';
  commit;
  --????????
  v_step := 1;
  for v_dev in (select distinct devicetypecode
                  from device d, restype r
                 where d.devicetypecode = r.restypeid) loop
    --??????????

    --????????????

    --?????????
    select count(1)
      into v_cross
      from user_tab_columns t
     where t.table_name = 'RESTYPE'
       and t.column_name = 'PERFSTORETYPE';
    v_step := 2;
    if v_cross > 0 then
      ---???????? RESTYPE.PERFSTORETYPE CENTRAL--???SCATTER--??
      select decode(perfstoretype, 'CENTRAL', 0, 'SCATTER', 1)
        into v_cross
        from restype
       where resclassid = 'DEV'
         and restypeid = v_dev.devicetypecode; --??????
    end if;
    v_step := 3;
    ---?????Ip??????????
    insert into dc_deverrortmp
      (deviceid,
       checkitemcode,
       checktime,
       probeip,
       probeno,
       checkresult,
       diagresult)
      select distinct dv.deviceid,
                      'DEV_PERF',
                      sysdate,
                      pt.probeip,
                      rp.groupno,
                      '???????????',
                      ''
        from device dv, resgroup rp, probehost pt
       where substr(dv.moniflag, 2, 1) = 'Y'
         and dv.deviceid = rp.resid(+)
         and rp.probeid = pt.probeid(+)
         and dv.changetype = '0'
         and rp.coltype(+) = 'PERF'
         and dv.devicetypecode = v_dev.devicetypecode
         and (rp.groupno is null or pt.probeid is null);
    v_step := 4;
    ---???????????????
    if v_cross = 0 then
      insert into dc_deverrortmp
        (deviceid,
         checkitemcode,
         checktime,
         probeip,
         probeno,
         checkresult,
         diagresult)
        select deviceid,
               checkitemcode,
               checktime,
               probeip,
               probeno,
               '???????????' || max(result),
               ''
          from (select deviceid,
                       checkitemcode,
                       checktime,
                       probeip,
                       probeno,
                       sys_connect_by_path(moniitemcode, ';') result
                  from (select deviceid,
                               checkitemcode,
                               checktime,
                               probeip,
                               probeno,
                               moniitemcode,
                               rn,
                               lead(rn) over(partition by deviceid order by rn) rn1
                          from (select deviceid,
                                       checkitemcode,
                                       checktime,
                                       probeip,
                                       probeno,
                                       moniitemcode,
                                       row_number() over(order by deviceid, moniitemcode desc) rn
                                  from (select distinct dv.deviceid,
                                                        'DEV_PERF' as checkitemcode,
                                                        sysdate as checktime,
                                                        pt.probeip,
                                                        rp.groupno as probeno,
                                                        rg.moniitemcode
                                          from device            dv,
                                               resgroup          rp,
                                               probehost         pt,
                                               resmoniitemcolcfg rg,
                                               dc_devcolitemlib  dc
                                         where substr(dv.moniflag, 2, 1) = 'Y'
                                           and dv.deviceid = rp.resid
                                           and rp.probeid = pt.probeid
                                           and dv.changetype = '0'
                                           and dv.colitemprofile =
                                               rg.colitemprofile
                                           and rp.coltype = 'PERF'
                                           and dc.devicemodelcode =
                                               dv.devicemodelcode
                                           and dc.itemtype = rp.coltype
                                           and rg.moniitemcode = dc.colitemcode
                                           and dv.devicetypecode =
                                               v_dev.devicetypecode
                                           and not exists
                                         (select 1
                                                  from resmonicurinfo
                                                 where resid like 'DEV%'
                                                   and recordtime >= sysdate - 1
                                                   and resid = dv.deviceid
                                                   and dataitemid =
                                                       rg.moniitemcode))))
                 start with rn1 is null
                connect by rn1 = prior rn)
         group by deviceid, checkitemcode, checktime, probeip, probeno;
    else
      v_step := 5;

      for v_index in (select rp.groupid,
                             restypeid,
                             columnname,
                             t.table_name,
                             moniitemcode
                        from resperfstoregroup     rp,
                             resperfstoregroupitem rs,
                             user_tab_columns      t
                       where rp.groupid = rs.groupid
                         and restypeid = v_dev.devicetypecode
                         and t.table_name = upper(tablename)
                         and t.column_name = upper(columnname)) loop

        v_moniitemcode := v_index.moniitemcode;
        ----????SQL
        v_step := 6;
        v_sql  := 'merge into dc_deverrortmp dc
              using ( select distinct
                              dv.deviceid,
                              ''DEV_PERF'' AS checkitemcode,
                              sysdate AS checktime,
                              pt.probeip,
                              rp.groupno AS probeno,
                              ''???????????:' ||
                  v_moniitemcode || ''' AS checkresult
                         from device dv,
                              resgroup rp,
                              probehost pt,
                              resmoniitemcolcfg rg,
                              dc_devcolitemlib dc
                              where substr(dv.moniflag, 2, 1) = ''Y''
                              and dv.deviceid = rp.resid
                              and rp.probeid = pt.probeid
                              and dv.changetype = ''0''
                              and dv.colitemprofile = rg.colitemprofile
                              and rp.coltype = ''PERF''
                              and dc.devicemodelcode = dv.devicemodelcode
                              and rg.MONIITEMCODE =
                              ''' || v_moniitemcode || '''
                              and dc.itemtype = rp.coltype
                              and dv.devicetypecode =
                              ''' || v_dev.devicetypecode || '''
                              and dc.COLITEMCODE =
                              ''' || v_moniitemcode || '''
                              and not exists
                              (select ' ||
                  v_index.columnname || '
                              from ' || v_index.table_name || '
                              where COLTIME >= sysdate - 1
                              and resid = dv.deviceid
                              and ' || v_index.columnname ||
                  ' is not null )) dv on (dc.deviceid = dv.deviceid
                            and dc.checkitemcode = dv.checkitemcode)
                           when matched then
                         update set dc.checkresult = dc.checkresult||'';' ||
                  v_moniitemcode || '''
                           when not matched then
                           insert
                             (dc.deviceid,
                              dc.checkitemcode,
                              dc.checktime,
                              dc.probeip,
                              dc.probeno,
                              dc.checkresult)
                           values
                             (dv.deviceid,
                              dv.checkitemcode,
                              dv.checktime,
                              dv.probeip,
                              dv.probeno,
                              dv.checkresult)';

        execute immediate v_sql;
      end loop;
    end if;
  end loop;
  commit;

  rtn_code := 0;
  rtn_info := '?????';
  ---------------------????--------------------------------
exception
  when others then
    rollback;
    rtn_code := -1;
    rtn_info := '????????(??' || to_char(v_step) || ')?' || sqlcode ||
                substr(sqlerrm, 1, 200);

end sp_check_dev_perf;
/
