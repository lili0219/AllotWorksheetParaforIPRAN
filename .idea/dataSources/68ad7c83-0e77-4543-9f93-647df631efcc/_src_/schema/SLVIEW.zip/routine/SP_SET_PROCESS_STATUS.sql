CREATE PROCEDURE SP_SET_PROCESS_STATUS(IN_SP_NAME    IN VARCHAR2,
                                                  IN_STAT_DATA  IN VARCHAR2,
                                                  IN_PARTION_ID IN NUMBER,
                                                  IN_STATUS     IN NUMBER,
                                                  IN_STEP_ID    IN NUMBER) IS
  /*
  * ?    ?: ?????????????
  * @author ???
  * @date   2011-10-25
  * @param    in_sp_name     ??????
  * @param    in_stat_data   ????????
  * @param    in_partion_id  ????
  * @param    in_status      ????
  */
  CONST_DOING CONSTANT NUMBER := 8;
  CONST_OK    CONSTANT NUMBER := 0;
  V_ERRORINFO VARCHAR2(200);
BEGIN
  UPDATE MD_PROCESS_CONTROL
     SET STATUS = IN_STATUS
   WHERE TRIM(UPPER(PROCESS_NAME)) = TRIM(UPPER(IN_SP_NAME))
     AND STAT_DATA = IN_STAT_DATA
     AND PARTION_ID = IN_PARTION_ID;
  IF (SQL%ROWCOUNT = 0) THEN
    ---sql??????
    INSERT INTO MD_PROCESS_CONTROL
      (PROCESS_NAME, STAT_DATA, PARTION_ID, STATUS, FIRST_TIME, STEP_ID)
    VALUES
      (UPPER(IN_SP_NAME),
       IN_STAT_DATA,
       IN_PARTION_ID,
       IN_STATUS,
       SYSDATE,
       IN_STEP_ID);
  END IF;

  IF IN_STATUS = CONST_DOING THEN
    IF IN_STEP_ID = 0 THEN
      ----???????????---
      UPDATE MD_PROCESS_CONTROL
         SET START_TIME  = SYSDATE,
             END_TIME    = NULL,
             RUN_SECONDS = 0,
             STEP_ID     = IN_STEP_ID
       WHERE TRIM(UPPER(PROCESS_NAME)) = TRIM(UPPER(IN_SP_NAME))
         AND STAT_DATA = IN_STAT_DATA
         AND PARTION_ID = IN_PARTION_ID;
    ELSE
      UPDATE MD_PROCESS_CONTROL
         SET END_TIME = NULL, RUN_SECONDS = 0, STEP_ID = IN_STEP_ID
       WHERE TRIM(UPPER(PROCESS_NAME)) = TRIM(UPPER(IN_SP_NAME))
         AND STAT_DATA = IN_STAT_DATA
         AND PARTION_ID = IN_PARTION_ID;
    END IF;
  END IF;
  IF IN_STATUS < CONST_OK THEN
    V_ERRORINFO := SUBSTR(SQLERRM, 1, 80);
    UPDATE MD_PROCESS_CONTROL
       SET RUN_SECONDS = (SYSDATE - NVL(START_TIME, SYSDATE)) * 24 * 60 * 60,
           END_TIME    = SYSDATE,
           ERROR_MSG   = V_ERRORINFO,
           STEP_ID     = IN_STEP_ID
     WHERE TRIM(UPPER(PROCESS_NAME)) = TRIM(UPPER(IN_SP_NAME))
       AND STAT_DATA = IN_STAT_DATA
       AND PARTION_ID = IN_PARTION_ID;
  END IF;
  IF IN_STATUS = CONST_OK THEN
    UPDATE MD_PROCESS_CONTROL
       SET RUN_SECONDS = (SYSDATE - NVL(START_TIME, SYSDATE)) * 24 * 60 * 60,
           END_TIME    = SYSDATE,
           ERROR_MSG   = '????????',
           STEP_ID     = IN_STEP_ID
     WHERE TRIM(UPPER(PROCESS_NAME)) = TRIM(UPPER(IN_SP_NAME))
       AND STAT_DATA = IN_STAT_DATA
       AND PARTION_ID = IN_PARTION_ID;
  END IF;
  COMMIT;
END SP_SET_PROCESS_STATUS;
/
