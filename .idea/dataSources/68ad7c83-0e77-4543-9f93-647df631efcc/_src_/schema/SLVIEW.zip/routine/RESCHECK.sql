CREATE PROCEDURE rescheck
   (    o_result out varchar2,
        i_refclass IN varchar2 DEFAULT 'ALL')
   IS
    l_nodecodea res.nodecodea%type;
    l_nodecodeb res.nodecodeb%type;
    l_ipaddressa res.ipaddressa%type;
    l_ipaddressb res.ipaddressb%type;
    l_deviceid res.resid%type;
    l_result integer;
    l_hastable integer;
BEGIN

    /*??????????,?????????*/
    begin
        select 1 into l_result
        from user_tables
        where table_name = 'TMP_RESCHECK';
    exception
        when no_data_found then
            l_result := 0;
    end ;

    if (l_result = 0) then
        execute immediate 'create table tmp_Rescheck  (
                           ResID              CHAR(8)                          not null,
                           ResName            VARCHAR2(255)                    not null,
                           ResTypeID          VARCHAR2(20)                     not null,
                           NodeCodeA          CHAR(6),
                           NodeCodeB          CHAR(6),
                           IPAddressA         VARCHAR2(45),
                           IPAddressB         VARCHAR2(45),
                           Remark             VARCHAR2(500),
                           constraint PK_tmp_REScheck primary key (ResID)
                        ) ' ;

        execute immediate 'create index ind_tmp_rescheck_restype on tmp_Rescheck (
                           ResTypeID ASC,
                           NodeCodeA ASC
                        )' ;
    else
        execute immediate 'truncate table tmp_rescheck' ;
    end if;


    begin
        select 1 into l_result
        from tab
        where tname = 'TMP_RESCHECKRESULT' ;
    exception
        when no_data_found then
            l_result := 0 ;
    end ;

    if (l_result = 0) then
        execute immediate 'create table tmp_Rescheckresult  (
                       ResID              CHAR(8)       ,
                       ResName            VARCHAR2(255) ,
                       ResTypeID          VARCHAR2(20)  ,
                       NodeCodeA          CHAR(6),
                       NodeCodeB          CHAR(6),
                       IPAddressA         VARCHAR2(45),
                       IPAddressB         VARCHAR2(45),
                       Remark             VARCHAR2(500),
                       rawResID              CHAR(8)       ,
                       rawResName            VARCHAR2(255) ,
                       rawResTypeID          VARCHAR2(20)  ,
                       rawNodeCodeA          CHAR(6),
                       rawNodeCodeB          CHAR(6),
                       rawIPAddressA         VARCHAR2(45),
                       rawIPAddressB         VARCHAR2(45),
                       rawRemark             VARCHAR2(500)
                    ) ' ;
    else
        execute immediate 'truncate table tmp_rescheckresult' ;
    end if;

    /*??????*/
    if (i_refclass in ('ALL','DEV')) then
        execute immediate 'insert into tmp_rescheck(resid,resname,restypeid,nodecodea,nodecodeb,ipaddressa,ipaddressb,remark)
            select deviceid,devicename,devicetypecode,nodecode,null,loopaddress,null,remark
            from device
            where changetype = 0' ;

        /*??NETFLOW??*/
        begin
            select 1 into l_hastable
            from user_tables
            where table_name = 'FLOWMONISCHEME' ;
        exception
            when no_data_found then
                l_hastable := 0 ;
        end ;
        if (l_hastable = 1) then
            execute immediate 'insert into tmp_rescheck(resid,resname,restypeid,nodecodea) values(''NFW00001'',''netflow??'',''DEV_IP_R'',''NOD999'')' ;
        end if;
    end if;

    /*??????*/
    if (i_refclass in ('ALL','HOS')) then
        execute immediate 'insert into tmp_rescheck(resid,resname,restypeid,nodecodea,nodecodeb,ipaddressa,ipaddressb)
            select hostid,hostname,hosttypecode,nodecode,null,ipaddress,null
            from host
            where changetype = 0' ;
    end if;

    /*??????*/
    if (i_refclass in ('ALL','APP')) then
        begin
            select 1 into l_hastable
            from user_tables
            where table_name = 'APPINFO' ;
        exception
            when no_data_found then
                l_hastable := 0 ;
        end ;
        if (l_hastable = 1) then
            execute immediate 'insert into tmp_rescheck(resid,resname,restypeid,nodecodea,nodecodeb,ipaddressa,ipaddressb)
                select appid,appname,apptypeid,nodecode,null,ipaddress,null
                from appinfo
                where validflag = 0' ;
        end if;
    end if;

    /*???????*/
    if (i_refclass in ('ALL','CIG')) then
         begin
            select 1 into l_hastable
            from user_tables
            where table_name = 'CG' ;
        exception
            when no_data_found then
                l_hastable := 0 ;
        end ;
        if (l_hastable = 1) then
           execute immediate 'insert into tmp_rescheck(resid,resname,restypeid,nodecodea,nodecodeb,ipaddressa,ipaddressb,remark)
                select a.cgid,a.cgname,''CIG_COM'',a.nodecodea,a.nodecodeb,null,null,a.remark
                from cg a ';
         end if;
    end if;

    /*??????*/
    if (i_refclass in ('ALL','CIR')) then
        for l_rec in (select circuitid,circuitname,circuittypecode,adeviceid,aintdescr,bdeviceid,bintdescr
                      from circuit
                      where changetype=0) loop
            /*??A????IP??*/
            begin
                select nodecode into l_nodecodea
                from device
                where deviceid = l_rec.adeviceid and changetype = 0 ;
            exception
                when no_data_found then
                    l_nodecodea := null;
            end ;

            begin
                select ipaddress into l_ipaddressa
                from devaddr
                where deviceid = l_rec.adeviceid
                    and intdescr = l_rec.aintdescr
                    and changetype = 0
                    and seqnum = 0;
            exception
                when no_data_found then
                    l_ipaddressa := null;
            end ;

            /*??B????IP??*/
            if (l_rec.bdeviceid is not null) then
                begin
                    select nodecode into l_nodecodeb
                    from device
                    where deviceid = l_rec.bdeviceid and changetype = 0 ;
                exception
                    when no_data_found then
                        l_nodecodeb := null;
                end ;

                begin
                    select ipaddress into l_ipaddressb
                    from devaddr
                    where deviceid = l_rec.bdeviceid
                        and intdescr = l_rec.bintdescr
                        and changetype = 0
                        and seqnum = 0;
                exception
                    when no_data_found then
                        l_ipaddressb := null;
                end ;
            else
                l_nodecodeb := null;
                l_ipaddressb := null;
            end if;

            /*????*/
            execute immediate 'insert into tmp_rescheck(resid,resname,restypeid,nodecodea,nodecodeb,ipaddressa,ipaddressb)
                values (:1,:2,:3,:4,:5,:6,:7)'
                using l_rec.circuitid,l_rec.circuitname,l_rec.circuittypecode,l_nodecodea,l_nodecodeb,l_ipaddressa,l_ipaddressb;
        end loop;
    end if;

    /*??????*/
    if (i_refclass in ('ALL','PTH')) then
        begin
            select 1 into l_hastable
            from user_tables
            where table_name = 'PATH' ;
        exception
            when no_data_found then
                l_hastable := 0 ;
        end ;
        if (l_hastable = 1) then
            /*????*/
            execute immediate 'insert into tmp_rescheck(resid,resname,restypeid,nodecodea,nodecodeb,ipaddressa,ipaddressb)
                select a.pathid,a.pathname,a.pathtypeid,d.nodecode,e.nodecode,d.loopaddress,nvl(e.loopaddress,c.ipaddress)
                from path a,endpoint b,endpoint c,device d,device e
                where a.startpointid = b.endpointid and a.endpointid = c.endpointid
                    and b.deviceid = d.deviceid(+) and b.changetype = d.changetype(+)
                    and c.deviceid = e.deviceid(+) and c.changetype = e.changetype(+)
                    and a.changetype=0 and b.changetype=0 and c.changetype = 0 ' ;
        end if;
    end if;

    /*????????*/
    if (i_refclass in ('ALL','CTY')) then
        begin
            select 1 into l_hastable
            from user_tables
            where table_name = 'AREATESTPATH' ;
        exception
            when no_data_found then
                l_hastable := 0 ;
        end ;
        if (l_hastable = 1) then
            /*????*/
            execute immediate 'insert into tmp_rescheck(resid,resname,restypeid,nodecodea,nodecodeb,ipaddressa,ipaddressb)
                select a.citycode,a.cityname,''CTY_COM'',b.nodecode,null,b.loopaddress,a.destip
                from areatestpath a,device b
                where a.startroutercode = b.deviceid(+) and a.changetype = b.changetype(+)
                    and a.changetype = 0 ';
        end if;
    end if;

    /*??????*/
    if (i_refclass in ('ALL','ROU')) then
        /*traceroute*/
        begin
            select 1 into l_hastable
            from user_tables
            where table_name = 'TRACEROUTECFG' ;
        exception
            when no_data_found then
                l_hastable := 0 ;
        end ;
        if (l_hastable = 1) then
            /*????*/
            execute immediate 'insert into tmp_rescheck(resid,resname,restypeid,nodecodea,nodecodeb,ipaddressa,ipaddressb)
                select a.routeid,a.routename,''ROU_TRACEROUTE'',b.nodecode,null,b.loopaddress,a.oppositeip
                from traceroutecfg a,device b
                where a.deviceid = b.deviceid(+) and a.changetype = b.changetype(+)
                    and a.changetype = 0 ';
        end if;

        /*bgpnei*/
        begin
            select 1 into l_hastable
            from user_tables
            where table_name = 'BGPNEICFG' ;
        exception
            when no_data_found then
                l_hastable := 0 ;
        end ;
        if (l_hastable = 1) then
            /*????*/
            execute immediate 'insert into tmp_rescheck(resid,resname,restypeid,nodecodea,nodecodeb,ipaddressa,ipaddressb)
                select a.neiid,a.neiname,''ROU_BGPNEI'',b.nodecode,null,b.loopaddress,a.neiip
                from bgpneicfg a,device b
                where a.deviceid = b.deviceid(+) and a.changetype = b.changetype(+)
                    and a.changetype = 0 ';
        end if;

    end if;

    /*??VPN???????*/
    if (i_refclass in ('ALL','RTB')) then
        /*VpnRouteTableMoni*/
        begin
            select 1 into l_hastable
            from user_tables
            where table_name = 'VPNROUTETABLEMONICFG' ;
        exception
            when no_data_found then
                l_hastable := 0 ;
        end ;
        if (l_hastable = 1) then
            /*????*/
            execute immediate 'insert into tmp_rescheck(resid,resname,restypeid,nodecodea,nodecodeb,ipaddressa,ipaddressb)
                select a.VpnRouteTableID,a.VpnRouteTableName,''RTB_VPN'',b.nodecode,null,b.loopaddress,null
                from VpnRouteTableMoniCfg a,device b, Pe p
                where p.deviceid = b.deviceid(+) and nvl(b.changetype,0)=0 and p.peid=a.peid
                    and a.ValidFlag = 0 ';

        end if;

    end if;

    /*??TUNNEL??*/
    if (i_refclass in ('ALL','TET')) then
        begin
            select 1 into l_hastable
            from user_tables
            where table_name = 'MPLSTETINFO' ;
        exception
            when no_data_found then
                l_hastable := 0 ;
        end ;
        if (l_hastable = 1) then
            /*????*/
            execute immediate 'insert into tmp_rescheck(resid,resname,restypeid,nodecodea,nodecodeb,ipaddressa,ipaddressb)
                select a.tetid,a.tetcname,''TET_IP_COM'',b.nodecode,null,a.aaddress,a.baddress
                from mplstetinfo a,device b
                where a.adeviceid = b.deviceid(+) and a.changetype = b.changetype(+)
                    and a.changetype = 0 ';
        end if;

    end if;

    commit;

    l_result := 0 ;

    /*??*/
    /*RES?,????*/
    if (i_refclass = 'ALL') then
       execute immediate 'insert into tmp_rescheckresult(resid,resname,restypeid,nodecodea,nodecodeb,ipaddressa,ipaddressb,remark)
            select resid,resname,restypeid,nodecodea,nodecodeb,ipaddressa,ipaddressb,remark
            from res a
            where not exists (select resid from tmp_rescheck where resid = a.resid)' ;
    else
       execute immediate 'insert into tmp_rescheckresult(resid,resname,restypeid,nodecodea,nodecodeb,ipaddressa,ipaddressb,remark)
            select resid,resname,restypeid,nodecodea,nodecodeb,ipaddressa,ipaddressb,remark
            from res a
            where a.restypeid in (select restypeid from restype where resclassid=:1)
             and not exists (select resid from tmp_rescheck where resid = a.resid)' using i_refclass;
    end if;
    l_result := l_result + sql%rowcount;

    /*????RES??*/
    execute immediate 'insert into tmp_rescheckresult(rawresid,rawresname,rawrestypeid,rawnodecodea,rawnodecodeb,rawipaddressa,rawipaddressb,rawremark)
        select resid,resname,restypeid,nodecodea,nodecodeb,ipaddressa,ipaddressb,remark
        from tmp_rescheck a
        where not exists (select resid from res where resid = a.resid)' ;
    l_result := l_result + sql%rowcount;

     /*??*/
    execute immediate 'insert into tmp_rescheckresult(resid,resname,restypeid,nodecodea,nodecodeb,ipaddressa,ipaddressb,remark,rawresid,rawresname,rawrestypeid,rawnodecodea,rawnodecodeb,rawipaddressa,rawipaddressb,rawremark)
        select a.resid,a.resname,a.restypeid,a.nodecodea,a.nodecodeb,a.ipaddressa,a.ipaddressb,a.remark,
            b.resid,b.resname,b.restypeid,b.nodecodea,b.nodecodeb,b.ipaddressa,b.ipaddressb,b.remark
        from res a,tmp_rescheck b
        where a.resid = b.resid
            and (a.resname != b.resname or a.restypeid != b.restypeid
                 or nvl(a.nodecodea,''NONE'') != nvl(b.nodecodea,''NONE'')
                 or nvl(a.nodecodeb,''NONE'') != nvl(b.nodecodeb,''NONE'')
                 or nvl(a.remark,''NONE'') != nvl(b.remark,''NONE'')
                 or nvl(a.ipaddressa,''NONE'') != nvl(b.ipaddressa,''NONE'')
                 or nvl(a.ipaddressb,''NONE'') != nvl(b.ipaddressb,''NONE''))'  ;
    l_result := l_result + sql%rowcount;

    commit ;

    if (l_result=0) then
        o_result := 'OK';
    else
        o_result := 'ERROR COUNT:' || to_char(l_result) || ' please check table tmp_rescheckresult get detail' ;
    end if ;

END;
/
