CREATE FUNCTION USERNODEAUTH
  ( i_netuserid IN varchar2,
    i_nodecode IN varchar2 DEFAULT null,
    i_authtype IN varchar2 DEFAULT 'CFG'
    )
  RETURN  nodeauthresult IS

   l_result nodeauthresult;
   l_returnresult nodeauthresult;
   type t_refcursor is ref cursor ;
   c_nodelist t_refcursor;
   l_nodecode node.nodecode%type;

BEGIN
    /*????????*/
    l_result := nodeauthresult();

    /*???????*/
    if upper(i_authtype) = 'CFG' then
        open c_nodelist for select distinct nodecode from userresauth
            where netuserid = i_netuserid and authtype='CFG'
              and restypeid = 'ALL';
    /*???????(?????????????)*/
    elsif upper(i_authtype) = 'VIEW' then
        open c_nodelist for select distinct nodecode from userresauth
            where netuserid = i_netuserid and authtype in ('CFG','VIEW')
              and restypeid = 'ALL';
    /*???????*/
    elsif upper(i_authtype) = 'REF' then
        open c_nodelist for select distinct nodecode from userresauth
            where netuserid = i_netuserid ;
    /*????*/
    else
        return (null) ;
    end if ;

    /*??????????*/
    loop
        fetch c_nodelist into l_nodecode;
        exit when c_nodelist%notfound ;
        for l_rec1 in (select nodecode from node start with nodecode=l_nodecode
                            connect by prior nodecode = fathernodecode ) loop
            l_result.extend;
            l_result(l_result.last) := nodeauth(l_rec1.nodecode);
        end loop;
    end loop;
    close c_nodelist;

    begin
        l_returnresult := nodeauthresult();
        /*?????????????DISTINCT???*/
        if i_nodecode is null then
            open c_nodelist for select distinct nodecode  from table(cast(l_result as nodeauthresult));
        /*???????????????????????????*/
        else
            open c_nodelist for select nodecode  from table(cast(l_result as nodeauthresult))
                intersect select nodecode from node start with nodecode=i_nodecode
                connect by prior nodecode = fathernodecode ;
        end if;
        loop
            fetch c_nodelist into l_nodecode;
            exit when c_nodelist%notfound ;
            l_returnresult.extend;
            l_returnresult(l_returnresult.last) := nodeauth(l_nodecode);
        end loop;
        close c_nodelist;
        RETURN l_returnresult ;
    end ;

END;
/
