CREATE PROCEDURE ipprefixresolve
( p_ipprefix IN VARCHAR2 ,
p_nstartip OUT number,
p_nstoptip OUT number)
IS
l_return number;
l_begin integer;
l_end integer;
l_segint integer;
l_prefix number;
l_ipaddr varchar2(50);
l_ipversion varchar2(10) ;
l_count integer ;
l_padstr varchar2(50) ;
BEGIN
p_nstartip := NULL ;
p_nstoptip := NULL ;
if p_ipprefix is null then
return ;
end if;

if p_ipprefix like '%:%' then
l_ipversion := 'IPV6' ;
else
l_ipversion := 'IPV4' ;
end if ;

if l_ipversion='IPV4' then
l_prefix := to_number(substrb(p_ipprefix,instrb(p_ipprefix,'/')+1)) ;
if l_prefix<0 or l_prefix>32 then
return ;
end if ;

l_begin := 1;
l_return := 0;
l_ipaddr := substrb(p_ipprefix,1,instrb(p_ipprefix,'/')-1) ;
for i in 1..3 loop
l_end := instrb(l_ipaddr,'.',l_begin);
if l_end = 0 then
return ;
end if;
l_segint:=to_number(substrb(l_ipaddr,l_begin,l_end-l_begin),'999');
if (l_segint<0 or l_segint>255) then
return ;
end if;
l_return := l_return + l_segint * power(256,4-i);
l_begin := l_end + 1;
end loop;
l_segint:=to_number(substrb(l_ipaddr,l_begin),'999');
if (l_segint<0 or l_segint>255) then
return ;
end if;

l_return := l_return + l_segint;

p_nstartip := floor(l_return/power(2,32-l_prefix)) * power(2,32-l_prefix);
p_nstoptip := p_nstartip + power(2,32-l_prefix) - 1 ;

else
l_prefix := to_number(substrb(p_ipprefix,instrb(p_ipprefix,'/')+1)) ;
if l_prefix<0 or l_prefix>128 then
return ;
end if ;

l_ipaddr := substrb(p_ipprefix,1,instrb(p_ipprefix,'/')-1) ;
if l_ipaddr like '%::%' then
l_count := 0 ;
l_padstr := '0' ;
for i in 1..length(l_ipaddr) loop
if substrb(l_ipaddr,i,1)=':' then
l_count := l_count + 1 ;
end if ;
end loop ;
for i in 1..7-l_count loop
l_padstr := l_padstr || ':0' ;
end loop ;
l_ipaddr := replace(l_ipaddr,'::',':'||l_padstr||':') ;
end if ;
if (substrb(l_ipaddr,1,1)=':') then
l_ipaddr:='0'||l_ipaddr ;
end if ;
if (substrb(l_ipaddr,-1,1)=':') then
l_ipaddr:=l_ipaddr||'0' ;
end if ;
l_begin := 1;
l_return := 0;
for i in 1..7 loop
l_end := instrb(l_ipaddr,':',l_begin);
if l_end = 0 then
return ;
end if;
l_segint:=to_number(substrb(l_ipaddr,l_begin,l_end-l_begin),'xxxx');
l_return := l_return + l_segint * power(65536,8-i);
l_begin := l_end + 1;
end loop;
l_return := l_return + to_number(substrb(l_ipaddr,l_begin),'xxxx');
p_nstartip := floor(l_return/power(2,128-l_prefix)) * power(2,128-l_prefix);
p_nstoptip := p_nstartip + power(2,128-l_prefix) - 1 ;

end if ;



RETURN ;
EXCEPTION
WHEN others THEN
return ;
END;
/
