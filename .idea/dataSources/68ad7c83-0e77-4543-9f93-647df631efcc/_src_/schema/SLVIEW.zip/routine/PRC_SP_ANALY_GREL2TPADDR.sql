CREATE procedure prc_sp_analy_grel2tpaddr
(-- ??apntunnelinfo? greinneraddrdetail?????????????apntunnelinfo.inneripseg?greinneraddrdetail.ipsegment
o_retdesc out varchar2
)
as
begin

update l2tpaddrdetail g -- apntunnelinfo???greinneraddrdetail????greinneraddrdetail?????
set g.status = 'free', g.deviceid = '', g.custid = '', g.wsnbr = '', g.updatetime = sysdate
where g.status = 'used'
and not exists (select 1 from apntunnelinfo a where a.l2tplocaladdr = g.startip);

merge into l2tpaddrdetail g
using (with tmp_ip as(
select l2tplocaladdr ,count(*) cou
from apntunnelinfo
where l2tplocaladdr is not null
group by l2tplocaladdr having count(*) > 1
),
tmp_apntunnelinfo as (select ai.deviceid, ai.custid,
ai.l2tplocaladdr,
substr(fun_transipmask(ai.l2tplocaladdr),1,instr(fun_transipmask(ai.l2tplocaladdr),'-',1,1)-1) startip,
substr(fun_transipmask(ai.l2tplocaladdr),instr(fun_transipmask(ai.l2tplocaladdr),'-',1,1)+1) endip
from apntunnelinfo ai
where ai.l2tplocaladdr is not null
and not exists(select 1 from tmp_ip where ai.l2tplocaladdr = tmp_ip.l2tplocaladdr))
select distinct deviceid, custid,
l2tplocaladdr,
startip,endip,
func_trans_ip_str2int(startip) nstartip,
func_trans_ip_str2int(endip) nendip
from tmp_apntunnelinfo) a
on (a.l2tplocaladdr = g.ipsegment)
when matched then-- apntunnelinfo??greinneraddrdetail?????greinneraddrdetail?????
update set g.status = 'used', g.deviceid = a.deviceid, g.custid = a.custid, g.updatetime = sysdate
when not matched then-- apntunnelinfo??greinneraddrdetail????greinneraddrdetail???????
insert (g.deviceid, g.custid, g.ipsegment, g.ipnum,
g.startip, g.endip, g.nstartip, g.nendip, g.status, g.updatetime)
values (a.deviceid, a.custid, a.l2tplocaladdr, a.nendip-a.nstartip+1,
a.startip, a.endip, a.nstartip, a.nendip, 'used', sysdate);
commit;
o_retdesc := 'Succeed';

exception when others then
o_retdesc := 'Failed ORA-'||sqlcode;
rollback;
end prc_sp_analy_grel2tpaddr;
/
