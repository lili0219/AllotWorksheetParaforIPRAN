CREATE PROCEDURE PRU_RMDValid_ORA
(
   Method char,
   StartTimeStr char,
   EndTimeStr char
)
AS
StartTime date;
EndTime date;
tmpStartTime date;
tmpEndTime date;
gtmpEndTime date;
tmpStartStr varchar2(14);
tmpEndStr varchar2(14);

BPTime varchar2(10);
BPCount number(1);
ifBP char(1);--????????
ifStat char(1); --????????????????????????????)
HourBP date; --???????????

lastResID varchar2(10);
beginRecordTime date;
lastDerivedItemcode varchar2(255);
lastValue int;

curResID char(8);
curRecordTime date;
curDerivedItemcode varchar2(255);
curValue int;

---????
TYPE R_GROUP IS RECORD(value number(10));
TYPE T_GROUP IS TABLE OF R_GROUP INDEX BY BINARY_INTEGER;
resgroup T_GROUP;

num int;
---????????
StatSpan int;

sql_str varchar2(2000);
type_sql varchar2(500);
type_str varchar2(100);
tmptype varchar2(10);
group_start varchar2(10);
group_end varchar2(10);
group_num number(10);

--??
TYPE tcursor IS REF CURSOR;
cur_record tcursor;

BEGIN
EndTime := sysdate;
StartTime := to_date(to_char(EndTime-1,'yyyymmdd')||'0000','yyyymmddhh24miss');

---????????
select to_number(PARAVALUE) into StatSpan from syspara where PARANAME='PerfCollectDay';
StatSpan := StatSpan - 1;
if StatSpan < 1 then
   StatSpan := 1;
end if;

select count(1) into group_num from ResSumGroup where groupnum<>0;
if group_num=0 then    --???
    resgroup(1).value := 0;
else
    num := 1;
    for g in (select groupnum from ResSumGroup where groupnum<>0) loop
        resgroup(num).value := g.groupnum;
	num := num+1;
    end loop;
end if;
---???????
num := resgroup.first;
loop
    exit when num is null;
    group_num := resgroup(num).value;
    ifStat := 'Y';

    --????
    select count(*) into BPCount from ressumbp b where b.sumperiodtype='D' and b.sumtype='V' and b.groupnum=group_num;
    if BPCount=0 then
        BPTime := null;
	      ifBP := 'I';
    else
        select b.bpdate into BPTime from ressumbp b where b.sumperiodtype='D' and b.sumtype='V' and b.groupnum=group_num;
	      ifBP := 'U';
    end if;

    if Method='CRON' then
       if BPTime is null then
          tmpStartTime := StartTime;
          tmpEndTime := EndTime;
       else
           tmpStartTime := to_date(BPTime,'yyyymmdd');
           tmpEndTime := to_date(to_char(tmpStartTime+StatSpan,'yyyymmdd')||'235959','yyyymmddhh24miss');
	         if tmpEndTime>EndTime then
	            tmpEndTime := EndTime;
	         end if;
       end if;
    elsif Method='SUB' then
       tmpStartTime := to_date(StartTimeStr,'yyyymmdd');
       tmpEndTime := to_date(EndTimeStr||'235959','yyyymmddhh24miss');
       if tmpEndTime>tmpStartTime+StatSpan then
           tmpEndTime := to_date(to_char(tmpStartTime+StatSpan,'yyyymmdd')||'235959','yyyymmddhh24miss');
       end if;
       if tmpEndTime>EndTime then
	        tmpEndTime := EndTime;
       end if;

       ---????????????????????
       select count(*) into BPCount from ressumbp b where b.sumperiodtype='H' and b.sumtype='--' and b.groupnum=group_num;
       if BPCount=1 then
          select to_date(substr(b.bpdate,1,8)||'235959','yyyymmddhh24miss') into HourBP from ressumbp b where b.sumperiodtype='H' and b.sumtype='--' and b.groupnum=group_num;
          if HourBP<tmpStartTime then
              ifStat := 'N';
          else
              if HourBP<tmpEndTime then
                 tmpEndTime := HourBP;
              end if;
          end if;
       end if;

       if to_char(tmpEndTime,'yyyymmdd')<BPTime then
           ifBP := 'N';
       end if;
    end if;

    --??????
   if ifStat='Y' then
    if group_num = 0 then
        type_sql := '';
    else
        type_sql := ' AND (';
        select ResType,GroupStart,GroupEnd into type_str,group_start,group_end from ResSumGroup where groupnum=group_num;
        while instr(type_str,',',1)>0 loop
           tmptype := substr(type_str,1,instr(type_str,',',1)-1);
	         type_sql := type_sql||'R.ResID between '''||tmptype||group_start||''' and '''||tmptype||group_end||''' or ';

           type_str := substr(type_str,instr(type_str,',',1)+1,length(type_str)-1-length(tmptype));
        end loop;
	      type_sql := type_sql||'R.ResID between '''||type_str||group_start||''' and '''||type_str||group_end||''')';
    end if;

    ---????
    while tmpStartTime<tmpEndTime loop
         gtmpEndTime := to_date(to_char(tmpStartTime,'yyyymmdd')||'235959','yyyymmddhh24miss');
	       if gtmpEndTime>tmpEndTime then
	           gtmpEndTime := tmpEndTime;
	       end if;


	       --??ResValidHis??????
	       tmpStartStr := to_char(tmpStartTime,'yyyymmddhh24miss');
	       tmpEndStr := to_char(gtmpEndTime,'yyyymmddhh24miss');
         sql_str := 'delete from ResValidHis R WHERE R.RecordTime>=to_date('''||tmpStartStr||''',''yyyymmddhh24miss'') and R.RecordTime<=to_date('''||tmpEndStr||''',''yyyymmddhh24miss'')'||type_sql;
	       execute immediate sql_str;

	       --??
        sql_str := 'SELECT R.Resid,R.Recordtime,D.DerivedItemCode,R.Value
                    FROM ResMoniRawInfo R,ResMoniDerivedItemCfg D
                    WHERE R.MoniItemCode=D.MoniItemCode
                    AND R.Moniitemcode IN (''B_CIR_COMValid'',''B_CIR_ATMValid'')
                    AND R.RecordTime>=to_date('''||tmpStartStr||''',''yyyymmddhh24miss'') and RecordTime<=to_date('''||tmpEndStr||''',''yyyymmddhh24miss'')'||type_sql||'
                    ORDER BY R.Resid,R.Recordtime';
         lastResID := 'forbegin';

          open cur_record for sql_str;
          loop
              fetch cur_record into curResID,curRecordTime,curDerivedItemcode,curValue;
              EXIT WHEN cur_record%NOTFOUND;
              if curResID = lastResID then --?????
                   if lastValue = 1 and curValue = 0 then
                       lastValue := 0;

                       --??his?lasttime
                       UPDATE ResValidHis SET lasttime=(curRecordTime-beginRecordTime)*86400
                       WHERE ResID=lastResID AND Param=lastDerivedItemCode AND Recordtime=beginRecordTime;

                       beginRecordTime := curRecordTime;
                       INSERT INTO ResValidHis(ResID,Param,Recordtime,Valid,LastTime)
                       VALUES(curResID,curDerivedItemCode,curRecordTime,curValue,0);
                   elsif lastValue=0 and curValue=1 then
                       lastValue := 1;

                        --??his?lasttime
                       UPDATE ResValidHis SET lasttime=(curRecordTime-beginRecordTime)*86400
                       WHERE ResID=lastResID AND Param=lastDerivedItemCode AND Recordtime=beginRecordTime;

                       beginRecordTime := curRecordTime;
                       INSERT INTO ResValidHis(ResID,Param,Recordtime,Valid,LastTime)
                       VALUES(curResID,curDerivedItemCode,curRecordTime,curValue,0);
                   end if;
              else
                    if lastResID = 'forbegin' then --???????????
                         lastResID := curResID;
                         beginRecordTime := curRecordTime;
                         lastDerivedItemcode := curDerivedItemcode;
                         lastValue := curValue;

                         --??his?
                         INSERT INTO ResValidHis(ResID,Param,Recordtime,Valid,LastTime)
                         VALUES(curResID,curDerivedItemCode,curRecordTime,curValue,0);
                    else
                       --??????his???
                       UPDATE ResValidHis SET LastTime=(tmpEndTime-beginRecordTime)*86400
                       WHERE ResID=lastResID AND Param=lastDerivedItemCode AND Recordtime=beginRecordTime;

                        --??????his?
                       INSERT INTO ResValidHis(ResID,Param,Recordtime,Valid,LastTime)
                       VALUES(curResID,curDerivedItemCode,curRecordTime,curValue,0);
                       --?????????????
                       lastResID := curResID;
                       beginRecordTime := curRecordTime;
                       lastDerivedItemcode := curDerivedItemcode;
                       lastValue := curValue;
                    end if;
                end if;
          end loop;--??????
          close cur_record;

          --????????
          if lastResID <> 'forbegin' then
               --??his???
               UPDATE ResValidHis SET LastTime=(gtmpEndTime-beginRecordTime)*86400
               WHERE ResID=lastResID AND Param=lastDerivedItemCode AND Recordtime=beginRecordTime;
          end if;

         --????
	       if ifBP='I' then
	           insert into ressumbp(SumPeriodType,sumtype,groupnum,BPDate) values('D','V',group_num,to_char(tmpStartTime,'yyyymmdd'));
	           ifBP := 'U';
	       elsif ifBP='U' then
             if Method='CRON' or (Method='SUB' and to_char(tmpStartTime,'yyyymmdd')>BPTime) then
	               update ressumbp set BPDate=to_char(tmpStartTime,'yyyymmdd') where sumperiodtype='D' and sumtype='V' and groupnum=group_num;
	           end if;
         end if;
	 select b.bpdate into BPTime from ressumbp b where b.sumperiodtype='D' and b.sumtype='V' and b.groupnum=group_num;

         commit;  --??
	       tmpStartTime := tmpStartTime+1;
   end loop; --??????
  end if; --??????
   num := resgroup.next(num);
end loop;--??????

END;
/
