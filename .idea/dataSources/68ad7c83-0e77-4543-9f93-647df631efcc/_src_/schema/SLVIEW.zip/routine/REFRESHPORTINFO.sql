CREATE PROCEDURE refreshportinfo
IS
   TYPE portcur IS REF CURSOR;

   l_portcur           portcur;
   l_deviceid          portinfo.deviceid%TYPE;
   l_portdescr         portinfo.portdescr%TYPE;
   l_portclass         portinfo.portclass%TYPE;
   l_porttype          portinfo.porttype%TYPE;
   l_portindex         portinfo.portindex%TYPE;
   l_portspeed         portinfo.portspeed%TYPE;
   l_vpi               portinfo.vpi%TYPE;
   l_vci               portinfo.vci%TYPE;
   l_dlci              portinfo.dlci%TYPE;
   l_adminstatus       portinfo.adminstatus%TYPE;
   l_operstatus        portinfo.operstatus%TYPE;
   l_portdescrdetail   portinfo.portdescrdetail%TYPE;
   l_portmode          portinfo.portmode%TYPE;
   l_distance          portinfo.distance%TYPE;
   l_ppdescr           portinfo.ppdescr%TYPE;
   l_ipaddress         portinfo.ipaddress%TYPE;
   l_netmask           portinfo.netmask%TYPE;
   l_fullipaddress     portinfo.fullipaddress%TYPE;
   l_begin             INTEGER;
   l_end               INTEGER;
   l_segint            INTEGER;
BEGIN
   EXECUTE IMMEDIATE 'truncate table PortInfo';

   OPEN l_portcur FOR
      SELECT lpinfo.deviceid, lpdescr, 'L', lptype, lpindex, lpspeed, vpi,
             vci, dlci, adminstatus, operstatus, portdescrdetail, '', '',
             ppdescr, ipaddress, netmask
        FROM lpinfo,
             (SELECT *
                FROM devaddr
               WHERE changetype = 0 AND seqnum = 0) addr
       WHERE lpinfo.deviceid = addr.deviceid(+)
         AND lpinfo.lpdescr = addr.intdescr(+)
         AND lpinfo.changetype = 0
      UNION
      SELECT ppinfo.deviceid, ppdescr, 'P', pptype, ppindex, ppspeed, -1, -1,
             -1, adminstatus, operstatus, portdescrdetail, portmode, distance,
             ppdescr, ipaddress, netmask
        FROM ppinfo,
             (SELECT *
                FROM devaddr
               WHERE changetype = 0 AND seqnum = 0) addr
       WHERE ppinfo.deviceid = addr.deviceid(+)
         AND ppinfo.ppdescr = addr.intdescr(+)
         AND ppinfo.changetype = 0;

   LOOP
      FETCH l_portcur
       INTO l_deviceid, l_portdescr, l_portclass, l_porttype, l_portindex,
            l_portspeed, l_vpi, l_vci, l_dlci, l_adminstatus, l_operstatus,
            l_portdescrdetail, l_portmode, l_distance, l_ppdescr,
            l_ipaddress, l_netmask;

      EXIT WHEN l_portcur%NOTFOUND;
      l_fullipaddress := NULL;

      IF (l_ipaddress IS NOT NULL)
      THEN
         l_fullipaddress := to_fullip (l_ipaddress);
      END IF;

      BEGIN
         INSERT INTO portinfo
                     (deviceid, portdescr, portclass, porttype,
                      portindex, portspeed, vpi, vci, dlci,
                      adminstatus, operstatus, portdescrdetail,
                      portmode, distance, ppdescr, ipaddress,
                      netmask, fullipaddress
                     )
              VALUES (l_deviceid, l_portdescr, l_portclass, l_porttype,
                      l_portindex, l_portspeed, l_vpi, l_vci, l_dlci,
                      l_adminstatus, l_operstatus, l_portdescrdetail,
                      l_portmode, l_distance, l_ppdescr, l_ipaddress,
                      l_netmask, l_fullipaddress
                     );

         COMMIT;
      EXCEPTION
         WHEN OTHERS
         THEN
            UPDATE portinfo
               SET porttype = l_porttype,
                   portindex = l_portindex,
                   portspeed = l_portspeed,
                   vpi = l_vpi,
                   vci = l_vci,
                   dlci = l_dlci,
                   adminstatus = l_adminstatus,
                   operstatus = l_operstatus,
                   portdescrdetail = l_portdescrdetail,
                   portmode = l_portmode,
                   distance = l_distance,
                   ppdescr = l_ppdescr,
                   ipaddress = l_ipaddress,
                   netmask = l_netmask,
                   fullipaddress = l_fullipaddress
             WHERE deviceid = l_deviceid
               AND portdescr = l_portdescr
               AND portclass = l_portclass;

            COMMIT;
      END;
   END LOOP;

   CLOSE l_portcur;
END refreshportinfo;
/
