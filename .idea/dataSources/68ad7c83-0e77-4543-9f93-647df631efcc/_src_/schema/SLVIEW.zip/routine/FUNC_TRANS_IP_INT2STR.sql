CREATE function func_trans_ip_int2str
(
    i_ip_int     number,
    i_funcswitch number   default 0  -- ???1??0-????IP???1-????IP??
)
return varchar2 deterministic
is
begin
    if i_ip_int is null then
    return null;
  end if;
    if bitand(i_funcswitch, 1) = 1 then
        return lpad(mod(trunc(i_ip_int /256/ 256/256 ),256), 3, 0)
               || '.'|| lpad(mod(trunc(i_ip_int/ 256/256 ),256), 3, 0)
               || '.'|| lpad(mod(trunc(i_ip_int/ 256),256 ), 3, 0)
               || '.'|| lpad(mod(i_ip_int, 256), 3, 0);
    else
        return to_char(mod(trunc(i_ip_int /256/ 256/256 ),256))
               || '.'|| to_char(mod(trunc(i_ip_int/ 256/256 ),256))
               || '.'|| to_char(mod(trunc(i_ip_int/ 256),256 ))
               || '.'|| to_char(mod(i_ip_int, 256));
    end if;
end func_trans_ip_int2str;

/
