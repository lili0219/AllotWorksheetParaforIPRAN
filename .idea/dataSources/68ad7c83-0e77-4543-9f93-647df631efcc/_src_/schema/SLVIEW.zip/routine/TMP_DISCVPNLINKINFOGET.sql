CREATE PROCEDURE TMP_DISCVPNLINKINFOGET

   IS
--
-- To modify this template, edit file PROC.TXT in TEMPLATE
-- directory of SQL Navigator
--
-- Purpose: Briefly explain the functionality of the procedure
--
-- MODIFICATION HISTORY
-- Person      Date    Comments
-- ---------   ------  -------------------------------------------
   l_tmplink            number ;
   l_tmpvalue           varchar2(4000) ;

   -- Declare program variables as shown above
BEGIN
    EXECUTE IMMEDIATE 'TRUNCATE TABLE TMP_DISCVPNLINK' ;

    INSERT INTO TMP_DISCVPNLINK(DiscVpnLinkID) SELECT DiscVpnLinkID FROM DISCMPLSVPNLINK ;

    COMMIT ;

    l_tmplink := -1 ;
    l_tmpvalue := null ;
    for l_rec in (
    select distinct lg.DiscVpnLinkID id,decode(lg.VRFRole,'hub',g.SpokeRT,g.HubRT) rt
    from discmplsvpnlink l,discvpnrtgroup lg, RTGroup g
    where l.DiscVpnLinkID=lg.DiscVpnLinkID and lg.RTGroupID=g.RTGroupID order by lg.DiscVpnLinkID ) loop
        if (l_tmplink = l_rec.id) then
            l_tmpvalue := l_tmpvalue || ';' || l_rec.rt ;
        else
            update TMP_DISCVPNLINK set importrt=l_tmpvalue where DiscVpnLinkID=l_tmplink ;
            l_tmpvalue := l_rec.rt ;
            l_tmplink := l_rec.id ;
        end if ;
    end loop ;
    update TMP_DISCVPNLINK set importrt=l_tmpvalue where DiscVpnLinkID=l_tmplink ;
    commit ;

    l_tmplink := -1 ;
    l_tmpvalue := null ;
    for l_rec in (
    select distinct lg.DiscVpnLinkID id,decode(lg.VRFRole,'hub',g.HubRT,g.SpokeRT) rt
    from discmplsvpnlink l,discvpnrtgroup lg, RTGroup g
    where l.DiscVpnLinkID=lg.DiscVpnLinkID and lg.RTGroupID=g.RTGroupID order by lg.DiscVpnLinkID ) loop
        if (l_tmplink = l_rec.id) then
            l_tmpvalue := l_tmpvalue || ';' || l_rec.rt ;
        else
            update TMP_DISCVPNLINK set exportrt=l_tmpvalue where DiscVpnLinkID=l_tmplink ;
            l_tmpvalue := l_rec.rt ;
            l_tmplink := l_rec.id ;
        end if ;
    end loop ;
    update TMP_DISCVPNLINK set exportrt=l_tmpvalue where DiscVpnLinkID=l_tmplink ;
    commit ;

    l_tmplink := -1 ;
    l_tmpvalue := null ;
    for l_rec in (
    select distinct l.DiscVpnLinkID id,vs.subnet subnet
    from discmplsvpnlink l,discvpnlinkstatic vs
    where l.DiscVpnLinkID=vs.DiscVpnLinkID order by l.DiscVpnLinkID ) loop
        if (l_tmplink = l_rec.id) then
            l_tmpvalue := l_tmpvalue || ';' || l_rec.subnet ;
        else
            update TMP_DISCVPNLINK set staticroute=l_tmpvalue where DiscVpnLinkID=l_tmplink ;
            l_tmpvalue := l_rec.subnet ;
            l_tmplink := l_rec.id ;
        end if ;
    end loop ;
    update TMP_DISCVPNLINK set staticroute=l_tmpvalue where DiscVpnLinkID=l_tmplink ;
    commit ;


END; -- Procedure
/
