CREATE PROCEDURE pru_rmdperf_ns
(
   Method char,
   StartTimeStr char,
   EndTimeStr char
)
AS
StartTime date;
EndTime date;
tmpStartTime date;
tmpEndTime date;
gtmpEndTime date;
tmpStartStr varchar2(14);
tmpEndStr varchar2(14);

---????
TYPE R_GROUP IS RECORD(value varchar2(30),ItemType varchar2(20));
TYPE T_GROUP IS TABLE OF R_GROUP INDEX BY BINARY_INTEGER;
resgroup T_GROUP;

num int;
tablenum int;
colnum int;
---????????
StatSpan int;
--groupindex int;

sql_str1 varchar2(1000);
sql_str varchar2(2000);
group_num varchar2(50);
group_type varchar2(10);

BEGIN
EndTime := to_date(to_char(sysdate,'yyyymmdd')||'235959','yyyymmddhh24miss');
StartTime := to_date(to_char(sysdate-1,'yyyymmdd'),'yyyymmdd');

---????????
select to_number(PARAVALUE) into StatSpan from syspara where PARANAME='PerfCollectDay';
StatSpan := StatSpan - 1;
if StatSpan < 1 then
   StatSpan := 1;
end if;

if Method='CRON' then
   tmpStartTime := StartTime;
   tmpEndTime := EndTime;
elsif Method='SUB' then
   tmpStartTime := to_date(StartTimeStr,'yyyymmdd');
   tmpEndTime := to_date(EndTimeStr||'235959','yyyymmddhh24miss');
   if tmpEndTime>tmpStartTime+StatSpan then
      tmpEndTime := to_date(to_char(tmpStartTime+StatSpan,'yyyymmdd')||'235959','yyyymmddhh24miss');
   end if;
   if tmpEndTime>EndTime then
        tmpEndTime := EndTime;
   end if;
end if;

--????
num := 0;
select count(distinct g.tablename) into tablenum from ResPerfStoreGroup g,restype r where g.restypeid=r.restypeid and r.perfstoretype='SCATTER';
if tablenum>0 then
  for g in (select distinct g.tablename,g.itemtype from ResPerfStoreGroup g,restype r where g.restypeid=r.restypeid and r.perfstoretype='SCATTER') loop
   --????????
   Select count(distinct columnname) into colnum from ResPerfStoreGroupItem a, ResPerfStoreGroup b where a.groupid=b.groupid and b.tablename=g.tablename;
   if colnum>0 then
      resgroup(num).value := g.tablename;
      resgroup(num).ItemType := g.itemtype;
        num := num+1;
   end if;
  end loop;

  ---????
  while tmpStartTime<tmpEndTime loop
    gtmpEndTime := to_date(to_char(tmpStartTime,'yyyymmdd')||'235959','yyyymmddhh24miss');
      if gtmpEndTime>tmpEndTime then
         gtmpEndTime := tmpEndTime;
      end if;

     ---????????
     num := resgroup.first;
     loop
        exit when num is null;
        group_num := resgroup(num).value;
        group_type := resgroup(num).ItemType;

        --??????
          tmpStartStr := to_char(tmpStartTime,'yyyymmdd');
        sql_str := 'delete from '||group_num||'_D WHERE DayID='''||tmpStartStr||'''';
          execute immediate sql_str;

        --??????
          tmpStartStr := to_char(tmpStartTime,'yyyymmddhh24miss');
          tmpEndStr := to_char(gtmpEndTime,'yyyymmddhh24miss');

        --SUM------
        Select count(distinct columnname) into colnum from ResPerfStoreGroupItem a, ResPerfStoreGroup b where a.groupid=b.groupid and b.tablename=group_num and instr(a.SummaryType,'SUM')>0;
        if colnum>0 then
           if group_type='value' then
              sql_str1 := 'INSERT INTO '||group_num||'_D(resid,dayid,summarytype';
              sql_str := '(Select resid,to_char(coltime,''yyyymmdd''),''SUM''';
           elsif group_type='table' then
              sql_str1 := 'INSERT INTO '||group_num||'_D(resid,respara,dayid,summarytype';
              sql_str := '(Select resid,respara,to_char(coltime,''yyyymmdd''),''SUM''';
           end if;

           for g in (Select distinct columnname from ResPerfStoreGroupItem a, ResPerfStoreGroup b where a.groupid=b.groupid and b.tablename=group_num and instr(a.SummaryType,'SUM')>0) loop
               sql_str1 := sql_str1||','||g.columnname;
               sql_str := sql_str||',SUM('||g.columnname||')';
           end loop;
           sql_str1 := sql_str1||')';
           sql_str := sql_str1||sql_str;
           sql_str := sql_str||' From '||group_num||'
              Where coltime >= to_date('||tmpStartStr||',''yyyymmddhh24miss'') and coltime <= to_date('||tmpEndStr||',''yyyymmddhh24miss'')
              Group by resid,';
           if group_type='value' then
              sql_str := sql_str||'to_char(coltime,''yyyymmdd''))';
           elsif group_type='table' then
              sql_str := sql_str||'respara,to_char(coltime,''yyyymmdd''))';
           end if;
           execute immediate sql_str;
        end if;

        sql_str1 := '';
        sql_str := '';
        --AVG------
        Select count(distinct columnname) into colnum from ResPerfStoreGroupItem a, ResPerfStoreGroup b where a.groupid=b.groupid and b.tablename=group_num and instr(a.SummaryType,'AVG')>0;
        if colnum>0 then
           if group_type='value' then
              sql_str1 := 'INSERT INTO '||group_num||'_D(resid,dayid,summarytype';
              sql_str := '(Select resid,to_char(coltime,''yyyymmdd''),''AVG''';
           elsif group_type='table' then
              sql_str1 := 'INSERT INTO '||group_num||'_D(resid,respara,dayid,summarytype';
              sql_str := '(Select resid,respara,to_char(coltime,''yyyymmdd''),''AVG''';
           end if;

           for g in (Select distinct columnname from ResPerfStoreGroupItem a, ResPerfStoreGroup b where a.groupid=b.groupid and b.tablename=group_num and instr(a.SummaryType,'AVG')>0) loop
               sql_str1 := sql_str1||','||g.columnname;
               sql_str := sql_str||',AVG('||g.columnname||')';
           end loop;
           sql_str1 := sql_str1||')';
           sql_str := sql_str1||sql_str;
           sql_str := sql_str||' From '||group_num||'
              Where coltime >= to_date('||tmpStartStr||',''yyyymmddhh24miss'') and coltime <= to_date('||tmpEndStr||',''yyyymmddhh24miss'')
              Group by resid,';
           if group_type='value' then
              sql_str := sql_str||'to_char(coltime,''yyyymmdd''))';
           elsif group_type='table' then
              sql_str := sql_str||'respara,to_char(coltime,''yyyymmdd''))';
           end if;
           execute immediate sql_str;
        end if;
        sql_str1 := '';
        sql_str := '';

        -----MIN------
        Select count(distinct columnname) into colnum from ResPerfStoreGroupItem a, ResPerfStoreGroup b where a.groupid=b.groupid and b.tablename=group_num and instr(a.SummaryType,'MIN')>0;
        if colnum>0 then
           if group_type='value' then
              sql_str1 := 'INSERT INTO '||group_num||'_D(resid,dayid,summarytype';
              sql_str := '(Select resid,to_char(coltime,''yyyymmdd''),''MIN''';
           elsif group_type='table' then
              sql_str1 := 'INSERT INTO '||group_num||'_D(resid,respara,dayid,summarytype';
              sql_str := '(Select resid,respara,to_char(coltime,''yyyymmdd''),''MIN''';
           end if;

           for g in (Select distinct columnname from ResPerfStoreGroupItem a, ResPerfStoreGroup b where a.groupid=b.groupid and b.tablename=group_num and instr(a.SummaryType,'MIN')>0) loop
               sql_str1 := sql_str1||','||g.columnname;
               sql_str := sql_str||',MIN('||g.columnname||')';
           end loop;
           sql_str1 := sql_str1||')';
           sql_str := sql_str1||sql_str;
           sql_str := sql_str||' From '||group_num||'
              Where coltime >= to_date('||tmpStartStr||',''yyyymmddhh24miss'') and coltime <= to_date('||tmpEndStr||',''yyyymmddhh24miss'')
              Group by resid,';
           if group_type='value' then
              sql_str := sql_str||'to_char(coltime,''yyyymmdd''))';
           elsif group_type='table' then
              sql_str := sql_str||'respara,to_char(coltime,''yyyymmdd''))';
           end if;
           execute immediate sql_str;
        end if;
        sql_str1 := '';
        sql_str := '';

        -----MAX------
        Select count(distinct columnname) into colnum from ResPerfStoreGroupItem a, ResPerfStoreGroup b where a.groupid=b.groupid and b.tablename=group_num and instr(a.SummaryType,'MAX')>0;
        if colnum>0 then
           if group_type='value' then
              sql_str1 := 'INSERT INTO '||group_num||'_D(resid,dayid,summarytype';
              sql_str := '(Select resid,to_char(coltime,''yyyymmdd''),''MAX''';
           elsif group_type='table' then
              sql_str1 := 'INSERT INTO '||group_num||'_D(resid,respara,dayid,summarytype';
              sql_str := '(Select resid,respara,to_char(coltime,''yyyymmdd''),''MAX''';
           end if;

           for g in (Select distinct columnname from ResPerfStoreGroupItem a, ResPerfStoreGroup b where a.groupid=b.groupid and b.tablename=group_num and instr(a.SummaryType,'MAX')>0) loop
               sql_str1 := sql_str1||','||g.columnname;
               sql_str := sql_str||',MAX('||g.columnname||')';
           end loop;
           sql_str1 := sql_str1||')';
           sql_str := sql_str1||sql_str;
           sql_str := sql_str||' From '||group_num||'
              Where coltime >= to_date('||tmpStartStr||',''yyyymmddhh24miss'') and coltime <= to_date('||tmpEndStr||',''yyyymmddhh24miss'')
              Group by resid,';
           if group_type='value' then
              sql_str := sql_str||'to_char(coltime,''yyyymmdd''))';
           elsif group_type='table' then
              sql_str := sql_str||'respara,to_char(coltime,''yyyymmdd''))';
           end if;
           execute immediate sql_str;
        end if;

        num := resgroup.next(num);
     end loop;--??????
     commit;  --??
    tmpStartTime := tmpStartTime+1;
    end loop; --??????
  end if;
END;
/
