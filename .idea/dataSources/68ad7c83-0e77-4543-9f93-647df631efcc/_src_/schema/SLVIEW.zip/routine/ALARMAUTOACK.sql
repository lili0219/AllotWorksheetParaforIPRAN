CREATE PROCEDURE alarmautoack
IS
BEGIN
    /*
     ??????:
     ??????????????????????<????????????
    */
    FOR l_rec IN (
                  SELECT a.sumalarmid
                  FROM alarmsummary a ,alarmtype b
                  WHERE a.alarmtypeid = b.alarmtypeid
                    AND b.autoackcond >= 0 AND a.starttime + b.autoackcond/(24*60) < SYSDATE AND a.ackstatus = '0'
                  ) LOOP
        BEGIN
            UPDATE alarmsummary
               SET ackstatus = '1',ackuserid='SYSAUTOACK',acktime=SYSDATE
            WHERE sumalarmid = l_rec.sumalarmid ;
        EXCEPTION
            WHEN OTHERS THEN
                NULL;
        END;
        COMMIT;
    END LOOP;

    /*
      ?????????:
      ???????????????????????????????????+??????<????,??????????
    */
    FOR l_rec IN (
                  SELECT a.sumalarmid
                  FROM alarmsummary a, alarmtype b
                  WHERE a.alarmtypeid = b.alarmtypeid
                    AND
                       (a.stoptime IS NULL OR b.autorecovertime IS NOT NULL)
                    AND
                       (a.lastoccurtime + b.autorecovertime/(24*60) < SYSDATE)
                  ) LOOP
        BEGIN
            UPDATE alarmsummary
               SET stoptime = SYSDATE
            WHERE sumalarmid = l_rec.sumalarmid ;
        EXCEPTION
            WHEN OTHERS THEN
                NULL;
        END;
        COMMIT;
    END LOOP;
END;
/
