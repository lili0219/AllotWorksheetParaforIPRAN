CREATE function func_trans_ip_str2int
(
    i_ip_str in varchar2
)
return number deterministic
is
begin
    return substr(i_ip_str, 1, (instr(i_ip_str, '.', 1, 1) - 1)) * 256 * 256 * 256 +
           substr(i_ip_str, instr(i_ip_str, '.', 1, 1) + 1, instr(i_ip_str, '.', 1, 2 ) - instr(i_ip_str, '.', 1, 1 ) - 1) * 256 * 256 +
           substr(i_ip_str, instr(i_ip_str, '.', 1, 2) + 1, instr(i_ip_str, '.', 1, 3 ) - instr(i_ip_str, '.', 1, 2 ) - 1) * 256 +
           substr(i_ip_str, instr(i_ip_str, '.', 1, 3 ) + 1);
end func_trans_ip_str2int;

/
