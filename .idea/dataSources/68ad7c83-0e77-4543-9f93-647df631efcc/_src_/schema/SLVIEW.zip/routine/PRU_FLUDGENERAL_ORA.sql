CREATE procedure pru_fludgeneral_ora(i_dayflu_flag varchar2,
                                                i_group_id    number,
                                                i_begin_date  date,
                                                i_end_date    date,
                                                rtn_code      out number,
                                                rtn_info      out varchar2)

 is
  /*
  -----------------------????--------------------------------
  ?????????????????????????
  ?????2011-10-24
  ????: naym
  ????????????perl??????
       ???????????????????????
       ?????????? ???????*/
  /*?????20111110 ????NAYM ???I_GROUP_ID ???????????*/
  --I_GROUP_ID  ??????????????????0 ??? ??????
  /*????*/
  --I_DAYFLU_FLAG ???????? ????B,M,L,BM,BL,LM,BML
  --????????????????????BM?? B?M????
  --I_BEGIN_DATE I_END_DATE  ????????? ???????YYYY-MM-DD
  --????????????????????
  /*RTN_CODE   NUMBER(2);
  RTN_INFO   VARCHAR2(100);*/
  /*??????????*/
  v_status  number(2);
  v_step    number(2) := 0;
  v_sp_name varchar2(40) := 'PRU_FLUDGeneral_ORA';

  /*??????????,????????*/
  --V_NUM        NUMBER;
  v_begin_date varchar2(8) := to_char(i_begin_date, 'YYYYMMDD');
  v_end_date   varchar2(8) := to_char(i_end_date, 'YYYYMMDD');
  inlimita     varchar2(8);
  inlimitb     varchar2(8);
  outlimita    varchar2(8);
  outlimitb    varchar2(8);
  v_groupstart varchar2(10);
  v_groupend   varchar2(10);
begin
  ----------------------??????-----------------------------
  /*??????????*/
  --I_DAYFLU_FLAG ??? B M L ???
  --?????? ?date??? ??????
  if upper(i_dayflu_flag) in ('B',
                              'M',
                              'L',
                              'BM',
                              'BL',
                              'MB',
                              'ML',
                              'LB',
                              'LM',
                              'BML',
                              'BLM',
                              'MBL',
                              'MLB',
                              'LBM',
                              'LMB',
                              'G') and i_begin_date <= i_end_date then

    --??????
    v_status := fun_get_process_status(v_sp_name || '-' || i_dayflu_flag,
                                       v_begin_date || '-' ||
                                       substr(v_end_date, 5, 4),
                                       2);
    if v_status = 8 then
      rtn_code := -2;
      rtn_info := '??????';
      return;
    end if;

    -- ?????????
    sp_set_process_status(v_sp_name || '-' || i_dayflu_flag,
                          v_begin_date || '-' || substr(v_end_date, 5, 4),
                          2,
                          8,
                          v_step);

    v_step := 1;

    case
      when i_group_id <> 0 then
        select groupstart, groupend
          into v_groupstart, v_groupend
          from flusumgroup fp
         where fp.groupnum = i_group_id;
      when i_group_id = 0 then
        select to_char(min(ct.circuitid)), to_char(max(ct.circuitid))
          into v_groupstart, v_groupend
          from circuit ct;
    end case;
    v_step := 2;
    if upper(i_dayflu_flag) = 'G' then

      delete from fluxd fd
       where fd.fluxtime >= v_begin_date
         and fd.fluxtime < v_end_date
         and fd.circuitid >= v_groupstart
         and fd.circuitid <= v_groupend;
      commit;
      v_step := 3;
      insert into fluxd
        (circuitid,
         fluxtime,
         inavgvec,
         outavgvec,
         inmaxvec,
         outmaxvec,
         inminvec,
         outminvec,
         inavgratio,
         outavgratio,
         inmaxratio,
         outmaxratio,
         inminratio,
         outminratio,
         innonbmaxvec,
         outnonbmaxvec /*,
                                                                                                                              INFLOW,
                                                                                                                              OUTFLOW*/)
        select fh.circuitid,
               substr(fh.fluxtime, 1, 8),
               round(avg(fh.inavgvec), 3),
               round(avg(fh.outavgvec), 3),
               round(max(fh.inmaxvec), 3),
               round(max(fh.outmaxvec), 3),
               round(min(fh.inminvec), 3),
               round(min(fh.outminvec), 3),
               round(avg(fh.inavgratio), 2),
               round(avg(fh.outavgratio), 2),
               round(max(fh.inmaxratio), 2),
               round(max(fh.outmaxratio), 2),
               round(min(fh.inminratio), 2),
               round(min(fh.outminratio), 2),
               0,
               0 /*,
                                                                                                                       ROUND(SUM(FH.INFLOW), 3),
                                                                                                                       ROUND(SUM(FH.OUTFLOW), 3)*/
          from fluxh fh
         where fh.fluxtime > v_begin_date
           and fh.fluxtime < v_end_date
           and fh.circuitid >= v_groupstart
           and fh.circuitid <= v_groupend
         group by fh.circuitid, substr(fh.fluxtime, 1, 8);
      commit;

      --????????????
      delete from flusumbp
       where sumperiodtype = 'D'
         and instr(upper(i_dayflu_flag), sumtype) > 0
         and groupnum = i_group_id;
      insert into flusumbp
        (sumperiodtype, sumtype, groupnum, bpdate)
        select 'D',
               upper(i_dayflu_flag),
               i_group_id,
               to_char(i_end_date - 1, 'YYYYMMDD')
          from dual;
      commit;
      v_step := 4;
    else
      --???????????
      execute immediate 'truncate table flux_num';
      --????????????
      insert into flux_num
        (circuitid, num, fluxdate)
        select circuitid,
               trunc(count(*) * 0.05 - 1),
               substr(f.fluxtime, 1, 8) as fluxdate
          from flux f
         where f.fluxtime > v_begin_date
           and f.fluxtime < v_end_date
           and f.circuitid >= v_groupstart
           and f.circuitid <= v_groupend
         group by f.circuitid, substr(f.fluxtime, 1, 8);
      commit;
      v_step := 5;
      /*?????????????*/
      --?????
      insert into temp_flux
        (circuitid,
         fluxtime,
         interval,
         inavgvec,
         outavgvec,
         inavgratio,
         outavgratio)
        select f.circuitid,
               f.fluxtime,
               f.interval,
               f.inavgvec,
               f.outavgvec,
               (f.inavgvec * 8 / 1000) /
               decode(ct.bandwidth, null, 1, 0, 1, ct.bandwidth) * 100,
               (f.outavgvec * 8 / 1000) /
               decode(ct.bandwidth, null, 1, 0, 1, ct.bandwidth) * 100
          from flux f, circuit ct
         where f.fluxtime > v_begin_date
           and f.fluxtime < v_end_date
           and ct.circuitid = f.circuitid
           and f.circuitid >= v_groupstart
           and f.circuitid <= v_groupend
           and ct.changetype = 0;
      --?????
      insert into temp_fluxd
        (circuitid,
         fluxtime,
         innonbmaxvec,
         outnonbmaxvec,
         innonbmaxratio,
         outnonbmaxratio,
         inmaxtime,
         outmaxtime,
         inavgratioovermina,
         outavgratioovermina,
         inavgratiooverminb,
         outavgratiooverminb,
         state_flag)
        select circuitid,
               fluxtime,
               nvl(innonbmaxvec, 0),
               nvl(outnonbmaxvec, 0),
               innonbmaxratio,
               outnonbmaxratio,
               inmaxtime,
               outmaxtime,
               inavgratioovermina,
               outavgratioovermina,
               inavgratiooverminb,
               outavgratiooverminb,
               'O'
          from fluxd fd
         where fd.fluxtime >= v_begin_date
           and fd.fluxtime < v_end_date
           and fd.circuitid >= v_groupstart
           and fd.circuitid <= v_groupend;

      v_step := v_step + 1;
      /*????????B???*/
      if instr(upper(i_dayflu_flag), 'B') > 0 then
        --?????????
        insert into temp_fluxd
          (circuitid,
           fluxtime,
           innonbmaxvec,
           outnonbmaxvec,
           innonbmaxratio,
           outnonbmaxratio,
           inmaxtime,
           outmaxtime,
           inavgratioovermina,
           outavgratioovermina,
           inavgratiooverminb,
           outavgratiooverminb,
           state_flag)
          select tfd.circuitid,
                 tfd.fluxtime,
                 nvl(a1.inavgvec, 0),
                 nvl(a2.outavgvec, 0),
                 nvl(a3.inavgratio, 0),
                 nvl(a4.outavgratio, 0),
                 tfd.inmaxtime,
                 tfd.outmaxtime,
                 tfd.inavgratioovermina,
                 tfd.outavgratioovermina,
                 tfd.inavgratiooverminb,
                 tfd.outavgratiooverminb,
                 'B' as state_flag
            from temp_fluxd tfd
           inner join (select p.*,
                              substr(p.fluxtime, 1, 8) as fluxdate,
                              row_number() over(partition by circuitid, substr(p.fluxtime, 1, 8) order by inavgvec desc) as num_id
                         from temp_flux p) a1 on a1.circuitid =
                                                 tfd.circuitid
                                             and a1.fluxdate = tfd.fluxtime
                                             and exists
           (select *
                                                    from flux_num fn
                                                   where fn.circuitid =
                                                         a1.circuitid
                                                     and fn.num = a1.num_id
                                                     and fn.fluxdate =
                                                         a1.fluxdate)
           inner join (select p.*,
                              substr(p.fluxtime, 1, 8) as fluxdate,
                              row_number() over(partition by circuitid, substr(p.fluxtime, 1, 8) order by outavgvec desc) as num_id
                         from temp_flux p) a2 on a2.circuitid =
                                                 tfd.circuitid
                                             and a2.fluxdate = tfd.fluxtime
                                             and exists
           (select *
                                                    from flux_num fn
                                                   where fn.circuitid =
                                                         a2.circuitid
                                                     and fn.num = a2.num_id
                                                     and fn.fluxdate =
                                                         a2.fluxdate)
           inner join (select p.*,
                              substr(p.fluxtime, 1, 8) as fluxdate,
                              row_number() over(partition by circuitid, substr(p.fluxtime, 1, 8) order by inavgratio desc) as num_id
                         from temp_flux p) a3 on a3.circuitid =
                                                 tfd.circuitid
                                             and a3.fluxdate = tfd.fluxtime
                                             and exists
           (select *
                                                    from flux_num fn
                                                   where fn.circuitid =
                                                         a3.circuitid
                                                     and fn.num = a3.num_id
                                                     and fn.fluxdate =
                                                         a3.fluxdate)
           inner join (select p.*,
                              substr(p.fluxtime, 1, 8) as fluxdate,
                              row_number() over(partition by circuitid, substr(p.fluxtime, 1, 8) order by outavgratio desc) as num_id
                         from temp_flux p) a4 on a4.circuitid =
                                                 tfd.circuitid
                                             and a4.fluxdate = tfd.fluxtime
                                             and exists
           (select *
                                                    from flux_num fn
                                                   where fn.circuitid =
                                                         a4.circuitid
                                                     and fn.num = a4.num_id
                                                     and fn.fluxdate =
                                                         a4.fluxdate);
        delete from temp_fluxd fd where fd.state_flag = 'O';
        update temp_fluxd fd set fd.state_flag = 'O';
      end if;
      v_step := v_step + 1;
      /*????????M???*/
      if instr(upper(i_dayflu_flag), 'M') > 0 then
        --??????????
        insert into temp_fluxd
          (circuitid,
           fluxtime,
           innonbmaxvec,
           outnonbmaxvec,
           innonbmaxratio,
           outnonbmaxratio,
           inmaxtime,
           outmaxtime,
           inavgratioovermina,
           outavgratioovermina,
           inavgratiooverminb,
           outavgratiooverminb,
           state_flag)
          select tfd.circuitid,
                 tfd.fluxtime,
                 tfd.innonbmaxvec,
                 tfd.outnonbmaxvec,
                 tfd.innonbmaxratio,
                 tfd.outnonbmaxratio,
                 a1.fluxtime,
                 a2.fluxtime,
                 tfd.inavgratioovermina,
                 tfd.outavgratioovermina,
                 tfd.inavgratiooverminb,
                 tfd.outavgratiooverminb,
                 'M' as state_flag
            from temp_fluxd tfd
            left join (select p.*,
                              substr(p.fluxtime, 1, 8) as fluxdate,
                              row_number() over(partition by circuitid, substr(p.fluxtime, 1, 8) order by inavgvec desc, fluxtime desc) as num_id
                         from temp_flux p) a1 on a1.num_id = 1
                                             and a1.circuitid =
                                                 tfd.circuitid
                                             and a1.fluxdate = tfd.fluxtime
            left join (select p.*,
                              substr(p.fluxtime, 1, 8) as fluxdate,
                              row_number() over(partition by circuitid, substr(p.fluxtime, 1, 8) order by outavgvec desc, fluxtime desc) as num_id
                         from temp_flux p) a2 on a2.num_id = 1
                                             and a2.circuitid =
                                                 tfd.circuitid
                                             and a2.fluxdate = tfd.fluxtime;
        delete from temp_fluxd fd where fd.state_flag = 'O';
        update temp_fluxd fd set fd.state_flag = 'O';
      end if;
      v_step := v_step + 1;
      /*????????L???*/
      if instr(upper(i_dayflu_flag), 'L') > 0 then
        --??????
        select substr(p.paravalue, 1, (instr(p.paravalue, ';') - 1))
          into inlimita
          from syspara p
         where moduleid = 'FluxMgmt'
           and paraname = 'RatioLimit';
        select substr(p.paravalue,
                      (instr(p.paravalue, ';') + 1),
                      length(p.paravalue))
          into outlimita
          from syspara p
         where moduleid = 'FluxMgmt'
           and paraname = 'RatioLimit';
        inlimitb  := substr(inlimita,
                            (instr(inlimita, ':') + 1),
                            length(inlimita));
        inlimita  := substr(inlimita, 1, (instr(inlimita, ':') - 1));
        outlimitb := substr(outlimita,
                            (instr(outlimita, ':') + 1),
                            length(inlimita));
        outlimita := substr(outlimita, 1, (instr(outlimita, ':') - 1));
        --?????????
        delete from flux_num where 1 = 1;
        insert into flux_num
          (circuitid, num, fluxdate)
          select ct.circuitid,
                 avg(f.interval) as interval,
                 substr(f.fluxtime, 1, 8) as fluxdate
            from circuit ct, flux f
           where f.fluxtime > v_begin_date
             and f.fluxtime < v_end_date
             and ct.circuitid = f.circuitid
             and ct.circuitid >= v_groupstart
             and ct.circuitid <= v_groupend
             and ct.changetype = 0
           group by ct.circuitid, substr(f.fluxtime, 1, 8);
        v_step := v_step + 1;
        --????AB??????
        insert into temp_fluxd
          (circuitid,
           fluxtime,
           innonbmaxvec,
           outnonbmaxvec,
           innonbmaxratio,
           outnonbmaxratio,
           inmaxtime,
           outmaxtime,
           inavgratioovermina,
           outavgratioovermina,
           inavgratiooverminb,
           outavgratiooverminb,
           state_flag)
          select tfd.circuitid,
                 tfd.fluxtime,
                 tfd.innonbmaxvec,
                 tfd.outnonbmaxvec,
                 tfd.innonbmaxratio,
                 tfd.outnonbmaxratio,
                 tfd.inmaxtime,
                 tfd.outmaxtime,
                 m.inavgvecmounta * fn.num,
                 m.outavgvecmounta * fn.num,
                 m.inavgvecmountb * fn.num,
                 m.outavgvecmountb * fn.num,
                 'F' as state_flag
            from temp_fluxd tfd
            left join (select ct.circuitid,
                              substr(tf.fluxtime, 1, 8) as fluxdate,
                              sum(case
                                    when (tf.inavgvec * 8 / 1000) /
                                         decode(bandwidth,
                                                null,
                                                1,
                                                0,
                                                1,
                                                bandwidth) * 100 > inlimita then
                                     1
                                    else
                                     0
                                  end) as inavgvecmounta,
                              sum(case
                                    when (tf.inavgvec * 8 / 1000) /
                                         decode(bandwidth,
                                                null,
                                                1,
                                                0,
                                                1,
                                                bandwidth) * 100 > inlimitb then
                                     1
                                    else
                                     0
                                  end) as inavgvecmountb,
                              sum(case
                                    when (tf.outavgvec * 8 / 1000) /
                                         decode(bandwidth,
                                                null,
                                                1,
                                                0,
                                                1,
                                                bandwidth) * 100 > outlimita then
                                     1
                                    else
                                     0
                                  end) as outavgvecmounta,
                              sum(case
                                    when (tf.outavgvec * 8 / 1000) /
                                         decode(bandwidth,
                                                null,
                                                1,
                                                0,
                                                1,
                                                bandwidth) * 100 > outlimitb then
                                     1
                                    else
                                     0
                                  end) as outavgvecmountb
                         from circuit ct, temp_flux tf
                        where ct.circuitid = tf.circuitid
                          and ct.changetype=0
                        group by ct.circuitid, substr(tf.fluxtime, 1, 8)) m on m.circuitid =
                                                                               tfd.circuitid
                                                                           and m.fluxdate =
                                                                               tfd.fluxtime
           inner join flux_num fn on m.circuitid = fn.circuitid
                                 and m.fluxdate = fn.fluxdate;

        delete from temp_fluxd fd where fd.state_flag = 'O';

      end if;
      v_step := v_step + 1;
      --?????????
      update fluxd fd
         set (innonbmaxvec, outnonbmaxvec, innonbmaxratio, outnonbmaxratio, inmaxtime, outmaxtime, inavgratioovermina, outavgratioovermina, inavgratiooverminb, outavgratiooverminb) = (select innonbmaxvec,
                                                                                                                                                                                               outnonbmaxvec,
                                                                                                                                                                                               innonbmaxratio,
                                                                                                                                                                                               outnonbmaxratio,
                                                                                                                                                                                               inmaxtime,
                                                                                                                                                                                               outmaxtime,
                                                                                                                                                                                               inavgratioovermina,
                                                                                                                                                                                               outavgratioovermina,
                                                                                                                                                                                               inavgratiooverminb,
                                                                                                                                                                                               outavgratiooverminb
                                                                                                                                                                                          from temp_fluxd tfd
                                                                                                                                                                                         where fd.circuitid =
                                                                                                                                                                                               tfd.circuitid
                                                                                                                                                                                           and fd.fluxtime =
                                                                                                                                                                                               tfd.fluxtime)
       where fd.circuitid >= v_groupstart
         and fd.circuitid <= v_groupend
         and exists (select *
                from temp_fluxd tfd
               where fd.circuitid = tfd.circuitid
                 and fd.fluxtime = tfd.fluxtime);

      commit;

      --????????????
      if instr(upper(i_dayflu_flag), 'B') > 0 then
        delete from flusumbp
         where sumperiodtype = 'D'
           and instr(upper(sumtype), 'B') > 0
           and groupnum = i_group_id;
        insert into flusumbp
          (sumperiodtype, sumtype, groupnum, bpdate)
          select 'D', 'B', i_group_id, v_end_date from dual;
        commit;
      end if;
      if instr(upper(i_dayflu_flag), 'M') > 0 then
        delete from flusumbp
         where sumperiodtype = 'D'
           and instr(upper(sumtype), 'M') > 0
           and groupnum = i_group_id;
        insert into flusumbp
          (sumperiodtype, sumtype, groupnum, bpdate)
          select 'D', 'M', i_group_id, v_end_date from dual;
        commit;
      end if;
      if instr(upper(i_dayflu_flag), 'L') > 0 then
        delete from flusumbp
         where sumperiodtype = 'D'
           and instr(upper(sumtype), 'L') > 0
           and groupnum = i_group_id;
        insert into flusumbp
          (sumperiodtype, sumtype, groupnum, bpdate)
          select 'D', 'L', i_group_id, v_end_date from dual;
        commit;
      end if;
    end if;
    v_step := v_step + 1;
    --????
    sp_set_process_status(v_sp_name || '-' || i_dayflu_flag,
                          v_begin_date || '-' || substr(v_end_date, 5, 4),
                          2,
                          0,
                          v_step);
    rtn_code := 0;
    rtn_info := v_sp_name || '?????????';
    ---------------------????--------------------------------
    --??????
  else
    v_step := v_step + 1;
    sp_set_process_status(v_sp_name || '-' || i_dayflu_flag,
                          v_begin_date || '-' || substr(v_end_date, 5, 4),
                          2,
                          -1,
                          v_step);
    --????????????
    if i_begin_date > i_end_date then
      update md_process_control p
         set p.error_msg = '??????????'
       where p.process_name = v_sp_name
         and p.stat_data = v_begin_date
         and p.status = -1
         and p.partion_id = 0;
    else
      update md_process_control p
         set p.error_msg = '??????'
       where p.process_name = v_sp_name
         and p.stat_data = v_begin_date
         and p.status = -1
         and p.partion_id = 0;
    end if;
    commit;
    --???????? ????????
  end if;
exception
  when others then
    rollback;
    --??????
    sp_set_process_status(v_sp_name || '-' || i_dayflu_flag,
                          v_begin_date || '-' || substr(v_end_date, 5, 4),
                          0,
                          -1,
                          v_step);
    rtn_code := -1;
    rtn_info := '????????(??' || to_char(v_step) || ')?' || sqlcode ||
                substr(sqlerrm, 1, 200);

end pru_fludgeneral_ora;
/
