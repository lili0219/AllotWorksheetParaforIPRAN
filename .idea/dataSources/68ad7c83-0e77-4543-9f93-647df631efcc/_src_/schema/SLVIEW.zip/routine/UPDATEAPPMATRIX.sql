CREATE procedure updateappmatrix is
  --declare
  v_appcount    number;
  v_newappid    char(8);
  v_newappvalid number;
  v_appid       char(8);
  v_appvalid    number;
  l_count       number;

  cursor c_app(p_aprs in varchar2, p_bprs in varchar2) is
    select count(distinct appid)
      from appinfo
     where testtype = 'AA'
       and ((aprobeid = p_aprs and bprobeid = p_bprs) or
           (aprobeid = p_bprs and bprobeid = p_aprs));
begin
  l_count := 0;
  for c_mtrx in (select a.probeid as aprs,
                        a.matrixenable as amtrx_enable,
                        b.probeid as bprs,
                        b.matrixenable as bmtrx_enable,
                        b.probeip,
                        a.nodecode,
                        regexp_replace(a.probenicinfo, ':[^;]+;', ';') as localint,
                        a.probename || '->' || b.probename as mtrx_name
                   from probehost a, probehost b
                  where a.agentflag = 1
                    and a.validflag = 1
                    and b.agentflag = 1
                    and b.validflag = 1
                    and to_number(substr(a.probeid, 4)) <
                        to_number(substr(b.probeid, 4))
                  order by to_number(substr(a.probeid, 4)),
                           to_number(substr(b.probeid, 4))) loop
    v_appcount := -1;
    if (c_mtrx.amtrx_enable = 1 and c_mtrx.bmtrx_enable = 1) then
      v_newappvalid := 0; --0??
    else
      v_newappvalid := 1; --1??
    end if;
    open c_app(c_mtrx.aprs, c_mtrx.bprs);
    loop
      fetch c_app
        into v_appcount;
      if v_appcount = 0 then
        --????AA??
        --SELECT lpad(appseq.nextval, 5, 0) INTO v_newAppID FROM dual; --??????
        select getnextid('appseq', 'STRING', 'APP', 5)
          into v_newappid
          from dual;
        insert into appinfo
          (appid,
           aprobeid,
           bprobeid,
           localint,
           remoteip,
           appname,
           validflag,
           nodecode,
           apptypeid,
           appsystypeid,
           testtype,
           moniflag,
           appstatus,
           groupno,
           opendate)
        values
          (v_newappid,
           c_mtrx.aprs,
           c_mtrx.bprs,
           c_mtrx.localint,
           c_mtrx.probeip,
           c_mtrx.mtrx_name,
           v_newappvalid,
           c_mtrx.nodecode,
           'APP_PING',
           'APP_PING_DIAL',
           'AA',
           'NN',
           -2,
           0,
           sysdate);
        l_count := l_count + 1;
      elsif v_appcount > 0 then
        select appid, validflag
          into v_appid, v_appvalid
          from appinfo
         where testtype = 'AA'
           and ((aprobeid = c_mtrx.aprs and bprobeid = c_mtrx.bprs) or
               (aprobeid = c_mtrx.bprs and bprobeid = c_mtrx.aprs))
           and rownum = 1;
        if v_newappvalid <> v_appvalid then
          --????????
          update appinfo
             set validflag = v_newappvalid
           where appid = v_appid;
          l_count := l_count + 1;
        end if;
      end if;
      exit;
    end loop;
    close c_app;
    if (l_count >= 100) then
      commit;
      l_count := 0;
    end if;
  end loop;

  --???????????validflag?-1
  update appinfo
     set validflag = -1
   where testtype = 'AA'
     and validflag = 0
     and aprobeid || bprobeid not in
         (select a.probeid || b.probeid as aprsid_bprsid
            from probehost a, probehost b
           where a.agentflag = 1
             and a.validflag = 1
             and b.agentflag = 1
             and b.validflag = 1
             and a.probeid <> b.probeid);
  commit;
end;
/
