CREATE PROCEDURE alarmpipetest
   IS
    l_alarmrec alarmsummary%rowtype ;
    l_starttime varchar2(20) ;
    l_endtime varchar2(20) ;
    l_opertype varchar2(20) ;
    l_pipename varchar2(50) ;
    l_status integer;
    l_sumalarmid varchar2(20);
    l_times varchar2(10);
    l_alarmlevel varchar2(10);
    l_count integer ;
begin
    select 'ALARM_'||username into l_pipename from user_users;
    l_count := 0 ;
    while true loop
        l_status := dbms_pipe.receive_message(l_pipename,1) ;
        if (l_status != 0) then
            exit ;
        end if ;
        dbms_pipe.unpack_message(l_opertype);
        dbms_pipe.unpack_message(l_sumalarmid);
        dbms_pipe.unpack_message(l_alarmrec.alarmtypeid);
        dbms_pipe.unpack_message(l_alarmrec.resid);
        dbms_pipe.unpack_message(l_alarmrec.respara);
        dbms_pipe.unpack_message(l_starttime);
        dbms_pipe.unpack_message(l_endtime);
        dbms_pipe.unpack_message(l_times);
        dbms_pipe.unpack_message(l_alarmlevel);
        dbms_pipe.unpack_message(l_alarmrec.summary);
        dbms_pipe.unpack_message(l_alarmrec.ensummary);
        dbms_output.put_line(substrb(l_opertype||'->'||l_sumalarmid||'->'||l_alarmrec.alarmtypeid||'->'||l_alarmrec.resid||'->'||l_alarmrec.respara
            ||'->'||l_starttime||'->'||l_endtime||'->'||l_times||'->'||l_alarmlevel||'->'||l_alarmrec.summary||'->'||l_alarmrec.ensummary,1,255));
        l_count := l_count + 1 ;
    end loop ;
    dbms_output.put_line(substr('receive message number : '||l_count,1,255));
end ;
/
