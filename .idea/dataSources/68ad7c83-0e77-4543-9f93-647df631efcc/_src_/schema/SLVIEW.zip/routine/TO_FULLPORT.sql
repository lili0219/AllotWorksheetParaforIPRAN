CREATE FUNCTION TO_FULLPORT
(p_port varchar2)
RETURN varchar2 IS
-- ------------------------------------------------------------------------------- --
-- Purpose: ????0???????????00-00-00-00????????????NULL --
-- ------------------------------------------------------------------------------- --
l_return varchar2(11);
l_begin integer;
l_end integer;
l_segint integer;
BEGIN
if p_port is null then
return null;
end if;
l_begin := 1;
l_return := '';
for i in 1..3 loop
l_end := instrb(p_port,'-',l_begin);
if l_end = 0 then
return null;
end if;
l_segint:=to_number(substrb(p_port,l_begin,l_end-l_begin),'99');
if (l_segint<0 or l_segint>99) then
return null;
end if;
l_return := l_return || lpad(to_char(l_segint),2,'0') || '-';
l_begin := l_end + 1;
end loop;
l_segint:=to_number(substrb(p_port,l_begin),'99');
if l_segint<0 or l_segint>99 then
return null;
end if;
l_return := l_return || lpad(to_char(l_segint),2,'0') ;
RETURN l_return ;
EXCEPTION
WHEN others THEN
return null ;
END;
/
