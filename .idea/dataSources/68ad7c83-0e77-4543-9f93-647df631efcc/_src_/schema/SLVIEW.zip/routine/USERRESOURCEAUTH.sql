CREATE FUNCTION userresourceauth (
   i_netuserid   IN   VARCHAR2,
   i_restype     IN   VARCHAR2,
   i_nodecode    IN   VARCHAR2 DEFAULT NULL,
   i_authtype    IN   VARCHAR2 DEFAULT 'CFG'
)
   RETURN resauthresult
IS
   l_return_result   resauthresult;
BEGIN

	/* ?????????*/
	BEGIN
	   refreshuserauth(i_netuserid) ;
	EXCEPTION
		WHEN others THEN
			null ;
	END ;


	/* ???? */

   l_return_result := resauthresult ();

   FOR l_rec in ( SELECT DISTINCT a.resid
                  from singleuserresauth a,res b,
      	             (SELECT  nodecode FROM node START WITH nodecode = decode(i_nodecode,null,'NOD999',i_nodecode) CONNECT BY PRIOR nodecode = fathernodecode) c
                  where a.netuserid=i_netuserid and a.resid=b.resid and (b.nodecodea = c.nodecode or b.nodecodeb=c.nodecode)
                     and a.authtype=i_authtype and (i_restype='ALL' or b.restypeid like i_restype||'%'))   LOOP
      l_return_result.EXTEND;
      l_return_result (l_return_result.LAST) := resauth (l_rec.resid);
   END LOOP;

   RETURN l_return_result;
END;
/
