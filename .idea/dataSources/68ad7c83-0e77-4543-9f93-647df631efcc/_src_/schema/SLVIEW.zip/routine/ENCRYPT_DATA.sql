CREATE FUNCTION encrypt_data(p_text varchar2, p_key varchar2) return varchar2 is
v_text varchar2(2048);
v_enc varchar2(2048);
v_filllen pls_integer ;
begin
--    v_text := rpad( p_text, ceil(length(p_text)/8)*8, chr(0));    oracle9i bug

    v_filllen :=  ceil(lengthb(p_text)/8)*8 -  lengthb(p_text) ;
    v_text := p_text ;
    while (v_filllen > 0) loop
        v_text := v_text || chr(0) ;
        v_filllen := v_filllen - 1 ;
    end loop;

    dbms_obfuscation_toolkit.desencrypt(
    input_string => v_text,
    key_string => p_key,
    encrypted_string=>v_enc);
    return rawtohex(utl_raw.cast_to_raw(v_enc));
exception
    when others then
        return null;
end;
/
