CREATE procedure pru_fluhgeneral_ora(i_dayflu_flag varchar2,
                                                i_group_id    number,
                                                i_begin_date  date,
                                                i_end_date    date,
                                                rtn_code      out number,
                                                rtn_info      out varchar2)

 is
  /*
  -----------------------????--------------------------------
  ????????????????????????????
  ?????2011-10-24
  ????: naym
  ????????????perl??????
       ???????????????????????
       ?????????? ???????
  */
  /*????*/
  --I_GROUP_ID  ??????????????????0 ??? ??????
  --I_BEGIN_DATE I_END_DATE  ????????? ???????YYYY-MM-DD HH24:MI:SS:
  --?????????????????????????????????
  /*RTN_CODE   NUMBER(2);
  RTN_INFO   VARCHAR2(100);*/
  /*??????????*/
  v_status  number(2);
  v_step    number(2) := 0;
  v_sp_name varchar2(40) := 'PRU_FLUHGeneral_ORA';

  /*??????????,????????*/
  --V_NUM        NUMBER;
  v_begin_time varchar2(10) := to_char(i_begin_date, 'YYYYMMDDHH24');
  v_end_time   varchar2(10) := to_char(i_end_date, 'YYYYMMDDHH24');
  --???????
  v_groupstart varchar2(10);
  v_groupend   varchar2(10);

begin
  ----------------------??????-----------------------------
  /*??????????*/
  --I_DAYFLU_FLAG ??? B M L ???
  --?????? ?date??? ??????
  --??????

  v_status := fun_get_process_status(v_sp_name || '-' || i_dayflu_flag,
                                     v_begin_time || '-' ||
                                     substr(v_end_time, 5, 6),
                                     1);
  if v_status = 8 then
    rtn_code := -2;
    rtn_info := '??????';
    return;
  end if;

  -- ?????????
  sp_set_process_status(v_sp_name || '-' || i_dayflu_flag,
                        v_begin_time || '-' || substr(v_end_time, 5, 6),
                        1,
                        8,
                        v_step);

  v_step := 1;
  --????????
  case
    when i_group_id <> 0 then
      select restype || groupstart, restype || groupend
        into v_groupstart, v_groupend
        from flusumgroup fp
       where fp.groupnum = i_group_id;
    when i_group_id = 0 then
      select to_char(min(ct.circuitid)), to_char(max(ct.circuitid))
        into v_groupstart, v_groupend
        from circuit ct;
  end case;
  v_step := 2;
  --????????
  delete from fluxh fh
   where fh.fluxtime >= v_begin_time
     and fh.fluxtime < v_end_time
     and fh.circuitid >= v_groupstart
     and fh.circuitid <= v_groupend;
  commit;
  v_step := 3;
  insert into fluxh
    (circuitid,
     fluxtime,
     inavgvec,
     outavgvec,
     inmaxvec,
     outmaxvec,
     inminvec,
     outminvec,
     inavgratio,
     outavgratio,
     inmaxratio,
     outmaxratio,
     inminratio,
     outminratio /*,
                              INFLOW,
                              OUTFLOW*/)
    select f.circuitid,
           substr(f.fluxtime, 1, 10),
           round(avg(f.inavgvec), 3),
           round(avg(f.outavgvec), 3),
           round(max(f.inavgvec), 3),
           round(max(f.outavgvec), 3),
           round(min(f.inavgvec), 3),
           round(min(f.outavgvec), 3),
           round(avg(f.inavgratio), 2),
           round(avg(f.outavgratio), 2),
           round(max(f.inavgratio), 2),
           round(max(f.outavgratio), 2),
           round(min(f.inavgratio), 2),
           round(min(f.outavgratio), 2) /*,
                               ROUND(SUM(F.INAVGVEC * F.INTERVAL * 60), 3),
                               ROUND(SUM(F.OUTAVGVEC * F.INTERVAL * 60), 3)*/
      from flux f
     where f.fluxtime > v_begin_time
       and f.fluxtime < v_end_time
       and f.circuitid >= v_groupstart
       and f.circuitid <= v_groupend
     group by f.circuitid, substr(f.fluxtime, 1, 10);
  commit;
  --????????????
  delete from flusumbp
   where sumperiodtype = 'H'
     and sumtype = i_dayflu_flag
     and groupnum = i_group_id;
  insert into flusumbp
    (sumperiodtype, sumtype, groupnum, bpdate)
    select 'H', i_dayflu_flag, i_group_id, v_end_time from dual;
  commit;
  v_step := 4;
  --????
  sp_set_process_status(v_sp_name || '-' || i_dayflu_flag,
                        v_begin_time || '-' || substr(v_end_time, 5, 6),
                        1,
                        0,
                        v_step);
  rtn_code := 0;
  rtn_info := v_sp_name || '?????????';
  ---------------------????--------------------------------
exception
  when others then
    rollback;
    --??????
    sp_set_process_status(v_sp_name || '-' || i_dayflu_flag,
                          v_begin_time || '-' || substr(v_end_time, 5, 6),
                          1,
                          -1,
                          v_step);
    rtn_code := -1;
    rtn_info := '????????(??' || to_char(v_step) || ')?' || sqlcode ||
                substr(sqlerrm, 1, 200);

end pru_fluhgeneral_ora;
/
