CREATE PROCEDURE genresperfschema
IS
   --?????????????CURSOR
   CURSOR c_resperftable IS
      SELECT sg.tablename, sg.itemtype, sg.groupid, sg.groupdesc
      FROM ResPerfStoreGroup sg, ResType rt
      WHERE sg.restypeid = rt.restypeid AND rt.perfstoretype = 'SCATTER';
   --????cursor??
   TYPE t_cursortype IS REF CURSOR;
   --??????CURSOR c_resperftable?????
   r_resperftable c_resperftable%ROWTYPE;

BEGIN
   DECLARE
      --???????????
      v_tablename ResPerfStoreGroup.tablename%TYPE;
      v_tabsgroupid ResPerfStoreGroup.groupid%TYPE;
      v_itemtype ResPerfStoreGroup.itemtype%TYPE;
      v_groupdesc ResPerfStoreGroup.groupdesc%TYPE;
      v_daytableanme v_tablename%TYPE;
      --??c_resperftable??????????????
      v_rowtablecolumns VARCHAR2(2000) := ' ';--??????
      v_daytablecolumns VARCHAR2(2000) := ' ';--?????
      v_ifrowtabexist BOOLEAN;
      v_ifdaytabexist BOOLEAN;
   BEGIN
      --????(??????tablename????groupid???)
      OPEN c_resperftable;
         LOOP
            FETCH c_resperftable INTO r_resperftable;
            EXIT WHEN c_resperftable%NOTFOUND;
            --????????????????????+_D?
            v_tablename := r_resperftable.tablename;--?????
            v_daytableanme := v_tablename || '_D';--??????
            v_tabsgroupid := r_resperftable.groupid;
            v_itemtype := r_resperftable.itemtype;
            v_groupdesc := r_resperftable.groupdesc;

            v_rowtablecolumns := ' ' ;
            v_daytablecolumns := ' ' ;

            --?????????????????????????????????
            DECLARE
               --???????
               v_temprowcolunmname VARCHAR2(100);
               --????
               c_tabcolumnrela t_cursortype;
               v_tabscolumnname user_tab_columns.COLUMN_NAME%TYPE;
            BEGIN
               --?????????
               OPEN c_tabcolumnrela FOR
                  'SELECT utc.COLUMN_NAME
                   FROM user_tab_columns utc
                   WHERE utc.TABLE_NAME = UPPER(:1)'
               USING v_tablename;
               --??????????????????????????????
               LOOP
                  FETCH c_tabcolumnrela INTO v_temprowcolunmname;
                  EXIT WHEN c_tabcolumnrela%NOTFOUND;
                  v_rowtablecolumns := v_rowtablecolumns || v_temprowcolunmname || ';';
               END LOOP;
               IF (v_rowtablecolumns <> ' ') THEN
                  v_ifrowtabexist := TRUE;
               ELSE
                  v_ifrowtabexist := FALSE;
               END IF;
               DBMS_OUTPUT.PUT_LINE('???' || v_tablename || '?????:' || v_rowtablecolumns);
               CLOSE c_tabcolumnrela;
            EXCEPTION
               WHEN OTHERS
                  THEN
                     DBMS_OUTPUT.PUT_LINE('???????????????????!');
            END;

            --????????????????????????????????
            DECLARE
               --????????
               v_tempdaycolunmname VARCHAR2(100);
               --????
               c_tabcolumnrela t_cursortype;
               v_tabscolumnname user_tab_columns.COLUMN_NAME%TYPE;
            BEGIN
               --????????
               OPEN c_tabcolumnrela FOR
                  'SELECT utc.COLUMN_NAME
                   FROM user_tab_columns utc
                   WHERE utc.TABLE_NAME = UPPER(:1)'
               USING v_daytableanme;

               --?????????????????????????????
               LOOP
                  FETCH c_tabcolumnrela INTO v_tempdaycolunmname;
                  EXIT WHEN c_tabcolumnrela%NOTFOUND;
                  v_daytablecolumns := v_daytablecolumns || v_tempdaycolunmname || ';';
               END LOOP;
               IF (v_daytablecolumns <> ' ') THEN
                  v_ifdaytabexist := TRUE;
               ELSE
                  v_ifdaytabexist := FALSE;
               END IF;
               DBMS_OUTPUT.PUT_LINE('??' || v_daytableanme || '?????:' || v_daytablecolumns);
               CLOSE c_tabcolumnrela;
            EXCEPTION
               WHEN OTHERS
                  THEN
                     DBMS_OUTPUT.PUT_LINE('??????????????????!');
            END;

            --???????????????????
            DECLARE
            --?????sql
            v_handlerowtablesql VARCHAR2(2000);
            v_handlerowcolumn VARCHAR2(2000) := ' ';
            v_handlerowindexsql VARCHAR2(2000);
            v_handlerowpartitionsql VARCHAR2(2000);
            --????sql
            v_handledaytablesql VARCHAR2(2000);
            v_handledaycolumn VARCHAR2(2000) := ' ';
            v_handledayindexsql VARCHAR2(2000);
            v_handledaypartitionsql VARCHAR2(2000);
            --??????????cursor
            c_tabscolumn t_cursortype;
            --??c_tabscolumn?????
            v_moniitemcode ResPerfStoreGroupItem.moniitemcode%TYPE;
            v_columnname ResPerfStoreGroupItem.columnname%TYPE;
            v_summarytype ResPerfStoreGroupItem.summarytype%TYPE;
            BEGIN
               OPEN c_tabscolumn FOR
               'SELECT DISTINCT sgi.moniitemcode, sgi.columnname, sgi.summarytype ' ||
               'FROM ResPerfStoreGroup sg, ResPerfStoreGroupItem sgi ' ||
               'WHERE sg.groupid = sgi.groupid ' ||
                 'AND sg.groupid = :1'
               USING v_tabsgroupid;

               LOOP
                  FETCH c_tabscolumn INTO v_moniitemcode, v_columnname, v_summarytype;
                  EXIT WHEN c_tabscolumn%NOTFOUND;
                  --???
                  IF (INSTR(v_rowtablecolumns, UPPER(v_columnname || ';'), 1, 1) = 0) THEN
                     v_handlerowcolumn := v_handlerowcolumn || ',' || v_columnname || ' NUMBER(20, 4)';
                  END IF;
                  --??
                  IF (v_summarytype IS NOT NULL) THEN
                     IF (INSTR(v_daytablecolumns, UPPER(v_columnname || ';'), 1, 1) = 0) THEN
                        v_handledaycolumn := v_handledaycolumn || ',' || v_columnname || ' NUMBER(20, 4)';
                     END IF;
                  END IF;
               END LOOP;
               DBMS_OUTPUT.PUT_LINE('????????:' || v_handlerowcolumn);
               DBMS_OUTPUT.PUT_LINE('???????:' || v_handledaycolumn);

              --?????
              BEGIN
                  IF (v_ifrowtabexist = TRUE) THEN
                     IF (v_handlerowcolumn <> ' ') THEN
                        v_handlerowcolumn := SUBSTR(v_handlerowcolumn, 3, LENGTH(v_handlerowcolumn));
                        v_handlerowtablesql :=
                           'ALTER TABLE ' || v_tablename || ' ADD' ||
                           '(' ||
                           v_handlerowcolumn ||
                           ')'
                           ;
                        DBMS_OUTPUT.PUT_LINE(v_handlerowtablesql);
                        EXECUTE IMMEDIATE v_handlerowtablesql;
                     END IF;
                  ELSE
                     --?????
                     v_handlerowtablesql :=
                        'CREATE TABLE ' || v_tablename ||
                        '(' ||
                            'ResID CHAR(8) NOT NULL,';
                     IF (v_itemtype <> 'value') THEN
                        v_handlerowtablesql := v_handlerowtablesql ||
                            'ResPara VARCHAR2(255) NOT NULL,';
                     END IF;
                        v_handlerowtablesql := v_handlerowtablesql ||
                            'ColTime DATE NOT NULL' ||
                        v_handlerowcolumn ||
                        ')' ||
                        ' TABLESPACE DATALIST' ||
                        ' PARTITION BY RANGE (COLTIME)' ||
                        ' (PARTITION  P_20110430 VALUES LESS THAN (TO_DATE(''20110501'', ''YYYYMMDD'')))'
                        ;
                      --???
                      v_handlerowindexsql :=
                         'CREATE INDEX IND_' || v_tablename || '_RES ON ' || v_tablename ||
                         '(RESID';
                      IF (v_itemtype <> 'value') THEN
                         v_handlerowindexsql := v_handlerowindexsql ||
                            ',RESPARA';
                      END IF;
                         v_handlerowindexsql := v_handlerowindexsql ||
                            ') LOCAL TABLESPACE INDEXLIST'
                         ;
                      --???????sql
                      DBMS_OUTPUT.PUT_LINE(v_handlerowtablesql);
                      EXECUTE IMMEDIATE v_handlerowtablesql;
                      DBMS_OUTPUT.PUT_LINE(v_handlerowindexsql);
                      EXECUTE IMMEDIATE v_handlerowindexsql;
                      DBMS_OUTPUT.PUT_LINE(v_handlerowpartitionsql);

                      --??????partitioncleancfg?????????????????90?
                      INSERT INTO PARTITIONCLEANCFG ( TABLE_NAME, HOLDDAYS, PARTITIONTYPE, DATADESC )
                      VALUES (upper(v_tablename), 90, 'DAY',v_groupdesc );

                      COMMIT ;

                      --???????
                      slvw_partition.init_partition(TO_CHAR(SYSDATE, 'YYYYMMDD'), v_tablename);
                      slvw_partition.add_partition(TO_CHAR(SYSDATE + 7, 'YYYYMMDD'), v_tablename);
                  END IF;
               EXCEPTION
                  WHEN OTHERS
                     THEN
                        DBMS_OUTPUT.PUT_LINE('???????!');
               END;


               --????
               BEGIN
                  IF (v_ifdaytabexist = TRUE) THEN
                     IF (v_handledaycolumn <> ' ') THEN
                        v_handledaycolumn := SUBSTR(v_handledaycolumn, 3, LENGTH(v_handledaycolumn));
                        v_handledaytablesql :=
                           'ALTER TABLE ' || v_daytableanme || ' ADD' ||
                           '(' ||
                           v_handledaycolumn ||
                           ')'
                           ;
                      DBMS_OUTPUT.PUT_LINE(v_handledaytablesql);
                      EXECUTE IMMEDIATE v_handledaytablesql;
                      END IF;
                  ELSE
                     --?????
                     v_handledaytablesql :=
                        'CREATE TABLE ' || v_daytableanme ||
                        '(' ||
                            'ResID CHAR(8) NOT NULL,';
                     IF (v_itemtype <> 'value') THEN
                        v_handledaytablesql := v_handledaytablesql ||
                            'ResPara VARCHAR2(255) NOT NULL,';
                     END IF;
                        v_handledaytablesql := v_handledaytablesql ||
                            'DAYID CHAR(8) NOT NULL,' ||
                            'SummaryType VARCHAR2(20) NOT NULL' ||
                        v_handledaycolumn ||
                        ')' ||
                        ' TABLESPACE DATALIST' ||
                        ' PARTITION BY RANGE (DAYID)' ||
                        ' (PARTITION  P_20110430 VALUES LESS THAN (''20110501''))'
                        ;
                      --???
                      v_handledayindexsql :=
                         'CREATE INDEX IND_' || v_daytableanme || '_RES ON ' || v_daytableanme ||
                         '(RESID';
                      IF (v_itemtype <> 'value') THEN
                         v_handledayindexsql := v_handledayindexsql ||
                            ',RESPARA';
                      END IF;
                         v_handledayindexsql := v_handledayindexsql ||
                            ') LOCAL TABLESPACE INDEXLIST'
                         ;

                      --???????sql
                      DBMS_OUTPUT.PUT_LINE(v_handledaytablesql);
                      EXECUTE IMMEDIATE v_handledaytablesql;
                      DBMS_OUTPUT.PUT_LINE(v_handledayindexsql);
                      EXECUTE IMMEDIATE v_handledayindexsql;
                      DBMS_OUTPUT.PUT_LINE(v_handledaypartitionsql);

                      --??????partitioncleancfg??????????????????180?
                      INSERT INTO PARTITIONCLEANCFG ( TABLE_NAME, HOLDDAYS, PARTITIONTYPE, DATADESC )
                      VALUES (upper(v_daytableanme),180,'WEEK',v_groupdesc || '???') ;
                      COMMIT ;

                      --???????
                      slvw_partition.init_partition(TO_CHAR(SYSDATE, 'YYYYMMDD'), v_daytableanme);
                      slvw_partition.add_partition(TO_CHAR(SYSDATE + 7, 'YYYYMMDD'), v_daytableanme);
                  END IF;
               EXCEPTION
                  WHEN OTHERS
                     THEN
                        DBMS_OUTPUT.PUT_LINE('??????!');
               END;
            EXCEPTION
               WHEN OTHERS
                  THEN
                     DBMS_OUTPUT.PUT_LINE('?????????????!');
            END;
         END LOOP;
      CLOSE c_resperftable;
   EXCEPTION
      WHEN OTHERS
         THEN
            DBMS_OUTPUT.PUT_LINE('????c_resperftable??!');
   END;
END;
/
