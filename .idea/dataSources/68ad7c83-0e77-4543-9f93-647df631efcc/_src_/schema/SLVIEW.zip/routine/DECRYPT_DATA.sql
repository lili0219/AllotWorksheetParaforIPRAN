CREATE FUNCTION decrypt_data(p_text varchar2,p_key varchar2) return varchar2 is
v_text varchar2(2048);
v_enc varchar2(2048);
begin
    v_enc := utl_raw.cast_to_varchar2(hextoraw(p_text)) ;
    dbms_obfuscation_toolkit.desdecrypt(
    input_string => v_enc,
    key_string => p_key,
    decrypted_string=> v_text);
    return rtrim(v_text,chr(0));
exception
    when others then
        return null;
end;
/
