CREATE procedure prc_sp_apnbwlistdis
 (
 o_retdesc out varchar2 --????
)
as
 begin
--step1??????3???? disapnl3rule
--step1.1??????????????
execute immediate 'truncate table disapnl3rule';
--step1.2?????????3????
o_retdesc := 'SQL Step1.2';
 insert into disapnl3rule (deviceid, rule, filtergrp, categorygrp,
 upofflinecbbid, uponlinecbbid,
 downofflinecbbid, downonlinecbbid,
 filter, protocol, ip, mask, port,
 updatetime)
--???????????
with l3rule_tmp1 as
 (select deviceid, rule, filtergrp, categorygrp, l7rule
 from devcolrule
 where l7rule is null
 or (filtergrp <> 'any' and l7rule is not null)
 ),
--??devcolchargeproperty ? devcolcbbid
 chargepro_tmp as
 (select deviceid, chargeproperty,
 case when (deviceid, uponlinecbbid) in (select deviceid, cbbid from devcolcbbid) then uponlinecbbid else null end uponlinecbbid,
 case when (deviceid, upofflinecbbid) in (select deviceid, cbbid from devcolcbbid) then upofflinecbbid else null end upofflinecbbid,
 case when (deviceid, downonlinecbbid) in (select deviceid, cbbid from devcolcbbid) then downonlinecbbid else null end downonlinecbbid,
 case when (deviceid, downofflinecbbid) in (select deviceid, cbbid from devcolcbbid) then downofflinecbbid else null end downofflinecbbid
 from devcolchargeproperty
 ),
--??devcolcategorygrp ? tmp_chargepro
 l3rule_tmp2 as
 (select tmp1.deviceid,tmp1.rule,tmp1.filtergrp,tmp1.categorygrp,
 chargepro.upofflinecbbid,
 chargepro.uponlinecbbid,
 chargepro.downofflinecbbid,
 chargepro.downonlinecbbid
 from l3rule_tmp1 tmp1,
 devcolcategorygrp categrp,
 chargepro_tmp chargepro
 where tmp1.deviceid = categrp.deviceid(+)
 and tmp1.categorygrp = categrp.categorygrp(+)
 and categrp.deviceid = chargepro.deviceid(+)
 and categrp.chargeproperty = chargepro.chargeproperty(+)
 ),
--??devcolfiltergrp?devcolfilter
 l3rule_tmp3 as
 (select tmp2.deviceid,tmp2.rule,tmp2.filtergrp,tmp2.categorygrp,
 tmp2.upofflinecbbid,tmp2.uponlinecbbid,tmp2.downofflinecbbid,
 tmp2.downonlinecbbid,filtergrp.filter,filter.protocol,
 filter.ip,filter.mask,filter.port
 from l3rule_tmp2 tmp2,
 devcolfiltergrp filtergrp,
 devcolfilter filter
 where tmp2.deviceid = filtergrp.deviceid(+)
 and tmp2.filtergrp = filtergrp.filtergrp(+)
 and filtergrp.deviceid = filter.deviceid(+)
 and filtergrp.filter = filter.filter(+)
 )
 select tmp3.deviceid,tmp3.rule,tmp3.filtergrp,tmp3.categorygrp,
 tmp3.upofflinecbbid,tmp3.uponlinecbbid,
 tmp3.downofflinecbbid,tmp3.downonlinecbbid,
 tmp3.filter,tmp3.protocol,tmp3.ip,tmp3.mask,tmp3.port,
 sysdate updatetime
 from l3rule_tmp3 tmp3;
--???????????
commit;

--step2??????7???? disapnl7rule
--step2.1??????????????
execute immediate 'truncate table disapnl7rule';
--step2.2?????????7????
o_retdesc := 'SQL Step2.2';
 insert into disapnl7rule (deviceid, rule, l7rule, categorygrp,
 upofflinecbbid, uponlinecbbid,
 downofflinecbbid, downonlinecbbid,
 protocol, l7infogrp,
 l7info, type, url,
 updatetime)
--????7????????
with l7rule_tmp1 as
 (select deviceid, rule, filtergrp, categorygrp, l7rule
 from devcolrule
 where filtergrp='any'
 and l7rule is not null
 ),
-- devcoll7infogrp ?? devcoll7info
 l7info_tmp as
 (select l7infogrp.deviceid,l7infogrp.l7infogrp,l7info.l7info,
 l7info.categorygrp,l7info.type,l7info.url
 from devcoll7infogrp l7infogrp,devcoll7info l7info
 where l7infogrp.deviceid = l7info.deviceid(+)
 and l7infogrp.l7info = l7info.l7info(+)
 ),
--devcoll7rule ?? l7info_tmp
 l7rule_tmp2 as
 (select l7rule.deviceid,l7rule.l7rule,l7rule.protocol,
 l7info_tmp.l7infogrp,l7info_tmp.categorygrp,
 l7info_tmp.l7info,l7info_tmp.type,l7info_tmp.url
 from devcoll7rule l7rule,l7info_tmp
 where l7rule.deviceid = l7info_tmp.deviceid(+)
 and l7rule.l7infogrp = l7info_tmp.l7infogrp
 ),
-- devcolchargeproperty ?? devcolcbbid
 chargepro_tmp as
 (select deviceid, chargeproperty,
 case when (deviceid,upofflinecbbid) in (select deviceid,cbbid from devcolcbbid) then upofflinecbbid else null end upofflinecbbid,
 case when (deviceid,uponlinecbbid) in (select deviceid,cbbid from devcolcbbid) then uponlinecbbid else null end uponlinecbbid,
 case when (deviceid,downofflinecbbid) in (select deviceid,cbbid from devcolcbbid) then downofflinecbbid else null end downofflinecbbid,
 case when (deviceid,downonlinecbbid) in (select deviceid,cbbid from devcolcbbid) then downonlinecbbid else null end downonlinecbbid
 from devcolchargeproperty
 ),
-- ?? devcolcategorygrp
 l7rule_tmp3 as
 (select tmp1.deviceid,tmp1.rule,tmp1.l7rule,
 chargepro.upofflinecbbid,
 chargepro.uponlinecbbid,
 chargepro.downofflinecbbid,
 chargepro.downonlinecbbid
 from l7rule_tmp1 tmp1,
 chargepro_tmp chargepro,
 devcolcategorygrp categrp
 where tmp1.deviceid = categrp.deviceid(+)
 and tmp1.categorygrp = categrp.categorygrp(+)
 and categrp.deviceid = chargepro.deviceid(+)
 and categrp.chargeproperty = chargepro.chargeproperty(+)
 )
 select tmp3.deviceid,tmp3.rule,tmp3.l7rule,tmp2.categorygrp,
 tmp3.upofflinecbbid,tmp3.uponlinecbbid,
 tmp3.downofflinecbbid,tmp3.downonlinecbbid,
 tmp2.protocol,tmp2.l7infogrp,
 tmp2.l7info,tmp2.type,tmp2.url,
 sysdate updatetime
 from l7rule_tmp3 tmp3,l7rule_tmp2 tmp2
 where tmp3.deviceid = tmp2.deviceid
 and tmp3.l7rule = tmp2.l7rule;
--???????????
commit;

--step3????????????? disapnruleinfo
--step3.1??????????????
execute immediate 'truncate table disapnruleinfo';
 o_retdesc := 'SQL Step3.2';
--step3.2???????????????
insert into disapnruleinfo (deviceid, apnname, userprofilegrp, userprofile, rule,
 listtype,
 updatetime)
 with disapnruleinfo_tmp1 as
 (select apninfo.deviceid,apninfo.apnname,
 apninfo.userprofilegrp,profilegrp.userprofile
 from apninfo ,devcoluserprofilegrp profilegrp
 where apninfo.deviceid = profilegrp.deviceid
 and apninfo.userprofilegrp = profilegrp.userprofilegrp
 --bugid111801
 --and apninfo.pccswitch<>'enable'
 and (select ','||trim(paravalue)||',' from syspara where paraname='USERPROFILEGRPFILTER')
 not like '%,'||apninfo.userprofilegrp||',%'
 ),
 disapnruleinfo_tmp2 as
 (select tmp1.deviceid,tmp1.apnname,
 tmp1.userprofilegrp,tmp1.userprofile,profile.rule
 from disapnruleinfo_tmp1 tmp1,devcoluserprofile profile
 where tmp1.deviceid = profile.deviceid
 and tmp1.userprofile = profile.userprofile
 ),
 disapnruleinfo_tmp3 as
 (select deviceid,apnname,userprofilegrp,userprofile,rule,
 case when lower(rule)='r_block_any' then 'cg_pass'
 else nvl((select disl7.categorygrp from disapnl7rule disl7 where tmp2.deviceid = disl7.deviceid and tmp2.rule = disl7.rule and rownum = 1),
 (select disl3.categorygrp from disapnl3rule disl3 where tmp2.deviceid = disl3.deviceid and tmp2.rule = disl3.rule and rownum = 1)
 )
 end listtype
 from disapnruleinfo_tmp2 tmp2
 )
 select deviceid, apnname, userprofilegrp, userprofile, rule,
 decode(listtype,null,null,'cg_pass','???','cg_block','???','????') listtype,
 sysdate updatetime
 from disapnruleinfo_tmp3 tmp3;
--???????????
commit;

--step4??????????????
--step4.1???3???apnl3rule
 execute immediate 'truncate table apnl3rule';
 o_retdesc := 'SQL Step4.1';
 insert into apnl3rule (deviceid, rule, filtergrp, categorygrp, upofflinecbbid, uponlinecbbid,
 downofflinecbbid, downonlinecbbid, filter, protocol, ip, mask, port, updatetime)
 select deviceid, rule, filtergrp, categorygrp, upofflinecbbid, uponlinecbbid,
 downofflinecbbid, downonlinecbbid, filter, protocol, ip, mask, port, updatetime
 from disapnl3rule;
--???????
commit;
--step4.2???7???apnl7rule
 execute immediate 'truncate table apnl7rule';
 o_retdesc := 'SQL Step4.2';
 insert into apnl7rule (deviceid, rule, l7rule, categorygrp, upofflinecbbid, uponlinecbbid,
 downofflinecbbid, downonlinecbbid, protocol, l7infogrp, l7info,
 type, url, updatetime)
 select deviceid, rule, l7rule, categorygrp, upofflinecbbid, uponlinecbbid,
 downofflinecbbid, downonlinecbbid, protocol, l7infogrp, l7info,
 type, url, updatetime
 from disapnl7rule;
--???????
commit;
--step4.3???????apnruleinfo
 execute immediate 'truncate table apnruleinfo';
 o_retdesc := 'SQL Step4.3';
 insert into apnruleinfo (deviceid, apnname, userprofilegrp, userprofile, rule, listtype, updatetime)
 select deviceid, apnname, userprofilegrp, userprofile, rule, listtype, updatetime
 from disapnruleinfo;

--???????
commit;
--????
o_retdesc := 'Succeed';
--????
exception when others then
 o_retdesc := 'Failed on'||o_retdesc||'with sqlcode:'||SQLCODE;
 rollback;
 end prc_sp_apnbwlistdis;

/
