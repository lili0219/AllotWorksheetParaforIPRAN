CREATE PROCEDURE VPLSVPNSiteLinkDisc IS
begin
 delete from VPLSVPNSite2Site;
 insert into VPLSVPNSite2Site(ID,FromSite,ToSite)
select rownum,fromsite,tosite from
(select distinct c1.siteid fromsite,c2.siteid tosite
  from vplsvpnlink l1, pe p1, device d1, ce c1, vplsvpnlink l2, pe p2, device d2, ce c2
 where l1.vpnid = l2.vpnid
   and l1.peid = p1.peid
   and p1.deviceid = d1.deviceid
   and l1.ceid = c1.ceid
   and l2.peid = p2.peid
   and p2.deviceid = d2.deviceid
   and l2.ceid = c2.ceid
   and (l1.staticldppeers = d2.loopaddress
     or l1.staticldppeers like d2.loopaddress||',%'
     or l1.staticldppeers like '%,'||d2.loopaddress
     or l1.staticldppeers like '%,'||d2.loopaddress||',%')
   and (l2.staticldppeers = d1.loopaddress
     or l2.staticldppeers like d1.loopaddress||',%'
     or l2.staticldppeers like '%,'||d1.loopaddress
     or l2.staticldppeers like '%,'||d1.loopaddress||',%')
   and c1.siteid < c2.siteid);
end;
/
