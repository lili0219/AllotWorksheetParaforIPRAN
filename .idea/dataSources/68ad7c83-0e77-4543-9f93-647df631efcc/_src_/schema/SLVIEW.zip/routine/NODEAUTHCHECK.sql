CREATE FUNCTION NODEAUTHCHECK
  ( i_netuserid IN varchar2,
    i_nodecode IN varchar2,
    i_authtype IN varchar2 default 'CFG')
  RETURN  number IS

  l_result number;
  l_authtype varchar2(20);
BEGIN
    /*??????*/
    if (upper(i_authtype) = 'CFG') then
        l_authtype := 'CFG' ;
    elsif (upper(i_authtype) = 'VIEW') then
        l_authtype := 'CFG,VIEW' ;
    else
        return (0) ;
    end if;

    begin
        select 1 into l_result
        from userresauth
        where netuserid = i_netuserid
            and instr(l_authtype,authtype)>0
            and restypeid = 'ALL'
            and nodecode in (select nodecode from node start with nodecode=i_nodecode
                    connect by prior fathernodecode = nodecode )
            and rownum = 1 ;
    exception
        when no_data_found then
            l_result := 0 ;
    end;

    RETURN l_result ;
END;
/
