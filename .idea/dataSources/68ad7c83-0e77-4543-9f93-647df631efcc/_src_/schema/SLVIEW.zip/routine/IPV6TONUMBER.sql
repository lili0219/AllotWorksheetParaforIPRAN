CREATE FUNCTION ipv6tonumber
  ( p_ipaddr varchar2)
  RETURN  number IS
-- ????: ?ipv6???????
   l_begin integer;
   l_end integer;
   l_segint integer;
   l_return number ;
   l_count integer ;
   l_padstr varchar2(50) ;
   l_ipaddr varchar2(50) ;
BEGIN

    if p_ipaddr like '%::%' then
        l_count := 0 ;
        l_padstr := '0' ;
        for i in 1..length(p_ipaddr) loop
            if substrb(p_ipaddr,i,1)=':' then
                l_count := l_count + 1 ;
            end if ;
        end loop ;
        for i in 1..7-l_count loop
            l_padstr := l_padstr || ':0' ;
        end loop ;
        l_ipaddr := replace(p_ipaddr,'::',':'||l_padstr||':') ;
    else
        l_ipaddr := p_ipaddr ;
    end if ;

    if (substrb(l_ipaddr,1,1)=':') then
        l_ipaddr:='0'||l_ipaddr ;
    end if ;
    if (substrb(l_ipaddr,-1,1)=':') then
        l_ipaddr:=l_ipaddr||'0' ;
    end if ;

    l_begin := 1;
    l_return := 0;
    for i in 1..7 loop
        l_end := instrb(l_ipaddr,':',l_begin);
        if l_end = 0 then
            return null;
        end if;
        l_segint:=to_number(substrb(l_ipaddr,l_begin,l_end-l_begin),'xxxx');
        l_return := l_return + l_segint * power(65536,8-i);
        l_begin := l_end + 1;
    end loop;
    l_return := l_return + to_number(substrb(l_ipaddr,l_begin),'xxxx');

    return l_return ;

EXCEPTION
   WHEN others THEN
       return null ;
END;
/
