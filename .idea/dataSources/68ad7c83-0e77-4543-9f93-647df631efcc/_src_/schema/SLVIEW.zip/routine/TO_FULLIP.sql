CREATE FUNCTION TO_FULLIP
  ( p_ipaddr varchar2)
  RETURN  varchar2 IS
-- Purpose: ?IP???0??????????010.000.000.001?????IP???????NULL
--
-- MODIFICATION HISTORY
-- Person      Date    Comments
-- ---------   ------  -------------------------------------------
   l_return varchar2(15);
   l_begin integer;
   l_end integer;
   l_segint integer;
BEGIN
    if p_ipaddr is null then
        return null;
    end if;
    l_begin := 1;
    l_return := '';
    for i in 1..3 loop
        l_end := instrb(p_ipaddr,'.',l_begin);
        if l_end = 0 then
            return null;
        end if;
        l_segint:=to_number(substrb(p_ipaddr,l_begin,l_end-l_begin+1),'999');
        if (l_segint<0 or l_segint>255) then
            return null;
        end if;
        l_return := l_return || lpad(to_char(l_segint),3,'0') || '.';
        l_begin := l_end + 1;
    end loop;
    l_segint:=to_number(substrb(p_ipaddr,l_begin),'999');
    if l_segint<0 or l_segint>255 then
        return null;
    end if;
    l_return := l_return || lpad(to_char(l_segint),3,'0') ;

    RETURN l_return ;
EXCEPTION
   WHEN others THEN
       return null ;
END;
/
