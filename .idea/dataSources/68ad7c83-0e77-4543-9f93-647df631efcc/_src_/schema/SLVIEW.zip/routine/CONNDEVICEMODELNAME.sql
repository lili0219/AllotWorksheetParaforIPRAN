CREATE function connDeviceModelName(modelid  varchar2,
                                     opentype varchar2,
                                     dcode  varchar2) return varchar2 is
  Result varchar2(4000);
  cursor list_cur IS
    select distinct(a.devicemodelname)  devicemodelname
      from servcfgtemplet t, devicemodel a
     where t.servmodelid = modelid
       and t.servopertype = opentype
       and t.devrolecode = dcode
       and t.devicemodelcode = a.devicemodelcode(+)
     order by a.devicemodelname;
begin

Result :='';
  for v_cur in list_cur loop

    Result := Result || v_cur.devicemodelname || ';';

  end loop;
  Result:= rTRIM(Result,';');
  return (Result);
end connDeviceModelName;
/
