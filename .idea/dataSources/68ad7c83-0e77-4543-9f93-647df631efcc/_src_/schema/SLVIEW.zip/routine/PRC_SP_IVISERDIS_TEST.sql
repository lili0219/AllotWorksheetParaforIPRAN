CREATE procedure prc_sp_iviserdis_test(o_retdesc out varchar2) as
begin
  begin
    --  ??????iviservdetail????iviserv?????
    execute immediate 'truncate table iviservdetail';
    --  iviservdetail??????????deviceid???
    insert into iviservdetail
      (ipsegment, deviceid, nataddr, ippoolname)
      with tmp_policy as
       (select dcp.addrgrpname,
               dcp.ipsegment,
               deviceip,
               func_trans_ip_str2int(startip) nstartip,
               func_trans_ip_str2int(endip) nendip
        --fun_transipmask(dcp.ip||'/'||dcp.mask) ipsegment,
        --substr(fun_transipmask(dcp.ip||'/'||dcp.mask,2),1,instr(fun_transipmask(dcp.ip||'/'||dcp.mask,2),'-',1,1) - 1) nstartip,
        --substr(fun_transipmask(dcp.ip||'/'||dcp.mask,2),instr(fun_transipmask(dcp.ip||'/'||dcp.mask,2),'-',1,1) + 1,15) nendip
          from devcolpolicy dcp),
      rst as
       (select dcp.ipsegment,
               ips.deviceid,
               dcna.startip || '-' || dcna.endip nataddr,
               ips.ippoolname
          from apninfo          ai,
               ippoolsection    ips,
               tmp_policy       dcp,
               devColnataddrgrp dcna,
               devColippool     dcip
         where ai.ippoolname LIKE '%' || ips.ippoolname || '%'
              --where ai.ippoolname = ips.ippoolname
           and ai.deviceid = ips.deviceid
           and ips.ippoolname = dcip.ippoolname
           and dcip.vpninstance is null
           and dcp.addrgrpname = dcna.addrgrpname(+)
           and dcp.deviceip = dcna.deviceip(+)
           and dcp.nstartip <= func_trans_ip_str2int(ips.startip)
           and func_trans_ip_str2int(ips.endip) <= dcp.nendip)
      select distinct ipsegment,
                      first_value(deviceid) over(partition by ipsegment order by 1) deviceid,
                      first_value(nataddr) over(partition by ipsegment order by 1) nataddr,
                      first_value(ippoolname) over(partition by ipsegment order by 1) ippoolname
        from rst;

    o_retdesc := 'Succeed to refreash iviservdetail !';
    commit;
  exception
    when others then
      o_retdesc := 'Failed ORA--' || sqlcode;
      rollback;
      return;
  end;

  begin
    delete from iviserv i
     where i.status != 1
       and not exists (select 1
              from iviservdetail isd, apninfo ai
             where isd.deviceid = ai.deviceid
               and isd.ippoolname = ai.ippoolname
               and i.apnname = ai.apnname);

    merge into iviserv i
    using (select distinct ai.apnname,
                           first_value(ai.ippoolname) over(partition by ai.apnname order by ser.isselfippool nulls last) ippoolname,
                           first_value(ser.isselfippool) over(partition by ai.apnname order by ser.isselfippool nulls last) isselfippool
             from iviservdetail isd, apninfo ai, iviserv ser
            where isd.deviceid = ai.deviceid
              --and isd.ippoolname = ai.ippoolname
              AND ai.ippoolname LIKE '%' || isd.ippoolname || '%'
              and isd.ippoolname = ser.ippoolname(+)) a
    on (i.apnname = a.apnname)
    when matched then
      update
         set i.ippoolname = a.ippoolname, status = 0, updatetime = sysdate
    when not matched then
      insert
        (apnname, ippoolname, status, isselfippool, opendate, updatetime)
      values
        (a.apnname, a.ippoolname, 0, a.isselfippool, sysdate, sysdate);

    o_retdesc := o_retdesc || ' and Succeed to refreash iviserv !';
    commit;
  exception
    when others then
      o_retdesc := 'Failed ORA--' || sqlcode;
      rollback;
      return;
  end;
end prc_sp_iviserdis_test;
/
