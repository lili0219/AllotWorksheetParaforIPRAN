CREATE procedure pru_check_2_his(table_name varchar2,
                                            rtn_code   out number,
                                            rtn_info   out varchar2)

 is
  /*
  -----------------------????--------------------------------
  ?????6.2. ???????????
  ?????2012-7-24
  ????: naym
  ???
  */
  v_step number;
begin
  ----------------------??????-----------------------------
  v_step := 0;

  if (upper(table_name) in
     ('DEV_CFG', 'DEV_PERF', 'DEV_CFGFILE', 'DEV_CHECK')) then
    ---?? DC_DevErrorTmp ???
    ---?????????
    insert into dc_deverrorhis
      select * from dc_deverrortmp where checkitemcode = table_name;

    ---?????????????????????
    delete from dc_deverrorcur cr
     where cr.checkitemcode = table_name
       and not exists
     (select 1
              from dc_deverrortmp cp
             where cp.deviceid = cr.deviceid
               and cp.checkitemcode = cr.checkitemcode);
    ---???????????????????
    insert into dc_deverrorcur
      select deviceid,
             checkitemcode,
             sysdate,
             sysdate,
             probeip,
             probeno,
             checkresult,
             diagresult,
             '0'
        from dc_deverrortmp cr
       where cr.checkitemcode = table_name
         and not exists
       (select 1
                from dc_deverrorcur cp
               where cp.deviceid = cr.deviceid
                 and cp.checkitemcode = cr.checkitemcode);

    ---????????
    update dc_deverrorcur cr
       set lastchecktime = sysdate,
           duration      = (sysdate - starttime) * 24 * 60,
           diagresult    = (select cp.diagresult
                              from dc_deverrortmp cp
                             where cp.deviceid = cr.deviceid
                               and cp.checkitemcode = cr.checkitemcode)
     where cr.checkitemcode = table_name
       and exists (select 1
              from dc_deverrortmp cp
             where cp.deviceid = cr.deviceid
               and cp.checkitemcode = cr.checkitemcode);
    commit;
    ---??Tmp?
    delete from dc_deverrortmp where checkitemcode = table_name;
    commit;

  elsif (upper(table_name) = 'CIR_FLUX') then

    ---?? dc_cirerrortmp ???
    ---?????????
    insert into dc_cirerrorhis
      select * from dc_cirerrortmp;

    ---?????????????????????
    delete from dc_cirerrorcur cr
     where not exists (select 1
              from dc_cirerrortmp cp
             where cp.circuitid = cr.circuitid
               and cp.checkitemcode = cr.checkitemcode);
    ---???????????????????
    insert into dc_cirerrorcur
      select circuitid,
             checkitemcode,
             sysdate,
             sysdate,
             probeip,
             probeno,
             checkresult,
             diagresult,
             '0'
        from dc_cirerrortmp cr
       where not exists (select 1
                from dc_cirerrorcur cp
               where cp.circuitid = cr.circuitid
                 and cp.checkitemcode = cr.checkitemcode);

    ---????????
    update dc_cirerrorcur cr
       set lastchecktime = sysdate,
           duration      = (sysdate - starttime) * 24 * 60,
           diagresult    = (select cp.diagresult
                              from dc_cirerrortmp cp
                             where cp.circuitid = cr.circuitid
                               and cp.checkitemcode = cr.checkitemcode)
     where exists (select *
              from dc_cirerrortmp cp
             where cp.circuitid = cr.circuitid
               and cp.checkitemcode = cr.checkitemcode);
    commit;
    ---??Tmp?
    delete from dc_cirerrortmp where 1 = 1;
    commit;
  elsif (upper(table_name) = 'PERFALARM') then

    ---?? dc_perfalarmerrortmp ???
    ---?????????
    insert into dc_cirerrorhis
      select * from dc_cirerrortmp;

    ---?????????????????????
    delete from dc_perfalarmerrorcur cr
     where not exists (select *
              from dc_perfalarmerrortmp cp
             where cp.probeip = cr.probeip);
    ---???????????????????
    insert into dc_perfalarmerrorcur
      select probeip, sysdate, sysdate, checkresult, diagresult, '0'
        from dc_perfalarmerrortmp cr
       where not exists (select *
                from dc_perfalarmerrorcur cp
               where cp.probeip = cr.probeip);

    ---????????
    update dc_perfalarmerrorcur cr
       set lastchecktime = sysdate,
           duration      = (sysdate - starttime) * 24 * 60,
           DIAGRESULT    = (select cp.DIAGRESULT
              from dc_perfalarmerrortmp cp
             where cp.probeip = cr.probeip)
     where exists (select *
              from dc_perfalarmerrortmp cp
             where cp.probeip = cr.probeip);
    commit;
    ---??Tmp?
    delete from dc_perfalarmerrortmp where 1 = 1;
    commit;

  end if;
  rtn_code := 0;
  rtn_info := '?????';
  ---------------------????--------------------------------
exception
  when others then
    rollback;
    rtn_code := -1;
    rtn_info := '????????(??' || to_char(v_step) || ')?' || sqlcode ||
                substr(sqlerrm, 1, 200);

end pru_check_2_his;
/
