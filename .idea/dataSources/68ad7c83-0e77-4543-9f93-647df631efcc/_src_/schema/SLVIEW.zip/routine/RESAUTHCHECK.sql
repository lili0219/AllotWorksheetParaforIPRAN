CREATE FUNCTION RESAUTHCHECK (
   i_netuserid   IN   VARCHAR2,
   i_resid       IN   VARCHAR2,
   i_authtype    IN   VARCHAR2 DEFAULT 'CFG'
)
   RETURN NUMBER
IS
   l_result     NUMBER;
   l_authtype   VARCHAR2 (20);
   l_res        res%ROWTYPE;
   l_restypeid  VARCHAR2(20);

BEGIN
	/* ?????????*/
	BEGIN
	   refreshuserauth(i_netuserid) ;
	EXCEPTION
		WHEN others THEN
			null ;
	END ;


	/* ???? */
	BEGIN
	   select 1
	   into l_result
	   from singleuserresauth
	   where netuserid=i_netuserid and resid=i_resid and authtype=i_authtype ;
    EXCEPTION
        WHEN others THEN
            l_result := 0 ;
    END ;


   RETURN l_result;
END;
/
