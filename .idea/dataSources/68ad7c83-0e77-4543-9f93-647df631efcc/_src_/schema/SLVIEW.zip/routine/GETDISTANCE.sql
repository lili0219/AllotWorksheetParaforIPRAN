CREATE FUNCTION GetDistance(lat1 number,
                                       lng1 number,
                                       lat2 number,
                                       lng2 number) RETURN NUMBER is
  earth_padius number := 6378.137;
  radLat1      number := Radian(lat1);
  radLat2      number := Radian(lat2);
  a            number := radLat1 - radLat2;
  b            number := Radian(lng1) - Radian(lng2);
  s            number := 0;
begin
  s := 2 *
       Asin(Sqrt(power(sin(a / 2), 2) +
                 cos(radLat1) * cos(radLat2) * power(sin(b / 2), 2)));
  s := s * earth_padius;
  s := Round(s * 10000) / 10000;
  return s;
end;
/
