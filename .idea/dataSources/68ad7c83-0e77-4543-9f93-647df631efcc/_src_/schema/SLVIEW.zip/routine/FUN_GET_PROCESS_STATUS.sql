CREATE FUNCTION FUN_GET_PROCESS_STATUS(IN_SP_NAME    IN VARCHAR2,
                                                  IN_STAT_DATA  IN VARCHAR2,
                                                  IN_PARTION_ID IN NUMBER)
  RETURN NUMBER IS
  /*
  * ?    ?: ??????????????
  * @author ???
  * @date   2011-10-24
  * @version 1
  * @param    in_sp_name     ??????
  * @param    in_stat_data   ????????
  * @param    in_partion_id  ????
  * @????:
  */
  CONST_READY NUMBER := 9;
  RESULT NUMBER;
BEGIN
  SELECT STATUS
    INTO RESULT
    FROM MD_PROCESS_CONTROL
   WHERE TRIM(UPPER(PROCESS_NAME)) = TRIM(UPPER(IN_SP_NAME))
     AND STAT_DATA = IN_STAT_DATA
     AND PARTION_ID = IN_PARTION_ID;
  RETURN(RESULT);
EXCEPTION
  WHEN NO_DATA_FOUND THEN
    SP_SET_PROCESS_STATUS(IN_SP_NAME,
                          IN_STAT_DATA,
                          IN_PARTION_ID,
                          CONST_READY,
                          0);
    RETURN CONST_READY;
END FUN_GET_PROCESS_STATUS;
/
