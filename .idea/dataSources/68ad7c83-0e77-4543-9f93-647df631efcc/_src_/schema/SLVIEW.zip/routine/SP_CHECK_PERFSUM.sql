CREATE procedure sp_check_perfsum(rtn_code out number,
                                             rtn_info out varchar2)

 is
  /*
  -----------------------????--------------------------------
  ?????????????DC_Check_PERFSUM
  ?????2012-7-21
  ????: naym
  ???
  */
  v_step      number;
  v_count     number;
  v_error     varchar2(2000);
  v_sql       varchar2(2000);
  v_status    number;
  v_oldstatus number;
  v_begindate date;
begin
  ----------------------??????-----------------------------
  v_step := 0;

  --????????
  select count(*) into v_count from resmonicurinfo where resid like 'DEV%';

  if (v_count > 0) then
    select count(*)
      into v_count
      from resmonidailyinfo
     where dayid = to_char(sysdate - 1, 'YYYYMMDD');
    if (v_count = 0) then
      v_error := '????????ResMoniDailyInfo';
    end if;
  end if;
  v_step := 1;
  ---???????
  for v_table in (select t.table_name
                    from resperfstoregroup p, user_tables t
                   where t.table_name = upper(p.tablename)) loop

    v_sql := 'select count(*)
                from ' || v_table.table_name || '_D
               where dayid >= to_char(sysdate-1,''YYYYMMDD'')
                 and dayid < to_char(sysdate,''YYYYMMDD'')';

    execute immediate v_sql
      into v_count;

    v_step := 2;
    if (v_count = 0 and v_error is not null) then
      v_error := v_error || ',' || v_table.table_name;
    elsif (v_count = 0 and v_error is null) then
      v_error := '????????' || v_table.table_name || '_D';
    end if;
  end loop;
  v_step := 3;
  if (v_error is null) then
    v_status := 1;
  else
    v_status := 0;
  end if;
  v_step := 4;
  --??????????
  select count(*)
    into v_count
    from dc_funcerror
   where checkitemcode = 'PERFSUM';
  v_step := 5;
  if (v_count = 0) then
    insert into dc_funcerror
    values
      ('PERFSUM', sysdate, sysdate, v_status, v_error, '0');
  else
    select status, starttime
      into v_oldstatus, v_begindate
      from dc_funcerror
     where checkitemcode = 'PERFSUM';
    v_step := 6;
    if (v_oldstatus = v_status) then
      update dc_funcerror
         set lastchecktime = sysdate,
             checkresult   = v_error,
             duration      = (sysdate - nvl(v_begindate, sysdate)) * 24 * 60
       where checkitemcode = 'PERFSUM';
    else
      v_step := 6.2;
      update dc_funcerror
         set starttime     = sysdate,
             lastchecktime = sysdate,
             status        = v_status,
             checkresult   = v_error,
             duration      = 0
       where checkitemcode = 'PERFSUM';
    end if;

  end if;

  commit;

  rtn_code := 0;
  rtn_info := '?????';

  ---------------------????--------------------------------
exception
  when others then
    rollback;
    rtn_code := -1;
    rtn_info := '????????(??' || to_char(v_step) || ')?' || sqlcode ||
                substr(sqlerrm, 1, 200);

end sp_check_perfsum;
/
