CREATE procedure sp_check_analysis(rtn_code out number,
                                              rtn_info out varchar2)

 is
  /*
  -----------------------????--------------------------------
  ???????????????????????????????????????????????????????
  ?????2012-7-28
  ????: naym
  ???
  */
  v_step   number;
  v_count  number;
  v_status number;
  type emp_array is table of number index by binary_integer;
  v_hosterror emp_array;
  v_date      date;
begin
  ----------------------??????-----------------------------
  v_step := 0;
  ----------????????-------------
  v_date := sysdate;
  --1.?????
  delete from dc_probehosterror where 1 = 1;
  commit;
  for v_probe in (select distinct probeid, probeip
                    from probehost
                   where agentflag is null
                      or agentflag <> 1) loop
    ---1.1??????
    select count(*)
      into v_count
      from ((select resid
               from resgroup
              where coltype = 'FLUX'
                and probeid = v_probe.probeid
             minus
             select circuitid
               from dc_cirerrorcur
              where probeip = v_probe.probeip) union
            (select circuitid
               from dc_cirerrorcur
              where probeip = v_probe.probeip
             minus
             select resid
               from resgroup
              where coltype = 'FLUX'
                and probeid = v_probe.probeid));
    --????
    if (v_count > 0) then
      v_hosterror(1) := 1;
    else
      v_hosterror(1) := 0;
    end if;

    ---1.2??????
    select count(*)
      into v_count
      from ((select resid
               from resgroup
              where coltype = 'PERF'
                and probeid = v_probe.probeid
             minus
             select deviceid
               from dc_deverrorcur
              where probeip = v_probe.probeip
                and checkitemcode = 'DEV_PERF') union
            (select deviceid
               from dc_deverrorcur
              where probeip = v_probe.probeip
                and checkitemcode = 'DEV_PERF'
             minus
             select resid
               from resgroup
              where coltype = 'PERF'
                and probeid = v_probe.probeid));
    --????
    if (v_count > 0) then
      v_hosterror(2) := 1;
    else
      v_hosterror(2) := 0;
    end if;

    ---1.3??????
    select count(*)
      into v_count
      from ((select resid
               from resgroup
              where coltype = 'CFG'
                and probeid = v_probe.probeid
             minus
             select deviceid
               from dc_deverrorcur
              where probeip = v_probe.probeip
                and checkitemcode = 'DEV_CFG') union
            (select deviceid
               from dc_deverrorcur
              where probeip = v_probe.probeip
                and checkitemcode = 'DEV_CFG'
             minus
             select resid
               from resgroup
              where coltype = 'CFG'
                and probeid = v_probe.probeid));
    --????
    if (v_count > 0) then
      v_hosterror(3) := 1;
    else
      v_hosterror(3) := 0;
    end if;

    ---1.4????????
    select count(*)
      into v_count
      from ((select resid
               from resgroup
              where coltype = 'CFGFILE'
                and probeid = v_probe.probeid
             minus
             select deviceid
               from dc_deverrorcur
              where probeip = v_probe.probeip
                and checkitemcode = 'DEV_CFGFILE') union
            (select deviceid
               from dc_deverrorcur
              where probeip = v_probe.probeip
                and checkitemcode = 'DEV_CFGFILE'
             minus
             select resid
               from resgroup
              where coltype = 'CFGFILE'
                and probeid = v_probe.probeid));
    --????
    if (v_count > 0) then
      v_hosterror(4) := 1;
    else
      v_hosterror(4) := 0;
    end if;
    --1.5??????
    select count(*)
      into v_count
      from ((select resid
               from resgroup
              where coltype = 'PERF'
                and probeid = v_probe.probeid
             minus
             select distinct rp.resid
               from rcheckresplan     rn,
                    rcheckresplandef  rf,
                    rcheckresgroup    rg,
                    rcheckresgroupdef rgf,
                    node              n,
                    res               r,
                    tag               t,
                    resgroup          rp
              where rn.planid = rf.planid
                and rf.groupid = rg.groupid
                and rgf.groupid = rf.groupid
                and rg.nodecode = n.nodecode
                and t.tag = rgf.restag
                and r.restypeid = rgf.restypeid
                and r.restypeid like '%DEV%'
                and rp.resid = r.resid
                and rp.coltype = 'PERF'
                and probeid = v_probe.probeid
                and checkstarttime <= sysdate
                and checkendtime >= sysdate) union
            (select distinct rp.resid
               from rcheckresplan     rn,
                    rcheckresplandef  rf,
                    rcheckresgroup    rg,
                    rcheckresgroupdef rgf,
                    node              n,
                    res               r,
                    tag               t,
                    resgroup          rp
              where rn.planid = rf.planid
                and rf.groupid = rg.groupid
                and rgf.groupid = rf.groupid
                and rg.nodecode = n.nodecode
                and t.tag = rgf.restag
                and r.restypeid = rgf.restypeid
                and r.restypeid like '%DEV%'
                and rp.resid = r.resid
                and rp.coltype = 'PERF'
                and probeid = v_probe.probeid
                and checkstarttime <= sysdate
                and checkendtime >= sysdate
             minus
             select resid
               from resgroup
              where coltype = 'PERF'
                and probeid = v_probe.probeid));
    --????
    if (v_count > 0) then
      v_hosterror(5) := 1;
    else
      v_hosterror(5) := 0;
    end if;

    if (v_hosterror(1) = 0 or v_hosterror(2) = 0 or v_hosterror(3) = 0 or
       v_hosterror(4) = 0 or v_hosterror(5) = 0) then

      insert into dc_probehosterror
      values
        (v_probe.probeip,
         sysdate,
         v_hosterror(1),
         v_hosterror(2),
         v_hosterror(3),
         v_hosterror(4),
         v_hosterror(5));
      commit;
    end if;
  end loop;

  ----2.??????
  ---2.1  ??????
  for v_devicetype in (select d.devicemodelcode, count(p.resid) as mount
                         from ((select resid
                                  from resgroup
                                 where coltype = 'PERF'
                                   and resid like 'DEV%'
                                minus
                                select deviceid
                                  from dc_deverrorcur
                                 where checkitemcode = 'DEV_PERF') union
                               (select deviceid
                                  from dc_deverrorcur
                                 where checkitemcode = 'DEV_PERF'
                                minus
                                select resid
                                  from resgroup
                                 where coltype = 'PERF'
                                   and resid like 'DEV%')) p,
                              device d,
                              resgroup rp
                        where rp.resid = p.resid(+)
                          and d.changetype = 0
                          and rp.resid = d.deviceid
                          and rp.coltype = 'PERF'
                        group by d.devicemodelcode) loop

    v_count := v_devicetype.mount;
    --????
    if (v_count = 0) then
      v_status := 0;

      --????????
      select count(*)
        into v_count
        from dc_devmodelerror p
       where p.devicemodelcode = v_devicetype.devicemodelcode
         and p.checkitemcode = 'DEV_PERF';
      if (v_count > 0) then
        update dc_devmodelerror
           set lastchecktime = v_date,
               duration      = (v_date - starttime) * 24 * 60
         where devicemodelcode = v_devicetype.devicemodelcode
           and checkitemcode = 'DEV_PERF';
      else
        insert into dc_devmodelerror
        values
          (v_devicetype.devicemodelcode, 'DEV_PERF', v_date, v_date, 0);
      end if;
      commit;
    end if;
  end loop;

  ---2.2  ??????
  for v_devicetype in (select d.devicemodelcode, count(*) as mount
                         from ((select resid
                                  from resgroup
                                 where coltype = 'CFG'
                                minus
                                select deviceid
                                  from dc_deverrorcur
                                 where checkitemcode = 'DEV_CFG') union
                               (select deviceid
                                  from dc_deverrorcur
                                 where checkitemcode = 'DEV_CFG'
                                minus
                                select resid
                                  from resgroup
                                 where coltype = 'CFG')) p,
                              device d,
                              resgroup rp
                        where p.resid(+) = d.deviceid
                          and d.changetype = 0
                          and rp.resid = d.deviceid
                          and rp.coltype = 'CFG'
                        group by d.devicemodelcode) loop

    v_count := v_devicetype.mount;
    --????
    if (v_count = 0) then
      v_status := 0;

      --????????
      select count(*)
        into v_count
        from dc_devmodelerror p
       where p.devicemodelcode = v_devicetype.devicemodelcode
         and p.checkitemcode = 'DEV_CFG';
      if (v_count > 0) then
        update dc_devmodelerror
           set lastchecktime = v_date,
               duration      = (v_date - starttime) * 24 * 60
         where devicemodelcode = v_devicetype.devicemodelcode
           and checkitemcode = 'DEV_CFG';
      else
        insert into dc_devmodelerror
        values
          (v_devicetype.devicemodelcode, 'DEV_CFG', v_date, v_date, 0);
      end if;
      commit;
    end if;
  end loop;

  ---2.3  ????????
  for v_devicetype in (select d.devicemodelcode, count(*) as mount
                         from ((select resid
                                  from resgroup
                                 where coltype = 'CFGFILE'
                                minus
                                select deviceid
                                  from dc_deverrorcur
                                 where checkitemcode = 'DEV_CFGFILE') union
                               (select deviceid
                                  from dc_deverrorcur
                                 where checkitemcode = 'DEV_CFGFILE'
                                minus
                                select resid
                                  from resgroup
                                 where coltype = 'CFGFILE')) p,
                              device d,
                              resgroup rp
                        where p.resid(+) = d.deviceid
                          and d.changetype = 0
                          and d.deviceid = rp.resid
                          and rp.coltype = 'CFGFILE'
                        group by d.devicemodelcode) loop

    v_count := v_devicetype.mount;
    --????
    if (v_count = 0) then
      v_status := 0;

      --????????
      select count(*)
        into v_count
        from dc_devmodelerror p
       where p.devicemodelcode = v_devicetype.devicemodelcode
         and p.checkitemcode = 'DEV_CFGFILE';
      if (v_count > 0) then
        update dc_devmodelerror
           set lastchecktime = v_date,
               duration      = (v_date - starttime) * 24 * 60
         where devicemodelcode = v_devicetype.devicemodelcode
           and checkitemcode = 'DEV_CFGFILE';
      else
        insert into dc_devmodelerror
        values
          (v_devicetype.devicemodelcode, 'DEV_CFGFILE', v_date, v_date, 0);
      end if;
      commit;
    end if;
  end loop;

  ---2.4  ??????
  for v_devicetype in (select d.devicemodelcode, count(*) as mount
                         from ((select distinct rp.resid
                                  from rcheckresplan     rn,
                                       rcheckresplandef  rf,
                                       rcheckresgroup    rg,
                                       rcheckresgroupdef rgf,
                                       node              n,
                                       res               r,
                                       tag               t,
                                       resgroup          rp
                                 where rn.planid = rf.planid
                                   and rf.groupid = rg.groupid
                                   and rgf.groupid = rf.groupid
                                   and rg.nodecode = n.nodecode
                                   and t.tag = rgf.restag
                                   and r.restypeid = rgf.restypeid
                                   and r.restypeid like '%DEV%'
                                   and rp.resid = r.resid
                                   and rp.coltype = 'PERF'
                                   and checkstarttime <= sysdate
                                   and checkendtime >= sysdate
                                minus
                                select distinct deviceid
                                  from dc_deverrorcur
                                 where checkitemcode = 'DEV_CHECK') union
                               (select distinct deviceid
                                  from dc_deverrorcur
                                 where checkitemcode = 'DEV_CHECK'
                                minus
                                select distinct rp.resid
                                  from rcheckresplan     rn,
                                       rcheckresplandef  rf,
                                       rcheckresgroup    rg,
                                       rcheckresgroupdef rgf,
                                       node              n,
                                       res               r,
                                       tag               t,
                                       resgroup          rp
                                 where rn.planid = rf.planid
                                   and rf.groupid = rg.groupid
                                   and rgf.groupid = rf.groupid
                                   and rg.nodecode = n.nodecode
                                   and t.tag = rgf.restag
                                   and r.restypeid = rgf.restypeid
                                   and r.restypeid like '%DEV%'
                                   and rp.resid = r.resid
                                   and rp.coltype = 'PERF'
                                   and checkstarttime <= sysdate
                                   and checkendtime >= sysdate)) p,
                              device d,
                              (select distinct rp.resid
                                 from rcheckresplan     rn,
                                      rcheckresplandef  rf,
                                      rcheckresgroup    rg,
                                      rcheckresgroupdef rgf,
                                      node              n,
                                      res               r,
                                      tag               t,
                                      resgroup          rp
                                where rn.planid = rf.planid
                                  and rf.groupid = rg.groupid
                                  and rgf.groupid = rf.groupid
                                  and rg.nodecode = n.nodecode
                                  and t.tag = rgf.restag
                                  and r.restypeid = rgf.restypeid
                                  and r.restypeid like '%DEV%'
                                  and rp.resid = r.resid
                                  and rp.coltype = 'PERF'
                                  and checkstarttime <= sysdate
                                  and checkendtime >= sysdate) rp
                        where p.resid(+) = d.deviceid
                          and d.changetype = 0
                          and d.deviceid = rp.resid
                        group by d.devicemodelcode) loop

    v_count := v_devicetype.mount;
    --????
    if (v_count = 0) then
      v_status := 0;

      --????????
      select count(*)
        into v_count
        from dc_devmodelerror p
       where p.devicemodelcode = v_devicetype.devicemodelcode
         and p.checkitemcode = 'DEV_CHECK';
      if (v_count > 0) then
        update dc_devmodelerror
           set lastchecktime = v_date,
               duration      = (v_date - starttime) * 24 * 60
         where devicemodelcode = v_devicetype.devicemodelcode
           and checkitemcode = 'DEV_CHECK';
      else
        insert into dc_devmodelerror
        values
          (v_devicetype.devicemodelcode, 'DEV_CHECK', v_date, v_date, 0);
      end if;
      commit;
    end if;
  end loop;

  ---??DC_DevModelError ???
  delete from dc_devmodelerror where lastchecktime <> v_date;
  commit;

  ---3  ???????
  ---3.1 ????????

  for v_group in (select prt.probeip, rp.groupno, count(*) as mount
                    from resgroup rp,
                         probehost prt,
                         ((select distinct d.deviceid
                             from resgroup p, probehost pt, device d
                            where p.coltype = 'PERF'
                              and pt.probeid = p.probeid
                              and d.deviceid = p.resid
                              and d.changetype = 0
                              and not exists
                            (select 1
                                     from dc_probehosterror ph
                                    where pt.probeip = ph.probeip
                                      and ph.devperfstatus = 0)
                              and not exists
                            (select *
                                     from dc_devmodelerror dd
                                    where dd.devicemodelcode =
                                          d.devicemodelcode)
                           minus
                           select distinct p.deviceid
                             from dc_deverrorcur p
                            where checkitemcode = 'DEV_PERF') union
                          (select distinct p.deviceid
                             from dc_deverrorcur p
                            where checkitemcode = 'DEV_PERF'
                           minus
                           select distinct d.deviceid
                             from resgroup p, probehost pt, device d
                            where p.coltype = 'PERF'
                              and pt.probeid = p.probeid
                              and d.deviceid = p.resid
                              and d.changetype = 0
                              and not exists
                            (select 1
                                     from dc_probehosterror ph
                                    where pt.probeip = ph.probeip
                                      and ph.devperfstatus = 0)
                              and not exists
                            (select *
                                     from dc_devmodelerror dd
                                    where dd.devicemodelcode =
                                          d.devicemodelcode))) b
                   where b.deviceid = rp.resid
                     and rp.groupno is not null
                     and rp.probeid = prt.probeid
                   group by rp.groupno) loop

    v_count := v_group.mount;
    --????
    if (v_count = 0) then
      v_status := 0;

      --????????
      select count(*)
        into v_count
        from dc_grouperror p
       where p.probeno = v_group.groupno
         and p.checkitemcode = 'DEV_PERF'
         and probeip = v_group.probeip;
      if (v_count > 0) then
        update dc_grouperror
           set lastchecktime = v_date,
               duration      = (v_date - starttime) * 24 * 60
         where probeno = v_group.groupno
           and checkitemcode = 'DEV_PERF'
           and probeip = v_group.probeip;
      else
        insert into dc_grouperror
        values
          (v_group.probeip, 'DEV_PERF', v_group.groupno, v_date, v_date, 0);
      end if;
      commit;
    end if;
  end loop;

  ---3.2 ????????
  for v_group in (select prt.probeip, rp.groupno, count(*) as mount
                    from resgroup rp,
                         probehost prt,
                         ((select distinct d.deviceid
                             from resgroup p, probehost pt, device d
                            where p.coltype = 'CFG'
                              and pt.probeid = p.probeid
                              and d.deviceid = p.resid
                              and d.changetype = 0
                              and not exists
                            (select 1
                                     from dc_probehosterror ph
                                    where pt.probeip = ph.probeip
                                      and ph.devcfgstatus = 0)
                              and not exists
                            (select *
                                     from dc_devmodelerror dd
                                    where dd.devicemodelcode =
                                          d.devicemodelcode)
                           minus
                           select distinct p.deviceid
                             from dc_deverrorcur p
                            where checkitemcode = 'DEV_CFG') union
                          (select distinct p.deviceid
                             from dc_deverrorcur p
                            where checkitemcode = 'DEV_CFG'
                           minus
                           select distinct d.deviceid
                             from resgroup p, probehost pt, device d
                            where p.coltype = 'CFG'
                              and pt.probeid = p.probeid
                              and d.deviceid = p.resid
                              and d.changetype = 0
                              and not exists
                            (select 1
                                     from dc_probehosterror ph
                                    where pt.probeip = ph.probeip
                                      and ph.devcfgstatus = 0)
                              and not exists
                            (select *
                                     from dc_devmodelerror dd
                                    where dd.devicemodelcode =
                                          d.devicemodelcode))) b
                   where b.deviceid = rp.resid
                     and rp.groupno is not null
                     and rp.probeid = prt.probeid
                   group by rp.groupno) loop

    v_count := v_group.mount;
    --????
    if (v_count = 0) then
      v_status := 0;

      --????????
      select count(*)
        into v_count
        from dc_grouperror p
       where p.probeno = v_group.groupno
         and p.checkitemcode = 'DEV_CFG'
         and probeip = v_group.probeip;
      if (v_count > 0) then
        update dc_grouperror
           set lastchecktime = v_date,
               duration      = (v_date - starttime) * 24 * 60
         where probeno = v_group.groupno
           and checkitemcode = 'DEV_CFG'
           and probeip = v_group.probeip;
      else
        insert into dc_grouperror
        values
          (v_group.probeip, 'DEV_CFG', v_group.groupno, v_date, v_date, 0);
      end if;
      commit;
    end if;
  end loop;

  ---3.3 ??????????
  for v_group in (select prt.probeip, rp.groupno, count(*) as mount
                    from resgroup rp,
                         probehost prt,
                         ((select distinct d.deviceid
                             from resgroup p, probehost pt, device d
                            where p.coltype = 'CFGFILE'
                              and pt.probeid = p.probeid
                              and d.deviceid = p.resid
                              and d.changetype = 0
                              and not exists
                            (select 1
                                     from dc_probehosterror ph
                                    where pt.probeip = ph.probeip
                                      and ph.configfilestatus = 0)
                              and not exists
                            (select *
                                     from dc_devmodelerror dd
                                    where dd.devicemodelcode =
                                          d.devicemodelcode)
                           minus
                           select distinct p.deviceid
                             from dc_deverrorcur p
                            where checkitemcode = 'DEV_CFGFILE') union
                          (select distinct p.deviceid
                             from dc_deverrorcur p
                            where checkitemcode = 'DEV_CFGFILE'
                           minus
                           select distinct d.deviceid
                             from resgroup p, probehost pt, device d
                            where p.coltype = 'CFGFILE'
                              and pt.probeid = p.probeid
                              and d.deviceid = p.resid
                              and d.changetype = 0
                              and not exists
                            (select 1
                                     from dc_probehosterror ph
                                    where pt.probeip = ph.probeip
                                      and ph.configfilestatus = 0)
                              and not exists
                            (select *
                                     from dc_devmodelerror dd
                                    where dd.devicemodelcode =
                                          d.devicemodelcode))) b
                   where b.deviceid = rp.resid
                     and rp.groupno is not null
                     and rp.probeid = prt.probeid
                   group by prt.probeip, rp.groupno) loop

    v_count := v_group.mount;
    --????
    if (v_count = 0) then
      v_status := 0;

      --????????
      select count(*)
        into v_count
        from dc_grouperror p
       where p.probeno = v_group.groupno
         and p.checkitemcode = 'DEV_CFGFILE'
         and probeip = v_group.probeip;
      if (v_count > 0) then
        update dc_grouperror
           set lastchecktime = v_date,
               duration      = (v_date - starttime) * 24 * 60
         where probeno = v_group.groupno
           and checkitemcode = 'DEV_CFGFILE'
           and probeip = v_group.probeip;
      else
        insert into dc_grouperror
        values
          (v_group.probeip,
           'DEV_CFGFILE',
           v_group.groupno,
           v_date,
           v_date,
           0);
      end if;
      commit;
    end if;
  end loop;

  ---3.4 ????????
  for v_group in (select prt.probeip, rp.groupno, count(*) as mount
                    from resgroup rp,
                         probehost prt,
                         ((select distinct rp.resid
                             from rcheckresplan     rn,
                                  rcheckresplandef  rf,
                                  rcheckresgroup    rg,
                                  rcheckresgroupdef rgf,
                                  node              n,
                                  res               r,
                                  tag               t,
                                  resgroup          rp,
                                  probehost         pt,
                                  device            d
                            where rn.planid = rf.planid
                              and rf.groupid = rg.groupid
                              and rgf.groupid = rf.groupid
                              and rg.nodecode = n.nodecode
                              and t.tag = rgf.restag
                              and r.restypeid = rgf.restypeid
                              and r.restypeid like '%DEV%'
                              and rp.resid = r.resid
                              and rp.coltype = 'PERF'
                              and checkstarttime <= sysdate
                              and checkendtime >= sysdate
                              and pt.probeid = rp.probeid
                              and d.deviceid = rp.resid
                              and d.changetype = 0
                              and not exists
                            (select 1
                                     from dc_probehosterror ph
                                    where pt.probeip = ph.probeip
                                      and ph.devcheckstatus = 0)
                              and not exists
                            (select *
                                     from dc_devmodelerror dd
                                    where dd.devicemodelcode =
                                          d.devicemodelcode)

                           minus
                           select distinct rp.resid
                             from rcheckresplan     rn,
                                  rcheckresplandef  rf,
                                  rcheckresgroup    rg,
                                  rcheckresgroupdef rgf,
                                  node              n,
                                  res               r,
                                  tag               t,
                                  resgroup          rp,
                                  probehost         pt,
                                  device            d
                            where rn.planid = rf.planid
                              and rf.groupid = rg.groupid
                              and rgf.groupid = rf.groupid
                              and rg.nodecode = n.nodecode
                              and t.tag = rgf.restag
                              and r.restypeid = rgf.restypeid
                              and r.restypeid like '%DEV%'
                              and rp.resid = r.resid
                              and rp.coltype = 'PERF'
                              and checkstarttime <= sysdate
                              and checkendtime >= sysdate
                              and pt.probeid = rp.probeid
                              and d.deviceid = rp.resid
                              and d.changetype = 0
                              and not exists
                            (select 1
                                     from dc_probehosterror ph
                                    where pt.probeip = ph.probeip
                                      and ph.devcheckstatus = 0)
                              and not exists
                            (select *
                                     from dc_devmodelerror dd
                                    where dd.devicemodelcode =
                                          d.devicemodelcode))) b
                   where b.resid = rp.resid
                     and rp.groupno is not null
                     and rp.probeid = prt.probeid
                   group by rp.groupno) loop

    v_count := v_group.mount;
    --????
    if (v_count = 0) then
      v_status := 0;

      --????????
      select count(*)
        into v_count
        from dc_grouperror p
       where p.probeno = v_group.groupno
         and p.checkitemcode = 'DEV_CHECK'
         and probeip = v_group.probeip;
      if (v_count > 0) then
        update dc_grouperror
           set lastchecktime = v_date,
               duration      = (v_date - starttime) * 24 * 60
         where probeno = v_group.groupno
           and checkitemcode = 'DEV_CHECK'
           and probeip = v_group.probeip;
      else
        insert into dc_grouperror
        values
          (v_group.probeip,
           'DEV_CHECK',
           v_group.groupno,
           v_date,
           v_date,
           0);
      end if;
      commit;
    end if;
  end loop;

  delete from dc_grouperror p where p.lastchecktime <> v_date;
  commit;

  ---------------------????--------------------------------
exception
  when others then
    rollback;
    rtn_code := -1;
    rtn_info := '????????(??' || to_char(v_step) || ')?' || sqlcode ||
                substr(sqlerrm, 1, 200);

end sp_check_analysis;
/
