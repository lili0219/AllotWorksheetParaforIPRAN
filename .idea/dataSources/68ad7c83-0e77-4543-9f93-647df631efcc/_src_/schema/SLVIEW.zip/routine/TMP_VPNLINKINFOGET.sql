CREATE PROCEDURE TMP_VPNLINKINFOGET

   IS
--
-- To modify this template, edit file PROC.TXT in TEMPLATE
-- directory of SQL Navigator
--
-- Purpose: Briefly explain the functionality of the procedure
--
-- MODIFICATION HISTORY
-- Person      Date    Comments
-- ---------   ------  -------------------------------------------
   l_tmplink            number ;
   l_tmpvalue           varchar2(4000) ;

   -- Declare program variables as shown above
BEGIN
    EXECUTE IMMEDIATE 'TRUNCATE TABLE TMP_VPNLINK' ;

    INSERT INTO TMP_VPNLINK(VPNLINKID) SELECT VpnLinkID FROM MPLSVPNLINK ;

    COMMIT ;

    l_tmplink := -1 ;
    l_tmpvalue := null ;
    for l_rec in (
    select distinct lg.VpnLinkID id,decode(lg.VRFRole,'hub',g.SpokeRT,g.HubRT) rt
    from mplsvpnlink l,vpnlinkrt lg, RTGroup g
    where l.VpnLinkID=lg.VpnLinkID and lg.RTGroupID=g.RTGroupID order by lg.VpnLinkID ) loop
        if (l_tmplink = l_rec.id) then
            l_tmpvalue := l_tmpvalue || ';' || l_rec.rt ;
        else
            update tmp_vpnlink set importrt=l_tmpvalue where vpnlinkid=l_tmplink ;
            l_tmpvalue := l_rec.rt ;
            l_tmplink := l_rec.id ;
        end if ;
    end loop ;
    update tmp_vpnlink set importrt=l_tmpvalue where vpnlinkid=l_tmplink ;
    commit ;

    l_tmplink := -1 ;
    l_tmpvalue := null ;
    for l_rec in (
    select distinct lg.VpnLinkID id,decode(lg.VRFRole,'hub',g.HubRT,g.SpokeRT) rt
    from mplsvpnlink l,vpnlinkrt lg, RTGroup g
    where l.VpnLinkID=lg.VpnLinkID and lg.RTGroupID=g.RTGroupID order by lg.VpnLinkID ) loop
        if (l_tmplink = l_rec.id) then
            l_tmpvalue := l_tmpvalue || ';' || l_rec.rt ;
        else
            update tmp_vpnlink set exportrt=l_tmpvalue where vpnlinkid=l_tmplink ;
            l_tmpvalue := l_rec.rt ;
            l_tmplink := l_rec.id ;
        end if ;
    end loop ;
    update tmp_vpnlink set exportrt=l_tmpvalue where vpnlinkid=l_tmplink ;
    commit ;

    l_tmplink := -1 ;
    l_tmpvalue := null ;
    for l_rec in (
    select distinct l.VpnLinkID id,vs.subnet subnet
    from mplsvpnlink l,vpnlinkstatic vs
    where l.VpnLinkID=vs.VpnLinkID order by l.VpnLinkID ) loop
        if (l_tmplink = l_rec.id) then
            l_tmpvalue := l_tmpvalue || ';' || l_rec.subnet ;
        else
            update tmp_vpnlink set staticroute=l_tmpvalue where vpnlinkid=l_tmplink ;
            l_tmpvalue := l_rec.subnet ;
            l_tmplink := l_rec.id ;
        end if ;
    end loop ;
    update tmp_vpnlink set staticroute=l_tmpvalue where vpnlinkid=l_tmplink ;
    commit ;


END;
/
