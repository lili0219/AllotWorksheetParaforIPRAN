CREATE procedure sp_check_cir_flux(fluxcheckperiod in number,
                                              rtn_code        out number,
                                              rtn_info        out varchar2)

 is
  /*
  -----------------------????--------------------------------
  ?????????????DC_Check_CIR_FLUX
  ?????2012-7-21
  ????: naym
  ???
  */
  v_step number;
begin
  ----------------------??????-----------------------------
  v_step := 0;

  ---??????
  delete from dc_cirerrortmp where checkitemcode = 'CIR_FLUX';
  commit;
  --???????
  ---??????????
  v_step := 1;
  insert into dc_cirerrortmp
    select circuitid,
           'CIR_FLUX',
           sysdate,
           t.probeip,
           groupno,
           '?????',
           ''
      from (select t.circuitid
              from circuit t, flux f
             where t.changetype = '0'
               and t.ismonitor = 1
               and t.circuitid = f.circuitid(+)
               and f.fluxtime(+) >=
                   to_char(sysdate - fluxcheckperiod / (24 * 60),
                           'YYYYMMDDHH24MI')
               and f.fluxtime(+) <= to_char(sysdate, 'YYYYMMDDHH24MI')
             group by t.circuitid
            having(max(f.inavgvec) is null or max(f.outavgvec) is null) --????
            ),
           resgroup rp,probehost t
     where circuitid = rp.resid(+)
       and rp.coltype(+) = 'FLUX'
       and t.probeid(+) = rp.probeid;
  ---???????0
  v_step := 2;
  insert into dc_cirerrortmp
    select circuitid,
           'CIR_FLUX',
           sysdate,
           t.probeip,
           groupno,
           '???????0',
           ''
      from (select t.circuitid
              from circuit t, flux f
             where t.changetype = 0
               and t.ismonitor = 1
               and t.circuitid = f.circuitid(+)
               and f.fluxtime(+) >=
                   to_char(sysdate - fluxcheckperiod / (24 * 60),
                           'YYYYMMDDHH24MI')
               and f.fluxtime(+) <= to_char(sysdate, 'YYYYMMDDHH24MI')
             group by t.circuitid
            having(max(f.inavgvec) = 0 or max(f.outavgvec) = 0) --????
            ),
           resgroup rp,probehost t
     where circuitid = rp.resid(+)
       and rp.coltype(+) = 'FLUX'
       and t.probeid(+) = rp.probeid;

  ---????????
  v_step := 3;
  insert into dc_cirerrortmp
    select circuitid,
           'CIR_FLUX',
           sysdate,
           rp.probeid,
           groupno,
           '????????',
           ''
      from (select t.circuitid
              from circuit t, flux f
             where t.changetype = 0
               and t.ismonitor = 1
               and t.circuitid = f.circuitid(+)
               and f.fluxtime(+) >=
                   to_char(sysdate - fluxcheckperiod / (24 * 60),
                           'YYYYMMDDHH24MI')
               and f.fluxtime(+) <= to_char(sysdate, 'YYYYMMDDHH24MI')
             group by t.circuitid
            having(max(f.inavgvec) = min(f.inavgvec) and max(f.outavgvec) = min(f.outavgvec)) and (max(f.inavgvec) > 0 and max(f.outavgvec) > 0) --????
            ),
           resgroup rp
     where circuitid = rp.resid(+)
       and rp.coltype(+) = 'FLUX';

  commit;

  rtn_code := 0;
  rtn_info := '?????';

  ---------------------????--------------------------------
exception
  when others then
    rollback;
    rtn_code := -1;
    rtn_info := '????????(??' || to_char(v_step) || ')?' || sqlcode ||
                substr(sqlerrm, 1, 200);

end sp_check_cir_flux;
/
