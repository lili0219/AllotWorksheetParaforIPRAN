CREATE PROCEDURE PRU_RMHPerf_ORA
(
   Method char,
   StartTimeStr char,
   EndTimeStr char
)
AS
StartTime date;
EndTime date;
tmpStartTime date;
tmpEndTime date;
gtmpEndTime date;
tmpStartStr varchar2(14);
tmpEndStr varchar2(14);
HourString varchar2(10);

BPTime varchar2(10);
BPCount number(1);
ifBP char(1);--????????

---????
TYPE R_GROUP IS RECORD(value number(10));
TYPE T_GROUP IS TABLE OF R_GROUP INDEX BY BINARY_INTEGER;
resgroup T_GROUP;

num int;
---?????????
StatSpan int;

sql_str varchar2(2000);
type_sql varchar2(500);
type_str varchar2(100);
tmptype varchar2(100);
group_start varchar2(10);
group_end varchar2(10);
group_num number(10);

BEGIN
EndTime := sysdate;
StartTime := to_date(to_char(EndTime-1/24,'yyyymmddhh24')||'0000','yyyymmddhh24miss');

---?????????
select to_number(PARAVALUE) into StatSpan from syspara where PARANAME='PerfCollectHour';
StatSpan := StatSpan - 1;
if StatSpan < 1 then
   StatSpan := 1;
end if;

select count(1) into group_num from ResSumGroup where groupnum<>0;
if group_num=0 then    --???
    resgroup(1).value := 0;
else
    num := 1;
    for g in (select groupnum from ResSumGroup where groupnum<>0) loop
        resgroup(num).value := g.groupnum;
	      num := num+1;
    end loop;
end if;
---???????
num := resgroup.first;
loop
    exit when num is null;
    group_num := resgroup(num).value;

    --????
    select count(*) into BPCount from ressumbp b where b.sumperiodtype='H' and b.groupnum=group_num;
    if BPCount=0 then
        BPTime := null;
	      ifBP := 'I';
    else
        select b.bpdate into BPTime from ressumbp b where b.sumperiodtype='H' and b.groupnum=group_num;
	      ifBP := 'U';
    end if;

    if Method='CRON' then
       if BPTime is null then
          tmpStartTime := StartTime;
          tmpEndTime := EndTime;
       else
           tmpStartTime := to_date(BPTime,'yyyymmddhh24');
           tmpEndTime := to_date(to_char(tmpStartTime+StatSpan/24,'yyyymmddhh24')||'5959','yyyymmddhh24miss');
	         if tmpEndTime>EndTime then
	            tmpEndTime := EndTime;
	         end if;
       end if;
    elsif Method='SUB' then
       tmpStartTime := to_date(StartTimeStr,'yyyymmddhh24');
       tmpEndTime := to_date(EndTimeStr||'5959','yyyymmddhh24miss');
       if tmpEndTime>tmpStartTime+StatSpan/24 then
           tmpEndTime := to_date(to_char(tmpStartTime+StatSpan/24,'yyyymmddhh24')||'5959','yyyymmddhh24miss');
       end if;
       if tmpEndTime>EndTime then
	         tmpEndTime := EndTime;
       end if;
       if to_char(tmpEndTime,'yyyymmddhh24')<BPTime then
           ifBP := 'N';
       end if;
    end if;

     --??????
    if group_num=0 then
        type_sql := '';
    else
        type_sql := ' AND (';
        select ResType,GroupStart,GroupEnd into type_str,group_start,group_end from ResSumGroup where groupnum=group_num;
        while instr(type_str,',',1)>0 loop
           tmptype := substr(type_str,1,instr(type_str,',',1)-1);
	         type_sql := type_sql||'R.ResID between '''||tmptype||group_start||''' and '''||tmptype||group_end||''' or ';

           type_str := substr(type_str,instr(type_str,',',1)+1,length(type_str)-1-length(tmptype));
        end loop;
	      type_sql := type_sql||'R.ResID between '''||type_str||group_start||''' and '''||type_str||group_end||''')';
    end if;

     ---?????
    while tmpStartTime<tmpEndTime loop
        gtmpEndTime := to_date(to_char(tmpStartTime,'yyyymmddhh24')||'5959','yyyymmddhh24miss');
	      if gtmpEndTime>tmpEndTime then
	         gtmpEndTime := tmpEndTime;
	      end if;

        --??????
	      HourString := to_char(tmpStartTime,'yyyymmddhh24');
        sql_str := 'delete from ResMoniHourlyInfo R WHERE R.HourID='''||HourString||''''||type_sql;
	      execute immediate sql_str;

        --??????
	      tmpStartStr := to_char(tmpStartTime,'yyyymmddhh24miss');
	      tmpEndStr := to_char(gtmpEndTime,'yyyymmddhh24miss');
        sql_str := 'INSERT INTO ResMoniHourlyInfo(ResID,DerivedItemCode,ItemPara,HourID,Value)
                      ( SELECT  R.ResID,D.DerivedItemCode,R.ItemPara,'''||HourString||''',
	                              decode(D.DerivedType,''SUM'',ROUND(SUM(R.Value),4),''AVG'',ROUND(AVG(R.Value),4),''MAX'',ROUND(MAX(R.Value),4),ROUND(MIN(R.VALUE),4))
                        FROM ResMoniRawInfo R,ResMoniDerivedItemCfg D
                        WHERE R.MoniItemCode=D.MoniItemCode AND D.MinDerivedUnit=''H''
	                        AND D.DerivedType IN (''SUM'',''AVG'',''MAX'',''MIN'')
	                        AND R.RecordTime>=to_date('''||tmpStartStr||''',''yyyymmddhh24miss'')
			                    and R.RecordTime<=to_date('''||tmpEndStr||''',''yyyymmddhh24miss'')'||type_sql||'
                          GROUP BY D.DerivedItemCode,D.MoniItemCode,D.DerivedType,R.ResID,R.ItemPara,'''||HourString||''')';
          --dbms_output.put_line(sql_str);
	       execute immediate sql_str;

         --????
         dbms_output.put_line(ifBP||','||BPTime||','||to_char(tmpStartTime,'yyyymmddhh24'));
	       if ifBP='I' then
	           insert into ressumbp(SumPeriodType,sumtype,groupnum,BPDate) values('H','--',group_num,to_char(tmpStartTime,'yyyymmddhh24'));
	           ifBP := 'U';
	       elsif ifBP='U' then
             if Method='CRON' or (Method='SUB' and to_char(tmpStartTime,'yyyymmddhh24')>BPTime) then
	               update ressumbp set BPDate=to_char(tmpStartTime,'yyyymmddhh24') where sumperiodtype='H' and groupnum=group_num;
             end if;
	       end if;
         select b.bpdate into BPTime from ressumbp b where b.sumperiodtype='H' and b.groupnum=group_num;

         commit;  --??
	       tmpStartTime := tmpStartTime+1/24;
    end loop; --??????
    num := resgroup.next(num);
end loop;--??????

END;
/
