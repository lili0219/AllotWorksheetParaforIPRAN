CREATE function fun_transipmask
(
    i_ip_mask  varchar2,
    i_ip_type  number   default 1,
    i_para_sep varchar2 default '/'
)
return varchar2 deterministic
is
    v_ipstr    varchar2(64);
    v_masknum  number(5);
    v_tmpnum   number(3);

    v_tmpipnum number(5);

    v_return_ip_start varchar2(64);
    v_return_ip_end   varchar2(64);
    v_tmp_ip_start    varchar2(16);
    v_tmp_ip_end      varchar2(16);
begin
    v_ipstr   := substr(i_ip_mask, 1, instr(i_ip_mask, i_para_sep)-1);
    v_masknum := to_number(substr(i_ip_mask, instr(i_ip_mask, i_para_sep)+1));

    for n in 1..4 loop
        --??????IP???
        if n = 4 then
            v_tmpipnum := to_number(v_ipstr);
        else
            v_tmpipnum := to_number(substr(v_ipstr, 1, instr(v_ipstr, '.')-1));
        end if;
        v_ipstr    := substr(v_ipstr, instr(v_ipstr, '.')+1);

        if v_masknum <= (n-1)*8 then
            v_tmp_ip_start := 0;
            v_tmp_ip_end   := 255;
        elsif v_masknum > n*8 then
            v_tmp_ip_start := v_tmpipnum;
            v_tmp_ip_end   := v_tmpipnum;
        else
            v_tmpnum := n*8 - v_masknum;
            v_tmp_ip_start := bitand(v_tmpipnum, power(2, 8) - power(2, v_tmpnum));
            v_tmp_ip_end   := bitand(v_tmpipnum, power(2, 8) - power(2, v_tmpnum)) + power(2, v_tmpnum)-1;
        end if;

        if i_ip_type = 0 then
            v_tmp_ip_start := substr('00'||v_tmp_ip_start, length(v_tmp_ip_start));
            v_tmp_ip_end   := substr('00'||v_tmp_ip_end,   length(v_tmp_ip_end));
        end if;

        v_return_ip_start := v_return_ip_start||'.'||v_tmp_ip_start;
        v_return_ip_end   := v_return_ip_end  ||'.'||v_tmp_ip_end;

    end loop;

    if i_ip_type = 2 then
        return func_trans_ip_str2int(substr(v_return_ip_start, 2))||'-'||func_trans_ip_str2int(substr(v_return_ip_end, 2));
    else
        return substr(v_return_ip_start, 2)||'-'||substr(v_return_ip_end, 2);
    end if;

exception when others then
    return  'Failed:'||i_ip_mask;
end fun_transipmask;

/
