CREATE PROCEDURE KB_SYNC_INDEX
IS
     l_part_name varchar2(30);
     l_err_string varchar2(200);
     l_index_name varchar2(30);
BEGIN
     for l_rec in (select distinct pnd_index_name,pnd_partition_name from ctx_user_pending) loop
	    begin
	       l_part_name:=l_rec.pnd_partition_name;
	       l_index_name:=l_rec.pnd_index_name;
           ctx_ddl.sync_index(l_index_name,'10M',l_part_name);
        exception
            when others then
                  l_err_string:= '??context????-> ????' ||l_part_name || '->?????' || substrb(sqlerrm,1,100) ;
                  insert into partitionerrorlog(table_name,error_detail,log_time)
                  values(l_index_name,l_err_string,sysdate) ;
                  commit;
          end;
    end loop;
END;
/
