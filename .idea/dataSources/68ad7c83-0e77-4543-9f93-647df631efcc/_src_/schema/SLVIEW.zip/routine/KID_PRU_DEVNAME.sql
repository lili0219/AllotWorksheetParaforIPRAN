CREATE PROCEDURE kid_pru_devname
IS

      v_devid device.deviceid%type;
      v_devip device.loopaddress%type;
      v_no kid_test.data1%type;
      v_num_tmp number;
      v_char_tmp kid_test.data2%type;

      v_row kid_test%rowtype;

      --????
     cursor cursor_row is select * from kid_test k ;
      begin

      open cursor_row;
          loop
           fetch cursor_row into v_row;
               exit when cursor_row%notfound;

               v_no := v_row.data1;
               v_char_tmp := v_row.data2;
               v_devip := v_row.data4;
               --dbms_output.put_line(v_cirid);
               --update kid_test2 k set k.data8 = '??';

               select count(*) into v_num_tmp from device d,node n1
               where d.loopaddress = v_devip and d.changetype=0 and d.nodecode = n1.nodecode and n1.nodefullcode like '%NOD0ca%';
               if (v_num_tmp > 0) THEN

                  select deviceid into v_devid from device d,node n1
               where d.loopaddress = v_devip and d.changetype=0 and d.nodecode = n1.nodecode and n1.nodefullcode like '%NOD0ca%';

                     update device  set devicename = v_char_tmp where deviceid = v_devid;

               end if;

          end loop;
      close cursor_row;
commit;
end kid_pru_devname;
/
