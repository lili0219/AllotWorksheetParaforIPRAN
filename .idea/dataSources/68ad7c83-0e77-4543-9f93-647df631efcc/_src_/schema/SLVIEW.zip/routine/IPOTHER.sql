CREATE FUNCTION ipother
  ( p_ipaddr varchar2)
  RETURN  varchar2 IS
-- ????: ?IP???30???????IP
   l_pos integer;
   l_segint integer;
BEGIN
    l_pos := instr(p_ipaddr,'.',-1) ;
    l_segint := to_number(substr(p_ipaddr,l_pos+1)) ;
    -- ???????? +1 ???? -1
    if mod(l_segint,2) = 1 then
        l_segint := l_segint + 1 ;
    else
        l_segint := l_segint - 1 ;
    end if ;
    return substr(p_ipaddr,1,l_pos) || to_char(l_segint);

EXCEPTION
   WHEN others THEN
       return null ;
END;
/
