CREATE PROCEDURE fluxMetrixCirsCom(g_metrixid IN VARCHAR2)
IS
   --???????FluxMetrixCirGroup????
   TYPE v_cursortype IS REF CURSOR;
   c_fluxmetrixcirinfo v_cursortype;
   --????????????????
   c_circuitinfo v_cursortype;
   --?????FN_SPLIT???????
   c_onegroupdef v_cursortype;--???????????
   c_onedef v_cursortype;--???????????????
   --??????????????sql
   v_querycircuitsql VARCHAR2(1000);
   --?????????????????sql
   v_querycirgroupsql VARCHAR2(1000);

   --???????FluxMetrixCirGroup?????????
   v_metrixid FluxMetrixCirGroup.Metrixid%TYPE;
   v_cirgroupid FluxMetrixCirGroup.Cirgroupid%TYPE;
   v_scolumnid FluxMetrixCirGroup.Scolumnid%TYPE;
   v_dcolumnid FluxMetrixCirGroup.Dcolumnid%TYPE;
   v_deftype FluxMetrixCirGroup.Deftype%TYPE;
   v_fluxdirect FluxMetrixCirGroup.Fluxdirect%TYPE;
   v_defcontext FluxMetrixCirGroup.Defcontext%TYPE;

   --??????????????
   v_semicolonpart VARCHAR2(50);
   --????????????(1,2,3,4)
   v_semicolonpartnum NUMBER;
   --??????????????????
   v_colonpart VARCHAR2(50);
   --????????????(1,2)
   v_colonpartnum NUMBER := 0;
   --?????????
   v_defparaname VARCHAR2(20);
   --????????
   v_defparavalue VARCHAR2(100);
   --???????????sql
   v_querydefparanamesql VARCHAR2(100);

   --??????????
   v_anodecodecon VARCHAR2(100);
   v_bnodecodecon VARCHAR2(100) := ' ';
   v_cirtypecodecon VARCHAR2(100) := ' ';
   v_cirnameregular VARCHAR2(100) := ' ';

   --???????fluxMetrixCirs????
   CURSOR c_fluxMetrixCirsCount(p_snodecode IN VARCHAR2, p_dnodecode IN VARCHAR2, p_circuitid IN VARCHAR2) IS
      SELECT COUNT(fmc.circuitid) AS circount
      FROM FluxMetrixCirs fmc
      WHERE fmc.snodecode = p_snodecode AND fmc.dnodecode = p_dnodecode AND fmc.circuitid = p_circuitid;
   --????fluxMetrixCirs??????
   v_fmcirscount NUMBER;
   --???????????
   v_analysecirid Circuit.Circuitid%TYPE;
BEGIN
   --??FluxMetrixCirs???
   BEGIN
      DELETE FROM FluxMetrixCirs fmc WHERE fmc.metrixid = g_metrixid;
      COMMIT;
   EXCEPTION
      WHEN OTHERS THEN
         DBMS_OUTPUT.PUT_LINE('??FluxMetrixCirs???!');
   END;
   --????????????FluxMetrixCirGroup???
   IF (g_metrixid = 'ALL') THEN
      v_querycirgroupsql :=
         'SELECT fmcg.metrixid, fmcg.cirgroupid, fmcg.scolumnid, fmcg.dcolumnid,
                 fmcg.deftype, fmcg.fluxdirect, fmcg.defcontext
          FROM FluxMetrixCirGroup fmcg';
   ELSE
      v_querycirgroupsql := 'SELECT fmcg.metrixid, fmcg.cirgroupid, fmcg.scolumnid, fmcg.dcolumnid,
                 fmcg.deftype, fmcg.fluxdirect, fmcg.defcontext
          FROM FluxMetrixCirGroup fmcg
          WHERE fmcg.metrixid = ''' || g_metrixid || '''';
   END IF;
   --?????FluxMetrixCirGroup???????
   OPEN c_fluxmetrixcirinfo FOR v_querycirgroupsql;
   LOOP
      FETCH c_fluxmetrixcirinfo INTO v_metrixid, v_cirgroupid, v_scolumnid,
                                     v_dcolumnid, v_deftype, v_fluxdirect,
                                     v_defcontext;
      EXIT WHEN c_fluxmetrixcirinfo%NOTFOUND;
      --??????????????
      v_bnodecodecon := ' ';
      v_cirtypecodecon := ' ';
      v_cirnameregular := ' ';

      v_semicolonpartnum := 0;
      IF (v_deftype = 'C') THEN
         --??????????????????????????FluxMetrixCirs????????
         v_analysecirid := v_defcontext;
         OPEN c_fluxMetrixCirsCount(v_scolumnid, v_dcolumnid, v_analysecirid);
            LOOP
               FETCH c_fluxMetrixCirsCount INTO v_fmcirscount;
               IF (v_fmcirscount = 0) THEN
                  --???????????FluxMetrixCirs???????
                  INSERT INTO FluxMetrixCirs(metrixid, snodecode, dnodecode, circuitid, direct)
                  VALUES(v_metrixid, v_scolumnid, v_dcolumnid, v_defcontext, v_fluxdirect);
                  COMMIT;
               END IF;
               EXIT;--????????FluxMetrixCirs????????????????
            END LOOP;
         CLOSE c_fluxMetrixCirsCount;
      ELSIF (v_deftype = 'R') THEN
         --??????????(??ANodeCode:NOD999;Bnode Code:;cirtypecode:;Regular:/S??/S)
         OPEN c_onegroupdef FOR
            SELECT dg.*
            FROM TABLE(CAST (FN_SPLIT(v_defcontext, ';') AS TY_STR_SPLIT)) dg;
            LOOP
               FETCH c_onegroupdef INTO v_semicolonpart;
               EXIT WHEN c_onegroupdef%NOTFOUND;
               v_semicolonpartnum := v_semicolonpartnum + 1;
               v_colonpartnum := 0;

               v_querydefparanamesql :=
                  'SELECT dg.* FROM TABLE(FN_SPLIT(''' || v_semicolonpart || ''', '':'')) dg';
               OPEN c_onedef FOR v_querydefparanamesql;
                  LOOP
                     FETCH c_onedef INTO v_defparavalue;
                     EXIT WHEN c_onedef%NOTFOUND;
                     v_colonpartnum := v_colonpartnum + 1;
                     IF (v_colonpartnum = 2) THEN
                       IF (v_semicolonpartnum = 1) THEN
                          v_anodecodecon := v_defparavalue;
                       ELSIF (v_semicolonpartnum = 2) THEN
                          v_bnodecodecon := v_defparavalue;
                       ELSIF (v_semicolonpartnum = 3) THEN
                          v_cirtypecodecon := v_defparavalue;
                       ELSIF (v_semicolonpartnum = 4) THEN
                          v_cirnameregular := v_defparavalue;
                       END IF;
                     END IF;
                  END LOOP;
               CLOSE c_onedef;
            END LOOP;
         CLOSE c_onegroupdef;

         --??????????
         v_querycircuitsql := 'SELECT DISTINCT c.circuitid
                               FROM circuit c, cirprop cp, device da, device db, node na, node nb
                               WHERE c.cirpropcode = cp.cirpropcode
                                 AND c.adeviceid = da.deviceid AND da.nodecode = na.nodecode
                                 AND c.bdeviceid = db.deviceid(+) AND db.nodecode = nb.nodecode(+)
                                 AND c.changetype = 0 AND da.changetype = 0 AND db.changetype (+)= 0
                                 AND na.nodefullcode LIKE ''%' || v_anodecodecon || '%''';
         IF ( (v_bnodecodecon <> ' ') ) THEN
            v_querycircuitsql := v_querycircuitsql || ' AND nb.nodefullcode LIKE ''%' || v_bnodecodecon || '%''';
         END IF;
         IF ( (v_cirtypecodecon <> ' ') ) THEN
            v_querycircuitsql := v_querycircuitsql || ' AND cp.cirpropfullcode LIKE ''%' || v_cirtypecodecon || '%''';
         END IF;
         IF ( (v_cirnameregular <> ' ') ) THEN
            v_querycircuitsql := v_querycircuitsql || ' AND REGEXP_LIKE(c.circuitname, ''' || v_cirnameregular || ''')';
         END IF;

         --??????
         OPEN c_circuitinfo FOR v_querycircuitsql;
         LOOP
            FETCH c_circuitinfo INTO v_analysecirid;
            EXIT WHEN c_circuitinfo%NOTFOUND;
            --??????????????????????????FluxMetrixCirs????????
            OPEN c_fluxMetrixCirsCount(v_scolumnid, v_dcolumnid, v_analysecirid);
               LOOP
                  FETCH c_fluxMetrixCirsCount INTO v_fmcirscount;
                  EXIT WHEN c_fluxMetrixCirsCount%NOTFOUND;
                  IF (v_fmcirscount = 0) THEN
                     --???????????FluxMetrixCirs???????
                     INSERT INTO FluxMetrixCirs(metrixid, snodecode, dnodecode, circuitid, direct)
                     VALUES(v_metrixid, v_scolumnid, v_dcolumnid, v_analysecirid, v_fluxdirect);
                     COMMIT;
                  END IF;
               END LOOP;
            CLOSE c_fluxMetrixCirsCount;
         END LOOP;
      END IF;
   END LOOP;
   CLOSE c_fluxmetrixcirinfo;
EXCEPTION
   WHEN OTHERS THEN
      DBMS_OUTPUT.PUT_LINE('??fluxMetrixCirsCom??!');
END fluxMetrixCirsCom;
/
