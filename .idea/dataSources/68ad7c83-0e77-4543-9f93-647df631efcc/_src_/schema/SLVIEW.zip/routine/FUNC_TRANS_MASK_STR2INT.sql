CREATE function func_trans_mask_str2int
(
    i_netmask_str    in varchar2
)
return number deterministic
is
    v_netmask  varchar2(20);
    v_number   number(3);
    v_result   number(3) := 0;
    v_tmp      number(5, 2);
begin
    v_netmask := '.'||i_netmask_str||'.';

    for i in 1..4
    loop
        v_number := substr(v_netmask,instr(v_netmask,'.',1,i)+1,instr(v_netmask,'.',1,i+1) - instr(v_netmask,'.',1,i) - 1);
        if v_number >= 0 and v_number <= 255 then
            v_tmp := log(2, 256 - v_number);
            if mod(v_tmp, 1) = 0 then
                v_result := v_result + v_tmp;
            else
                return -1;
            end if;
         else
             return -1;
         end if;
    end loop;

    return 32 - v_result;

exception when others then
    return -1;
end func_trans_mask_str2int;

/
