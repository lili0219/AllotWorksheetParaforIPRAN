CREATE PROCEDURE GENRESTAG (
i_tag IN VARCHAR2 DEFAULT NULL
)
IS
/*??tagextdef??????restag? */

PRAGMA AUTONOMOUS_TRANSACTION ;
BEGIN

/* ????TAG */
for l_rec in (select distinct tag from tag where tag=i_tag or i_tag is null) loop

	/*?TAG?????????TAG?????*/
	insert into authtemptable (str1)
	select distinct a.resid
	from res a,tagextdef b,node c
	where b.tag=l_rec.tag and b.deftype='DEVPROP' and a.nodecodea=c.nodecode
	and instr(c.nodefullcode,b.nodecode)>0 and a.resid like 'DEV%'
	and a.resprop=b.membercode;

	/*?TAG?????????TAG?????*/
	insert into authtemptable (str1)
	select distinct a.resid
	from res a,tagextdef b,node c,cirprop d
	where b.tag=l_rec.tag and b.deftype='CIRPROP'
	and (a.nodecodea=c.nodecode or a.nodecodeb=c.nodecode)
	and a.resprop=d.cirpropcode
	and a.resid like 'CIR%'
	and instr(c.nodefullcode,b.nodecode)>0
	and instr(d.cirpropfullcode,b.membercode)>0 ;

	/* ?TAG?????????TAG???? */
	insert into authtemptable (str1)
	select membercode
	from tagextdef a,res b
	where a.tag=l_rec.tag and a.deftype='RES' and a.membercode=b.resid ;

	/* ???restag??????????????? */
	delete from restag where tag=l_rec.tag and resid not in (select str1 from authtemptable) ;

	/* ??restag???????? */
	insert into restag (resid,tag,resclassid)
	select str1,l_rec.tag,substr(str1,1,3) from authtemptable
	where str1 not in (select resid from restag where tag=l_rec.tag) ;

	commit ;
end loop ;

END;
/
