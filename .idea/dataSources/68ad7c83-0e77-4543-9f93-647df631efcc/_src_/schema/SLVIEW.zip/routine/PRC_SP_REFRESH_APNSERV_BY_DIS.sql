CREATE procedure prc_sp_refresh_apnserv_by_dis
(
    o_retdesc out varchar2
)
as
begin
    --add by huangkai in task 11650 2018-02-27
    delete
    from   APNTestTaskInfo info
    where  info.taskid in (select deviceid||'_'||tunnelid
                           from   apntunnelinfo
                           where  datasource=1);

    delete
    from   APNTestTaskResult result
    where  result.taskid in (select deviceid||'_'||tunnelid
                             from   apntunnelinfo
                             where  datasource=1);

    delete
    from   APNTestDetail detail
    where  detail.testid in (select deviceid||'_'||tunnelid
                             from   apntunnelinfo
                             where  datasource=1);

    -- ???apntunnelinfo??????????????datasource=1???
    delete from apntunnelinfo a
    where  a.datasource = '1'
    and    not exists (select 1 from disapntunnelinfo d where a.deviceid = d.deviceid and a.tunnelid = d.tunnelid);

    -- ??????????datasource!=1???
    merge  into apntunnelinfo a
    using (with tmptab as
               (select deviceid, tunnelid, vpninstance, vpnrd, apnname, gresource, gredestination, inneripseg, outeripseg,
                       localaddr, remoteaddr, ippoolname, ippooltype, ippoolsection, masterdns, slavedns,
                       l2tpgroup, giif, l2tpremoteaddr, l2tplocaladdr, l2tpremoteflag, l2tplocalflag, passwd, pvlan, cevrrpvrid,
                       ce01,ce02, row_number()over(partition by deviceid, tunnelid order by vpninstance) rn
                from   disapntunnelinfo)
           select deviceid, tunnelid, vpninstance, vpnrd, apnname, gresource, gredestination, inneripseg,outeripseg,
                  localaddr, remoteaddr, ippoolname, ippooltype, ippoolsection, masterdns, slavedns,
                  l2tpgroup,giif,l2tpremoteaddr,l2tplocaladdr,l2tpremoteflag,l2tplocalflag,passwd, pvlan, cevrrpvrid,
                  ce01,ce02
           from   tmptab
           where  rn =1) d
    on    (a.deviceid = d.deviceid and a.tunnelid = d.tunnelid)
    -- ?????????????????apntunnelinfo?????
    when   matched then
    update
    set    a.vpninstance = d.vpninstance,
           a.vpnrd = d.vpnrd,
           a.apnname = d.apnname,
           a.gresource = d.gresource,
           a.gredestination = d.gredestination,
           a.inneripseg = d.inneripseg,
           a.outeripseg = d.outeripseg,
           a.localaddr = d.localaddr,
           a.remoteaddr = d.remoteaddr,
           a.ippoolname = d.ippoolname,
           a.ippooltype = d.ippooltype,
           a.ippoolsection = d.ippoolsection,
           a.masterdns = d.masterdns,
           a.slavedns = d.slavedns,
           a.l2tpgroup = d.l2tpgroup,
           a.giif = d.giif,
           a.l2tpremoteaddr = d.l2tpremoteaddr,
           a.l2tplocaladdr = d.l2tplocaladdr,
           a.l2tpremoteflag = d.l2tpremoteflag,
           a.l2tplocalflag = d.l2tplocalflag,
           a.passwd = d.passwd,
           a.pvlan = d.pvlan,
           a.cevrrpvrid = d.cevrrpvrid,
           a.status = 0,
           a.datasource = decode(a.datasource, '0', '2', a.datasource),
           a.updatetime = sysdate
    when   not matched then -- ????????????????apntunnelinfo???????
    insert
          (a.deviceid, a.tunnelid, a.status, a.vpninstance, a.vpnrd,
           a.apnname, a.gresource, a.gredestination, a.inneripseg, a.outeripseg,
           a.localaddr, a.remoteaddr, a.ippoolname, a.ippooltype, a.ippoolsection,
           a.masterdns, a.slavedns, a.datasource, a.updatetime, a.l2tpgroup,
           a.giif, a.l2tpremoteaddr, a.l2tplocaladdr, a.l2tpremoteflag, a.l2tplocalflag, a.passwd,
           a.pvlan, a.cevrrpvrid,a.ce01,a.ce02)
    values (d.deviceid, d.tunnelid, 0, d.vpninstance, d.vpnrd,
            d.apnname, d.gresource, d.gredestination, d.inneripseg,d.outeripseg,
            d.localaddr, d.remoteaddr, d.ippoolname, d.ippooltype, d.ippoolsection,
            d.masterdns, d.slavedns, '1', sysdate, d.l2tpgroup,
            d.giif, d.l2tpremoteaddr, d.l2tplocaladdr, d.l2tpremoteflag, d.l2tplocalflag, d.passwd,
            d.pvlan, d.cevrrpvrid,d.ce01,d.ce02);

    commit;
    o_retdesc := 'Succeed';

exception when others then
    o_retdesc := 'Failed ORA-'||sqlcode;
    rollback;
end prc_sp_refresh_apnserv_by_dis;
/
