CREATE PROCEDURE bh_destasget
IS
    l_nstartip number ;
    l_nstopip number ;
    l_as number ;
    l_count number ;
begin
	l_count := 0 ;
	for l_rec in (select rowid,iptonumber(ipaddress) nip from devbhroute where sourceas is null order by iptonumber(ipaddress)) loop

	    if (l_rec.nip between l_nstartip and l_nstopip) then
	        update devbhroute set sourceas=l_as where rowid=l_rec.rowid ;
	    else
	        begin
	            select nstartip,nstopip,destas into l_nstartip,l_nstopip,l_as
	            from bgpprefix
	            where nstartip<=l_rec.nip and nstopip>=l_rec.nip and nstartip>0 and destas>0 and ROWNUM=1 ;
	        exception
	            when others then
	                l_nstartip:= 0 ;
	                l_nstopip:=0 ;
	                l_as := 0 ;
	        end ;

            update devbhroute set sourceas=l_as where rowid=l_rec.rowid ;
	    end if ;
        l_count := l_count + 1 ;

	    if (l_count>=100) then
	    	commit ;
	    	l_count := 0 ;
	    end if ;
	end loop ;
	commit ;
end ;
/
