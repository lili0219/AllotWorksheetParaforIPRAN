CREATE FUNCTION iptonumber
  ( p_ipaddr varchar2)
  RETURN  number IS
-- ????: ?ip???????
   l_begin integer;
   l_end integer;
   l_segint integer;
   l_return number ;
BEGIN
    l_begin := 1 ;
    l_return := 0 ;
    for i in 1..3 loop
        l_end := instrb(p_ipaddr,'.',l_begin);
        if l_end = 0 then
            return null;
        end if;
        l_segint:=to_number(substrb(p_ipaddr,l_begin,l_end-l_begin+1),'999');
        if (l_segint<0 or l_segint>255) then
            return null;
        end if;
        l_return := l_return + l_segint * power(256,4-i);
        l_begin := l_end + 1;
    end loop;

    l_return := l_return + to_number(substrb(p_ipaddr,l_begin),'999');
    if l_segint<0 or l_segint>255 then
        return null;
    end if;

    return l_return ;

EXCEPTION
   WHEN others THEN
       return null ;
END;
/
