CREATE procedure sp_check_dev_cfg(rtn_code out number,
                                             rtn_info out varchar2)

 is
  /*
  -----------------------????--------------------------------
  ?????????????DC_Check_DEV_CFG
  ?????2012-7-21
  ????: naym
  ???
  */
  v_step number;
begin
  ----------------------??????-----------------------------
  v_step := 0;

  ---??????
  delete from dc_deverrortmp where checkitemcode = 'DEV_CFG';
  commit;
  v_step := 1;
  ---?????Ip??????????
  insert into dc_deverrortmp
    select dv.deviceid,
           'DEV_CFG',
           sysdate,
           pt.probeip,
           rp.groupno,
           '?????????',
           dv.changetype
      from device dv, resgroup rp, probehost pt
     where substr(dv.moniflag, 1, 1) = 'Y'
       and dv.deviceid = rp.resid(+)
       and rp.probeid = pt.probeid(+)
       and dv.changetype = '0'
       and nvl(rp.coltype(+), 'CFG') = 'CFG'
       and (rp.groupno is null or pt.probeid is null);
  v_step := 2;
  --????????1??????
  insert into dc_deverrortmp
    select distinct deviceid,
                    checkitemcode,
                    tody_date,
                    probeip,
                    groupno,
                    decode(mout, 0, '???????', '?????????') checkresult,
                    diagresult
      from (select d.deviceid,
                   'DEV_CFG' as checkitemcode,
                   sysdate as tody_date,
                   h.probeip,
                   r.groupno,
                   '' as diagresult,
                   d.lastchecktime,
                   d.opendate,
                   count(p.portdescr) as mout
              from device d, resgroup r, probehost h, portinfo p
             where d.changetype = '0'
               and substr(d.moniflag, 1, 1) = 'Y'
               and d.deviceid = r.resid
               and nvl(r.coltype, 'CFG') = 'CFG'
               and r.probeid = h.probeid
               and d.deviceid = p.deviceid(+)
               and r.groupno is not null
               and h.probeid is not null
             group by d.deviceid, d.lastchecktime, r.groupno, h.probeip,d.opendate)
     where decode(lastchecktime, null,opendate, lastchecktime) <
           sysdate - 25 / 24 --??????
        or mout = 0;

  commit;

  rtn_code := 0;
  rtn_info := '?????';

  ---------------------????--------------------------------
exception
  when others then
    rollback;
    rtn_code := -1;
    rtn_info := '????????(??' || to_char(v_step) || ')?' || sqlcode ||
                substr(sqlerrm, 1, 200);

end sp_check_dev_cfg;
/
