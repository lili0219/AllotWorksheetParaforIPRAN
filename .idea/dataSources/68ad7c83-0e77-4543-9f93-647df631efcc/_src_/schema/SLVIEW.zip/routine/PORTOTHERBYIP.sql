CREATE FUNCTION PortOtherByIP
  ( p_ipaddr in varchar2,p_returntype in varchar2 default 'ID')
  RETURN  varchar2 IS
-- ????: ??IP?????
-- ???IP??,????('NAME'-??? 'ID'-??ID)
-- ????252?????IP???????????????????ID/NAME::???;??ID/NAME::??????????????????????????????????
	l_otherip VARCHAR2(50) ;
	l_return VARCHAR2(2000);
BEGIN

	l_otherip := ipother(p_ipaddr) ;
	if (p_returntype='NAME') then
		for l_rec in (select b.devicename,a.intdescr from devaddr a,device b
					  where a.ipaddress=l_otherip and a.changetype=0 and a.deviceid=b.deviceid and a.changetype=b.changetype ) loop
			if (l_return is null) then
				l_return := l_return || l_rec.devicename || '::' || l_rec.intdescr ;
			else
				l_return := l_return || ';' || l_rec.devicename || '::' || l_rec.intdescr ;
			end if ;
		end loop ;
	else
		for l_rec in (select deviceid,intdescr from devaddr where ipaddress=l_otherip and changetype=0) loop
			if (l_return is null) then
				l_return := l_return || l_rec.deviceid || '::' || l_rec.intdescr ;
			else
				l_return := l_return || ';' || l_rec.deviceid || '::' || l_rec.intdescr ;
			end if ;
		end loop ;
	end if ;
	return l_return ;

EXCEPTION
   WHEN others THEN
       return null ;
END;
/
