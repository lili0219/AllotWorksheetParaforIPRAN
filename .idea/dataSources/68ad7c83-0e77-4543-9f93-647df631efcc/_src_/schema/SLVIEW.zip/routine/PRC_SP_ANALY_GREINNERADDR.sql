CREATE procedure prc_sp_analy_greinneraddr
(--  ??apntunnelinfo? greinneraddrdetail?????????????apntunnelinfo.inneripseg?greinneraddrdetail.ipsegment
    o_retdesc out varchar2
)
as
begin
    
    insert into proc_exec_log(procname) values ('prc_sp_analy_greinneraddr');

    update greinneraddrdetail g --  apntunnelinfo???greinneraddrdetail????greinneraddrdetail?????
    set    g.status = 'free', g.deviceid = '', g.custid = '', g.wsnbr = '', g.updatetime = sysdate
    where  g.status = 'used'
    and not exists (select 1 from apntunnelinfo a where a.inneripseg = g.ipsegment);

    merge  into greinneraddrdetail g
    using (with   tmp_ip as(
                            select inneripseg ,count(*) cou 
                            from apntunnelinfo 
                            where inneripseg is not null 
                            group by inneripseg having count(*) > 1
                           ),
    tmp_apntunnelinfo as (select ai.inneripseg, ai.deviceid, ai.custid,
                                               fun_transipmask(ai.inneripseg, 1) str_ip_seg,
                                               fun_transipmask(ai.inneripseg, 2) int_ip_seg
                                        from   apntunnelinfo ai
                                        where  ai.inneripseg is not null
                                        and    not exists(select 1 from tmp_ip where ai.inneripseg = tmp_ip.inneripseg))
           select distinct inneripseg, deviceid, custid,
                  substr(str_ip_seg, 1, instr(str_ip_seg, '-')-1) startip,
                  substr(str_ip_seg, instr(str_ip_seg, '-')+1) endip,
                  substr(int_ip_seg, 1, instr(int_ip_seg, '-')-1) nstartip,
                  substr(int_ip_seg, instr(int_ip_seg, '-')+1)      nendip
           from   tmp_apntunnelinfo) a
    on    (a.inneripseg = g.ipsegment)
    when   matched then--  apntunnelinfo??greinneraddrdetail?????greinneraddrdetail?????
    update set g.status = 'used', g.deviceid = a.deviceid, g.custid = a.custid, g.updatetime = sysdate
    when   not matched then--  apntunnelinfo??greinneraddrdetail????greinneraddrdetail???????
    insert (g.deviceid, g.custid, g.ipsegment, g.ipnum,
            g.startip, g.endip, g.nstartip, g.nendip, g.status, g.updatetime)
    values (a.deviceid, a.custid, a.inneripseg, a.nendip-a.nstartip+1,
            a.startip, a.endip, a.nstartip, a.nendip, 'used', sysdate);

   commit;
   o_retdesc := 'Succeed';

exception when others then
    o_retdesc := 'Failed ORA-'||sqlcode;
    rollback;
end prc_sp_analy_greinneraddr;

/
