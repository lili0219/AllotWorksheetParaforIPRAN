CREATE FUNCTION Radian(d number) RETURN NUMBER
is
PI number :=3.141592625;

begin
return  d* PI/180.0;
end;
/
