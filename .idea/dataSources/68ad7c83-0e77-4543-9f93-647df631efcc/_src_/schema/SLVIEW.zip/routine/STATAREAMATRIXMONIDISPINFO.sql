CREATE PROCEDURE STATAREAMATRIXMONIDISPINFO(RTN_CODE OUT NUMBER,
                                                       RTN_INFO OUT VARCHAR2) AS
  CURSOR c_nodelevel IS
    select distinct arealevel from RCHECKAREA order by arealevel desc;
  --IS

  V_NUM      NUMBER;
  V_RESPROP  VARCHAR2(100);
  V_PLANLIST VARCHAR2(100);
  V_SQLPLAN  VARCHAR2(200);
  V_SQLPROP  VARCHAR2(200);
  V_SQL      VARCHAR2(4000);
  V_DATE     DATE;
  V_STEP     NUMBER;
  V_CNT      NUMBER;

BEGIN
  V_NUM  := 0;
  V_DATE := SYSDATE;

  /*??????????*/
  FOR V_NODELIST IN (SELECT RA.AREACODE,
                            RA.FATHERAREACODE,
                            RA.ISLEAF,
                            '''' || REPLACE(RA.NODECODELIST, ',', ''',''') || '''' AS NODECODELIST,
                            LTRIM(ARP.TEXT, '/') AS TEXT,
                            '''' ||
                            REPLACE(LTRIM(ARP.TEXT, '/'), '/', ''',''') || '''' AS RESPROP
                       FROM RCHECKAREA RA,
                            (SELECT ROW_NUMBER() OVER(PARTITION BY AREACODE ORDER BY AREACODE, LVL DESC) RN,
                                    AREACODE,
                                    TEXT
                               FROM (SELECT AREACODE,
                                            LEVEL LVL,
                                            SYS_CONNECT_BY_PATH(RESPROP, '/') TEXT
                                       FROM (SELECT AREACODE,
                                                    RESPROP,
                                                    ROW_NUMBER() OVER(PARTITION BY AREACODE ORDER BY AREACODE, RESPROP) X
                                               FROM RCHECKAREARELARESPROP
                                              WHERE RESCLASSID = 'DEV'
                                              ORDER BY AREACODE, RESPROP) A
                                     CONNECT BY AREACODE = PRIOR AREACODE
                                            AND X - 1 = PRIOR X)) ARP
                      WHERE RA.ISLEAF = 1
                        AND ARP.AREACODE(+) = RA.AREACODE
                        AND ARP.RN(+) = 1) LOOP

    -------------*****?????????*****--------------
    V_RESPROP := V_NODELIST.RESPROP;
    IF (V_NODELIST.TEXT IS NOT NULL) THEN
      V_SQLPROP := 'and (r.resprop in (' || V_RESPROP || ')
or r.resprop not like ''%PRP%''
or r.resprop is null)';
    ELSE
      V_SQLPROP := '';
    END IF;
    -----------******??????*********------------
    SELECT '''' || REPLACE(SP.PARAVALUE, ';', ''',''') || ''''
      INTO V_PLANLIST
      FROM SYSPARA SP
     WHERE SP.PARANAME = 'RcheckAreaMatrixPlan';

    /******??????????tag??,???sql********/

    IF (V_PLANLIST IS NOT NULL AND V_PLANLIST != '''''') THEN
      V_SQLPLAN := 'and pd.planid in (' || V_PLANLIST || ')';
    ELSE
      V_SQLPLAN := '';
    END IF;


    IF (V_NODELIST.NODECODELIST IS NOT NULL) THEN
      /*******????????********/
      V_SQL := 'insert into temp_areadispinfo
select ''' || V_NODELIST.AREACODE || ''',
nvl(round(avg(nvl(score,0)), 2),100) as avgscore,
nvl(min(nvl(score,0)),100) as maxscore,
nvl(decode(min(checkresult), ''Z'', ''S'', min(checkresult)),''S'') as checkresult,
count(resid)
from (select resid,
case when 100 + sum(nvl(score, 0))<0 then 0
else 100 + sum(nvl(score, 0)) end as score,
min(decode(checkresult, ''S'', ''Z'', checkresult)) as checkresult
FROM (SELECT DISTINCT RT.PLANID,
RT.GROUPID,
RT.RESID,
RT.ITEMCODE,
RT.SCORE,
RT.CHECKRESULT
from rcheckrescheckcurstat rt, res r
where rt.resid = r.resid
 ' || V_SQLPROP || '
and exists
(select 1
from rcheckresplandef pd,
rcheckresgroup rg,
rcheckresgroupdef rg1,node m,node n,node nt,rcheckresplanitem item
where pd.groupid = rg.groupid
AND item.planid = rt.planid
AND item.groupid = rt.groupid
AND item.itemcode = rt.itemcode
and r.nodecodea = nt.nodecode
and nt.nodefullcode like ''%''||n.nodecode||''%''
and n.nodecode in (' || V_NODELIST.NODECODELIST || ')' ||
'and n.nodefullcode like ''%''||m.nodecode||''%''
and rg.nodecode = m.nodecode ' ||
               V_SQLPLAN || ' ' || 'and rg1.groupid = pd.groupid
and decode(rg1.restypeid, null, r.restypeid, rg1.restypeid) =r.restypeid
and decode(rg1.resmodelid,null,r.resmodelid, rg1.resmodelid) = r.resmodelid
and rg1.restag is null
union
select 1
from rcheckresplandef pd,
rcheckresgroup rg,
rcheckresgroupdef rg1,node m,node n,node nt,restag g,rcheckresplanitem item
where pd.groupid = rg.groupid
AND item.planid = rt.planid
AND item.groupid = rt.groupid
AND item.itemcode = rt.itemcode
and r.nodecodea = nt.nodecode
and nt.nodefullcode like ''%''||n.nodecode||''%''
and n.nodecode in (' || V_NODELIST.NODECODELIST || ')' ||
'and n.nodefullcode like ''%''||m.nodecode||''%''
and rg.nodecode = m.nodecode ' ||
               V_SQLPLAN || ' ' || 'and rg1.groupid = pd.groupid
and decode(rg1.restypeid, null, r.restypeid, rg1.restypeid) =r.restypeid
and decode(rg1.resmodelid,null,r.resmodelid, rg1.resmodelid) = r.resmodelid
and decode(rg1.restag, null, g.tag, rg1.restag) like ''%'' ||g.tag|| ''%''
and rg1.restag is not null
and r.resid = g.resid))
group by resid)';

   EXECUTE IMMEDIATE V_SQL;

/*??????*/
  /*******????????********/
  FOR V_DEVTYPELIST IN (SELECT  code,value from codebook  where TABLENAME='RcheckResCheckCurStat'
            and COLUMNNAME='ITEMCODE6296') LOOP

  V_SQL := 'insert into temp_areadispinfo_dev
select ''' || V_NODELIST.AREACODE || ''',''' || V_DEVTYPELIST.CODE || ''',
nvl(round(avg(nvl(score,0)), 2),100) as avgscore,
nvl(min(nvl(score,0)),100) as maxscore,
nvl(decode(min(checkresult), ''Z'', ''S'', min(checkresult)),''S'') as checkresult,
count(resid)
from (select resid,
case when 100 + sum(nvl(score, 0))<0 then 0
else 100 + sum(nvl(score, 0)) end as score,
min(decode(checkresult, ''S'', ''Z'', checkresult)) as checkresult
FROM (SELECT DISTINCT RT.PLANID,
RT.GROUPID,
RT.RESID,
RT.ITEMCODE,
RT.SCORE,
RT.CHECKRESULT
from rcheckrescheckcurstat rt, res r,device d
where rt.resid = r.resid
 ' || V_SQLPROP || '
and r.resid = d.deviceid
and r.restypeid  = d.devicetypecode
and d.changetype = 0
and '|| V_DEVTYPELIST.VALUE ||'
and exists
(select 1
from rcheckresplandef pd,
rcheckresgroup rg,
rcheckresgroupdef rg1,node m,node n,node nt,rcheckresplanitem item
where pd.groupid = rg.groupid
AND item.planid = rt.planid
AND item.groupid = rt.groupid
AND item.itemcode = rt.itemcode
and r.nodecodea = nt.nodecode
and nt.nodefullcode like ''%''||n.nodecode||''%''
and n.nodecode in (' || V_NODELIST.NODECODELIST || ')' ||
'and n.nodefullcode like ''%''||m.nodecode||''%''
and rg.nodecode = m.nodecode ' ||
               V_SQLPLAN || ' ' || 'and rg1.groupid = pd.groupid
and decode(rg1.restypeid, null, r.restypeid, rg1.restypeid) =r.restypeid
and decode(rg1.resmodelid,null,r.resmodelid, rg1.resmodelid) = r.resmodelid
and rg1.restag is null
union
select 1
from rcheckresplandef pd,
rcheckresgroup rg,
rcheckresgroupdef rg1,node m,node n,node nt,restag g,rcheckresplanitem item
where pd.groupid = rg.groupid
AND item.planid = rt.planid
AND item.groupid = rt.groupid
AND item.itemcode = rt.itemcode
and r.nodecodea = nt.nodecode
and nt.nodefullcode like ''%''||n.nodecode||''%''
and n.nodecode in (' || V_NODELIST.NODECODELIST || ')' ||
'and n.nodefullcode like ''%''||m.nodecode||''%''
and rg.nodecode = m.nodecode ' ||
               V_SQLPLAN || ' ' || 'and rg1.groupid = pd.groupid
and decode(rg1.restypeid, null, r.restypeid, rg1.restypeid) =r.restypeid
and decode(rg1.resmodelid,null,r.resmodelid, rg1.resmodelid) = r.resmodelid
and decode(rg1.restag, null, g.tag, rg1.restag) like ''%'' ||g.tag|| ''%''
and rg1.restag is not null
and g.resid = r.resid))
group by resid)';

      EXECUTE IMMEDIATE V_SQL;

    END LOOP;

    ELSE
      INSERT INTO TEMP_AREADISPINFO
        SELECT V_NODELIST.AREACODE,
               '100' AS AVGSCORE,
               '100' AS MAXSCORE,
               'S' AS CHECKRESULT,
               0
          FROM DUAL;

    FOR V_DEVTYPELIST IN (SELECT  code,value from codebook  where TABLENAME='RcheckResCheckCurStat'
            and COLUMNNAME='ITEMCODE6296') LOOP

      INSERT INTO TEMP_AREADISPINFO_DEV
        SELECT V_NODELIST.AREACODE,
           V_DEVTYPELIST.code,
               '100' AS AVGSCORE,
               '100' AS MAXSCORE,
               'S' AS CHECKRESULT,
               0
          FROM DUAL;

     END LOOP;

    END IF;
    /*?????v_num*/
    V_NUM  := V_NUM + 1;
    V_STEP := V_NUM;


  END LOOP;
  /*???????????*/
  FOR r_nodelevel IN c_nodelevel LOOP
    INSERT INTO TEMP_AREADISPINFO
      SELECT FATHERAREACODE,
             CASE
               WHEN RCHECKNUM > 0 THEN
                ROUND(ALLSCORE / RCHECKNUM, 2)
               ELSE
                100
             END AS AVGSCORE,
             MINSCORE,
             DECODE(CHECKRESULT, 'Z', 'S', CHECKRESULT) AS CHECKRESULT,
             RCHECKNUM
        FROM (SELECT RA.FATHERAREACODE,
                     SUM(TA.AVGSCORE * RCHECKNUM) AS ALLSCORE,
                     MIN(to_number(TA.MINSCORE)) AS MINSCORE,
                     MIN(DECODE(CHECKRESULT, 'S', 'Z', CHECKRESULT)) AS CHECKRESULT,
                     SUM(TA.RCHECKNUM) AS RCHECKNUM
                FROM RCHECKAREA RA, TEMP_AREADISPINFO TA
               WHERE RA.AREALEVEL = r_nodelevel.arealevel
                 AND TA.AREACODE = RA.AREACODE
                 AND RA.FATHERAREACODE IS NOT NULL
               GROUP BY RA.FATHERAREACODE);
  END LOOP;

  /*????????*/
  DELETE FROM AREAMATRIXMONICURDISPINFO WHERE 1 = 1;

  ---????---
  --????  ???????*0.4+???*0.6   ??????*0.5+???*0.5
  INSERT INTO AREAMATRIXMONICURDISPINFO
    (AREACODE, SCORE, SCORERGBCOLOR, SCORECHECKRESULT, STATTIME)
    SELECT P.AREACODE,
           CASE when A.isleaf = '1' then ROUND(P.AVGSCORE * 0.5 + P.MINSCORE * 0.5, 2) else ROUND(P.AVGSCORE * 0.4 + P.MINSCORE * 0.6, 2) end,
           '#',
           P.CHECKRESULT,
           V_DATE
      FROM TEMP_AREADISPINFO P, RCHECKAREA A
	  WHERE p.areacode = a.areacode;
--  COMMIT;
  /*??color??*/
  UPDATE AREAMATRIXMONICURDISPINFO T
     SET T.SCORERGBCOLOR = (SELECT '#' || SCOLOR
                              FROM RCHECKAREATROUBLEGRADE
                             WHERE GRADE IN
                                   (SELECT MAX(TG.GRADE)
                                      FROM RCHECKAREATROUBLEGRADE TG
                                     WHERE TG.GRADE < T.SCORE))
   WHERE EXISTS (SELECT 1
            FROM RCHECKAREATROUBLEGRADE
           WHERE GRADE IN (SELECT MAX(TG.GRADE)
                             FROM RCHECKAREATROUBLEGRADE TG
                            WHERE TG.GRADE < T.SCORE));
--  COMMIT;

  /*????????*/
  /*???????????*/
  V_CNT := 100;

  FOR r_nodelevel IN c_nodelevel LOOP
    INSERT INTO TEMP_AREADISPINFO_DEV
      SELECT FATHERAREACODE,DEVTYPE,
             CASE
               WHEN RCHECKNUM > 0 THEN
                ROUND(ALLSCORE / RCHECKNUM, 2)
               ELSE
                100
             END AS AVGSCORE,
             MINSCORE,
             DECODE(CHECKRESULT, 'Z', 'S', CHECKRESULT) AS CHECKRESULT,
             RCHECKNUM
        FROM (SELECT RA.FATHERAREACODE,DEVTYPE,
                     SUM(TA.AVGSCORE * RCHECKNUM) AS ALLSCORE,
                     MIN(to_number(TA.MINSCORE)) AS MINSCORE,
                     MIN(DECODE(CHECKRESULT, 'S', 'Z', CHECKRESULT)) AS CHECKRESULT,
                     SUM(TA.RCHECKNUM) AS RCHECKNUM
                FROM RCHECKAREA RA, TEMP_AREADISPINFO_DEV TA
               WHERE RA.AREALEVEL = r_nodelevel.arealevel
                 AND TA.AREACODE = RA.AREACODE
                 AND RA.FATHERAREACODE IS NOT NULL
               GROUP BY RA.FATHERAREACODE,DEVTYPE);
  END LOOP;

  /*????????*/
  DELETE FROM AreaMatrixMoniCurDispInfoDev WHERE 1 = 1;

  ---????---
  INSERT INTO AreaMatrixMoniCurDispInfoDev
    (AREACODE, devTypeName,SCORE, SCORERGBCOLOR, SCORECHECKRESULT, STATTIME)
    SELECT P.AREACODE,devtype,
           CASE when A.isleaf = '1' then ROUND(P.AVGSCORE * 0.5 + P.MINSCORE * 0.5, 2) else ROUND(P.AVGSCORE * 0.4 + P.MINSCORE * 0.6, 2) end,
           '#',
           P.CHECKRESULT,
           V_DATE
      FROM TEMP_AREADISPINFO_DEV P, RCHECKAREA A
	  WHERE p.areacode = a.areacode;
  COMMIT;
  /*??color??*/
  UPDATE AreaMatrixMoniCurDispInfoDev T
     SET T.SCORERGBCOLOR = (SELECT '#' || SCOLOR
                              FROM RCHECKAREATROUBLEGRADE
                             WHERE GRADE IN
                                   (SELECT MAX(TG.GRADE)
                                      FROM RCHECKAREATROUBLEGRADE TG
                                     WHERE TG.GRADE < T.SCORE))
   WHERE EXISTS (SELECT 1
            FROM RCHECKAREATROUBLEGRADE
           WHERE GRADE IN (SELECT MAX(TG.GRADE)
                             FROM RCHECKAREATROUBLEGRADE TG
                            WHERE TG.GRADE < T.SCORE));
  COMMIT;

  RTN_CODE := 0;
  RTN_INFO := '????';
EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    RTN_CODE := V_STEP;
    RTN_INFO := '?????' || SQLCODE || SUBSTR(SQLERRM, 1, 200);

END STATAREAMATRIXMONIDISPINFO;
/
