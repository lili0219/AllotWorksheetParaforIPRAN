CREATE PROCEDURE refreshuserauth
   ( i_netuserid   IN   VARCHAR)
IS
    l_nodeflag integer ;
    l_resflag  integer ;
    l_newtime   date ;
    l_userauthchange     integer ;
    l_reschange      integer ;
    l_nodechange     integer ;
    l_errstr        varchar2(500);
    l_userupdatetime date ;
    l_starttime     date ;
    l_restyperefresh integer ;
    l_resauth       varchar2(20) ;
    l_count     number(10) ;
    l_count1    number(10) ;

    PRAGMA AUTONOMOUS_TRANSACTION ;
BEGIN

    l_userauthchange:=0;
    l_reschange:=0;
    l_nodechange:=0 ;

    /* ????????*/
    BEGIN
        select AuthUpdateTime
        into l_userupdatetime
        from userinfo a
        where a.netuserid=i_netuserid;
    END ;


    /* ???????????*/
    BEGIN
        select 0
        into l_userauthchange
        from userauthupdate a
        where a.UpdateTime=l_userupdatetime and a.netuserid=i_netuserid;
    EXCEPTION
        WHEN others THEN
            l_userauthchange := 1 ;
    END ;

    /* ????????????????????*/
    if (l_userauthchange=0) then
        /* ???????? */
        BEGIN
            select 0
            into l_nodechange
            from usernodeupdate
            where netuserid=i_netuserid and updatetime=nodeupdatetime;
        EXCEPTION
            WHEN others THEN
                l_nodechange := 1 ;
        END ;

        /* ???????? */
        BEGIN
            select 1
            into l_reschange
            from resupdate a,userresupdate b
            where a.resclassid=b.resclassid(+) and b.netuserid(+)=i_netuserid
              and nvl(a.changeversion,0) > nvl(b.changeversion,0)
              and rownum=1;
        EXCEPTION
            WHEN others THEN
                l_reschange := 0 ;
        END ;

    end if ;



    /* ?????? */
    if (l_userauthchange=1 or l_nodechange=1) then

        l_starttime := sysdate ;

        /* ?????? */
        begin
            select nodeupdatetime
            into l_newtime
            from usernodeupdate
            where netuserid=i_netuserid
            for update nowait ;
        exception
            when no_data_found then
                l_newtime := null ;
        end ;

        /* ??????????*/
        delete from singleusernodeauth where netuserid=i_netuserid ;

        /* ??CFG??????*/
        insert into  singleusernodeauth a (a.authtype, a.netuserid, a.nodecode, a.nodefullcode)
        select distinct 'CFG',i_netuserid,bb.nodecode,bb.nodefullcode
        from userresauth aa,node bb
        where aa.netuserid=i_netuserid and aa.authtype='CFG' and aa.restypeid='ALL' and instrb(bb.nodefullcode,aa.nodecode)>0 ;

        /* ??VIEW??????*/
        insert into  singleusernodeauth a (a.authtype, a.netuserid, a.nodecode, a.nodefullcode)
        select distinct 'VIEW',i_netuserid,bb.nodecode,bb.nodefullcode
        from userresauth aa,node bb
        where aa.netuserid=i_netuserid and aa.restypeid='ALL' and instrb(bb.nodefullcode,aa.nodecode)>0 ;

        /* ?????????? */
        if  (l_newtime is  null) then
            insert into usernodeupdate (netuserid,updatetime,nodeupdatetime) values (i_netuserid,sysdate,sysdate) ;
        else
            update usernodeupdate set updatetime=nodeupdatetime where netuserid=i_netuserid ;
        end if ;

        /* ?? */
        commit ;

        /* ??? */
        begin
            insert into errloginfo(LogTime,ErrorCode,ErrorProgram,ErrorDesc,ErrorDetail)
            values (sysdate,'AUT0002','REFRESHUSERAUTH',i_netuserid,'NODE REFRESH Elaps(s):'||to_char(round((sysdate-l_starttime)*86400,2))) ;
            commit ;
        exception
            when others then
                null ;
        end ;
    end if ;


    /* ????????????????????? */
    IF (l_reschange=1 or l_userauthchange=1) THEN
      l_starttime := sysdate ;

      for l_rec in (select resclassid from userresupdate where netuserid=i_netuserid for update nowait) loop
        null ;
      end loop ;
    END IF ;

    --dbms_output.put_line(substr('getlock duration:'||to_char(round((sysdate-l_starttime)*86400)),1,255));

    l_errstr := '' ;
    l_restyperefresh := 0 ;

    /* ?????????????????? */
    if (l_reschange=1 and l_userauthchange=0) then

        for l_rec in (
            select a.resclassid,nvl(a.changeversion,0) changeversion,a.updatetime,nvl(b.changeversion,0) userchangeversion,b.updatetime userupdatetime
            from resupdate a,(select resclassid,changeversion,updatetime from userresupdate where netuserid=i_netuserid) b
            where a.resclassid=b.resclassid(+) and nvl(a.changeversion,0)>nvl(b.changeversion,0)) LOOP

            /* ???????????????????180??? changeversion????500???????????????????????????? */
            IF (l_rec.changeversion-l_rec.userchangeversion>500 or l_rec.updatetime-l_rec.userupdatetime>180) THEN
                l_restyperefresh := 1 ;
            /* ??????????????,?????????? */
            ELSE
                l_count := 0 ;
                l_count1 := 0 ;
                for l_reslog in (select resid,changetype from resupdatelog
                        where resclassid=l_rec.resclassid and changeversion>l_rec.userchangeversion and changeversion<=l_rec.changeversion
                        order by changeversion asc) loop
                    l_count := l_count + 1 ;
                    /* ???????????????????????????*/
                    IF (l_reslog.changetype=-1) THEN
                        delete from singleuserresauth where netuserid=i_netuserid and resid=l_reslog.resid ;
                        IF (SQL%ROWCOUNT > 0) THEN
                            l_count1 := l_count1 + 1 ;
                        END IF ;
                    /* ??????????????????????????????????*/
                    ELSIF  (l_reslog.changetype=1) THEN
                        BEGIN
                            l_resauth := getuserresauth(i_netuserid,l_reslog.resid) ;
                            IF (l_resauth = 'CFG') THEN
                                insert into singleuserresauth a (a.netuserid, a.resid, a.authtype, a.resclassid)
                                values (i_netuserid,l_reslog.resid,'CFG',l_rec.resclassid) ;
                                insert into singleuserresauth a (a.netuserid, a.resid, a.authtype, a.resclassid)
                                values (i_netuserid,l_reslog.resid,'VIEW',l_rec.resclassid) ;
                                l_count1 := l_count1 + 1 ;
                            ELSIF (l_resauth = 'VIEW') THEN
                                insert into singleuserresauth a (a.netuserid, a.resid, a.authtype, a.resclassid)
                                values (i_netuserid,l_reslog.resid,'VIEW',l_rec.resclassid) ;
                                l_count1 := l_count1 + 1 ;
                            END IF ;
                        EXCEPTION
                            WHEN OTHERS THEN
                                NULL ;
                        END ;
                    /* ????????????????????????????????????????????*/
                    ELSIF  (l_reslog.changetype=2) THEN
                        BEGIN
                            l_resauth := getuserresauth(i_netuserid,l_reslog.resid) ;
                            IF (l_resauth = 'CFG') THEN

                                merge into singleuserresauth a
                                using (select i_netuserid netuserid,l_reslog.resid resid,'CFG' authtype,l_rec.resclassid resclassid from dual) b
                                on (a.netuserid=b.netuserid and a.resid=b.resid and a.authtype=b.authtype)
                                when not matched then insert (a.netuserid, a.resid, a.authtype, a.resclassid) values (b.netuserid, b.resid, b.authtype, b.resclassid) ;

                                merge into singleuserresauth a
                                using (select i_netuserid netuserid,l_reslog.resid resid,'VIEW' authtype,l_rec.resclassid resclassid from dual) b
                                on (a.netuserid=b.netuserid and a.resid=b.resid and a.authtype=b.authtype)
                                when not matched then insert (a.netuserid, a.resid, a.authtype, a.resclassid) values (b.netuserid, b.resid, b.authtype, b.resclassid) ;

                                l_count1 := l_count1 + 1 ;
                            ELSIF (l_resauth = 'VIEW') THEN
                                delete from singleuserresauth
                                where netuserid=i_netuserid and resid=l_reslog.resid and authtype='CFG' ;

                                merge into singleuserresauth a
                                using (select i_netuserid netuserid,l_reslog.resid resid,'VIEW' authtype,l_rec.resclassid resclassid from dual) b
                                on (a.netuserid=b.netuserid and a.resid=b.resid and a.authtype=b.authtype)
                                when not matched then insert (a.netuserid, a.resid, a.authtype, a.resclassid) values (b.netuserid, b.resid, b.authtype, b.resclassid) ;

                                l_count1 := l_count1 + 1 ;

                            ELSE
                                delete from singleuserresauth
                                where netuserid=i_netuserid and resid=l_reslog.resid  ;
                                IF (SQL%ROWCOUNT > 0) THEN
                                    l_count1 := l_count1 + 1 ;
                                END IF ;
                            END IF ;

                        EXCEPTION
                            WHEN OTHERS THEN
                                NULL ;
                        END ;
                    END IF ;
                END LOOP ;

                l_errstr := l_errstr||' '|| l_rec.resclassid || '(' || to_char(l_rec.userchangeversion) || ' ' || to_char(l_rec.changeversion) || ' ' || to_char(l_count) || ' ' || to_char(l_count1) || ')'  ;


                /* ???????????changeversion */
                update  userresupdate
                set updatetime=l_rec.updatetime,changeversion=l_rec.changeversion
                where netuserid=i_netuserid and resclassid=l_rec.resclassid ;

                if (SQL%ROWCOUNT=0) then
                   insert into userresupdate (netuserid,resclassid,updatetime,changeversion)
                   values (i_netuserid,l_rec.resclassid,l_rec.updatetime,l_rec.changeversion) ;
                end if ;

            END IF ;

        END LOOP ;

    END IF ;


    /* ????????????????????????????????????????? */
    IF (l_userauthchange=1 or l_restyperefresh=1) THEN

        /* ????????????????????????????????? */
        IF (l_userauthchange = 1 ) THEN
            delete from   userresupdate where netuserid=i_netuserid ;

            insert into userresupdate (netuserid,resclassid,updatetime,changeversion)
            select i_netuserid,resclassid,updatetime,changeversion
            from resupdate ;
        END IF ;

        /* ??????????*/
        /*???????????*/
        insert into authtemptable(str1,str2,str3)
        SELECT DISTINCT a.authtype,b.resid,c.resclassid
        FROM singleusernodeauth a,res b,restype c
        WHERE a.netuserid=i_netuserid
            and (a.nodecode = b.nodecodea OR a.nodecode = b.nodecodeb ) and b.restypeid=c.restypeid and a.authtype='CFG' ;

        insert into authtemptable(str1,str2,str3)
        SELECT DISTINCT a.authtype,b.resid,c.resclassid
        FROM singleusernodeauth a,res b,restype c
        WHERE a.netuserid=i_netuserid
            and (a.nodecode = b.nodecodea OR a.nodecode = b.nodecodeb ) and b.restypeid=c.restypeid and a.authtype='VIEW'
            and a.nodecode not in (select nodecode from singleusernodeauth where netuserid=i_netuserid and authtype='CFG') ;

        /*?????????????*/
        insert into authtemptable(str1,str2,str3)
        SELECT DISTINCT a.authtype,b.resid,d.resclassid
        FROM userresauth a,res b,node c,restype d
        WHERE a.netuserid=i_netuserid and instr(c.nodefullcode,a.nodecode)>0
            and (c.nodecode = b.nodecodea OR c.nodecode = b.nodecodeb )
            and b.restypeid=a.restypeid and a.restypeid =d.restypeid and a.resid='ALL';

        /*??????*/
        insert into authtemptable(str1,str2,str3)
        SELECT DISTINCT a.authtype,b.resid,c.resclassid
        FROM userresauth a,res b,restype c
        WHERE a.netuserid=i_netuserid and a.restypeid=b.restypeid
            and a.resid=b.resid and b.restypeid=c.restypeid;

        /*?TAG????????*/
        insert into authtemptable(str1,str2,str3)
        SELECT DISTINCT a.authtype,b.resid,d.resclassid
        FROM userresauth a,res b,node c,restag d,restype e
        WHERE a.netuserid=i_netuserid and instr(c.nodefullcode,a.nodecode)>0
            and (c.nodecode = b.nodecodea OR c.nodecode = b.nodecodeb )
            and  a.resid=d.tag and d.resid=b.resid and a.restypeid='TAG'
            and b.restypeid=e.restypeid;

        /*?????????????*/
        insert into authtemptable(str1,str2,str3)
        SELECT DISTINCT a.authtype,b.resid,d.resclassid
        FROM userresauth a,res b,node c,restype d
        WHERE a.netuserid=i_netuserid and instr(c.nodefullcode,a.nodecode)>0
            and (c.nodecode = b.nodecodea OR c.nodecode = b.nodecodeb ) and a.restypeid in ('DEVPROP','CIRPROP','HOSTPROP')
            and a.resid=b.resprop and b.restypeid=d.restypeid and a.restypeid like d.resclassid||'%';

          /*???????????*/
        insert into authtemptable(str1,str2,str3)
        SELECT DISTINCT a.authtype,b.resid,d.resclassid
        FROM userresauth a,res b,node c,restype d
        WHERE a.netuserid=i_netuserid and instr(c.nodefullcode,a.nodecode)>0
            and (c.nodecode = b.nodecodea OR c.nodecode = b.nodecodeb ) and a.restypeid = 'VENDOR'
            and a.resid=b.VENDOR and b.restypeid=d.restypeid ;


        --dbms_output.put_line(substr('????????:'||to_char(round((sysdate-l_starttime)*86400)),1,255));


        /* ??????????????????? */
        IF (l_userauthchange = 1 ) THEN

            /*???????????*/
            delete from singleuserresauth where netuserid=i_netuserid ;

            --dbms_output.put_line(substr('?????ALL:'||to_char(round((sysdate-l_starttime)*86400)),1,255));

            /*???????????*/
            insert into  singleuserresauth a (a.netuserid, a.resid, a.authtype, a.resclassid)
            select distinct i_netuserid,str2,'CFG',str3
            from authtemptable
            where str1='CFG' ;

            insert into  singleuserresauth a (a.netuserid, a.resid, a.authtype, a.resclassid)
            select distinct i_netuserid,str2,'VIEW',str3
            from authtemptable ;

            --dbms_output.put_line(substr('?????ALL:'||to_char(round((sysdate-l_starttime)*86400)),1,255));

            /* ??????????*/
            update  userauthupdate a
            set a.updatetime=l_userupdatetime
            where  a.netuserid=i_netuserid;

            if (SQL%ROWCOUNT=0) then
                insert into userauthupdate (netuserid,updatetime)
                values (i_netuserid,l_userupdatetime) ;
            end if ;

            l_errstr := 'ALL' ;

        /* ???????????????? */
        ELSE
            for l_rec in (
                select a.resclassid,a.updatetime,a.changeversion from resupdate a,(select resclassid,updatetime,changeversion from userresupdate where netuserid=i_netuserid) b
                where a.resclassid=b.resclassid(+) and nvl(a.changeversion,0)!=nvl(b.changeversion,0)) loop
                /*???????????*/
               delete from singleuserresauth where netuserid=i_netuserid and resclassid=l_rec.resclassid ;

                --dbms_output.put_line(substr('?????'||l_rec.resclassid ||':'||to_char(round((sysdate-l_starttime)*86400)),1,255));
               /*???????????*/
               insert into  singleuserresauth a (a.netuserid, a.resid, a.authtype, a.resclassid)
               select distinct i_netuserid,str2,'CFG',str3
               from authtemptable
               where str1='CFG' and str3=l_rec.resclassid;

               insert into  singleuserresauth a (a.netuserid, a.resid, a.authtype, a.resclassid)
               select distinct i_netuserid,str2,'VIEW',str3
               from authtemptable
               where str3=l_rec.resclassid;

                --dbms_output.put_line(substr('?????'||l_rec.resclassid ||':'||to_char(round((sysdate-l_starttime)*86400)),1,255));

                /* ???????????changeversion */
                update  userresupdate
                set updatetime=l_rec.updatetime,changeversion=l_rec.changeversion
                where netuserid=i_netuserid and resclassid=l_rec.resclassid ;

                if (SQL%ROWCOUNT=0) then
                   insert into userresupdate (netuserid,resclassid,updatetime,changeversion)
                   values (i_netuserid,l_rec.resclassid,l_rec.updatetime,l_rec.changeversion) ;
                end if ;
                l_errstr := l_errstr||' '|| l_rec.resclassid || '(ALL)';

            end loop ;

        END IF ;

    END IF ;

    /* ??????????????? */
    IF (l_reschange=1 or l_userauthchange=1) THEN
        /* ?? */
        commit ;

        --dbms_output.put_line(substr('commit:'||to_char(round((sysdate-l_starttime)*86400)),1,255));

        /* ??? */
        begin
            insert into errloginfo(LogTime,ErrorCode,ErrorProgram,ErrorDesc,ErrorDetail)
            values (sysdate,'AUT0003','REFRESHUSERAUTH',i_netuserid,'RES REFRESH:'||l_errstr||' Elaps(s):'||to_char(round((sysdate-l_starttime)*86400,2))) ;
            commit ;
        exception
            when others then
                null ;
        end ;

        commit ;

    end if ;

EXCEPTION
    WHEN others THEN
        l_errstr := SUBSTRB(SQLERRM,1,400) ;
        rollback ;
        insert into errloginfo(LogTime,ErrorCode,ErrorProgram,ErrorDesc,ErrorDetail)
        values (sysdate,'AUT0001','REFRESHUSERAUTH',i_netuserid,l_errstr) ;
        commit ;
END;
/
