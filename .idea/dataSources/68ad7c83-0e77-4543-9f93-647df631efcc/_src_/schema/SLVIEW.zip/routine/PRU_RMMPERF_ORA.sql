CREATE PROCEDURE PRU_RMMPerf_ORA
(
   Method char,
   StartTimeStr char,
   EndTimeStr char
)
AS
StartTime date;
EndTime date;
tmpStartTime date;
tmpEndTime date;
gtmpEndTime date;
tmpStartStr varchar2(14);
tmpEndStr varchar2(14);
MonthStr varchar2(10);

BPTime varchar2(10);
BPCount number(1);
ifBP char(1);--????????

ItemResType varchar2(50);         --?????M?????
ifRow char(1);                    --????????
ifStat char(1); --???????????????????????????)
DayBP date; --??????????

---????
TYPE R_GROUP IS RECORD(value number(10));
TYPE T_GROUP IS TABLE OF R_GROUP INDEX BY BINARY_INTEGER;
resgroup T_GROUP;

TYPE RT_GROUP IS RECORD(value char(3));
TYPE TT_GROUP IS TABLE OF RT_GROUP INDEX BY BINARY_INTEGER;
restypegroup TT_GROUP;

num int;
i int;
---????????
StatSpan int;

sql_str varchar2(2000);
type_sql varchar2(500);
type_str varchar2(100);
tmptype varchar2(100);
group_start varchar2(10);
group_end varchar2(10);
group_num number(10);

BEGIN
EndTime := sysdate;
StartTime := to_date(to_char(add_months(EndTime,-1),'yyyymm')||'01000000','yyyymmddhh24miss');

---????????
select to_number(PARAVALUE) into StatSpan from syspara where PARANAME='PerfCollectMonth';
StatSpan := StatSpan - 1;
if StatSpan < 1 then
   StatSpan := 1;
end if;

--?????????M?????????
ItemResType := '';
for rtype in (select  distinct resclassid from ResMoniDerivedItemCfg m,restype r where MinDerivedUnit='M' and r.restypeid=m.restypeid group by r.resclassid) loop
    ItemResType := ItemResType||','||rtype.resclassid;
end loop;

select count(1) into group_num from ResSumGroup where groupnum<>0;
if group_num=0 then    --???
    resgroup(1).value := 0;
else
    num := 1;
    for g in (select groupnum from ResSumGroup where groupnum<>0) loop
        resgroup(num).value := g.groupnum;
	      num := num+1;
    end loop;
end if;
---???????
num := resgroup.first;
loop
    exit when num is null;
    group_num := resgroup(num).value;
    ifStat := 'Y';
    --????
    select count(*) into BPCount from ressumbp b where b.sumperiodtype='M' and b.groupnum=group_num;
    if BPCount=0 then
        BPTime := null;
	      ifBP := 'I';
    else
        select b.bpdate into BPTime from ressumbp b where b.sumperiodtype='M' and b.groupnum=group_num;
	      ifBP := 'U';
    end if;

    if Method='CRON' then
       if BPTime is null then
          tmpStartTime := StartTime;
          tmpEndTime := EndTime;
       else
           tmpStartTime := to_date(BPTime||'01000000','yyyymmddhh24miss');
           tmpEndTime := to_date(to_char(last_day(add_months(tmpStartTime,StatSpan)),'yyyymmdd')||'235959','yyyymmddhh24miss');
	         if tmpEndTime>EndTime then
	            tmpEndTime := EndTime;
	         end if;
       end if;
    elsif Method='SUB' then
       tmpStartTime := to_date(StartTimeStr||'01000000','yyyymmddhh24miss');
       tmpEndTime := to_date(to_char(last_day(to_date(EndTimeStr||'01','yyyymmdd')),'yyyymmdd')||'235959','yyyymmddhh24miss');
       if tmpEndTime>add_months(tmpStartTime,StatSpan) then
           tmpEndTime := to_date(to_char(last_day(add_months(tmpStartTime,StatSpan)),'yyyymmdd')||'235959','yyyymmddhh24miss');
       end if;
       if tmpEndTime>EndTime then
	         tmpEndTime := EndTime;
       end if;

       ---??????????????????
       select count(*) into BPCount from ressumbp b where b.sumperiodtype='D' and b.sumtype='P' and b.groupnum=group_num;
       if BPCount=1 then
          select to_date(substr(b.bpdate,1,8),'yyyymmdd') into DayBP from ressumbp b where b.sumperiodtype='D' and b.sumtype='P' and b.groupnum=group_num;
          if DayBP<tmpStartTime then
              ifStat := 'N';
          else
              if DayBP<tmpEndTime then
                 tmpEndTime := DayBP;
              end if;
          end if;
       end if;

       if to_char(tmpEndTime,'yyyymm')<BPTime then
           ifBP := 'N';
       end if;
    end if;

     --??????
   if ifStat='Y' then
    if group_num=0 then
        type_sql := '';
    else
        type_sql := ' AND (';
        select ResType,GroupStart,GroupEnd into type_str,group_start,group_end from ResSumGroup where groupnum=group_num;
        i := 1;
        while instr(type_str,',',1)>0 loop
           tmptype := substr(type_str,1,instr(type_str,',',1)-1);
	         type_sql := type_sql||'R.ResID between '''||tmptype||group_start||''' and '''||tmptype||group_end||''' or ';
           restypegroup(i).value := tmptype;
           i := i+1;
           type_str := substr(type_str,instr(type_str,',',1)+1,length(type_str)-1-length(tmptype));
        end loop;
	      type_sql := type_sql||'R.ResID between '''||type_str||group_start||''' and '''||type_str||group_end||''')';
        restypegroup(i).value := type_str;
    end if;

    --???????????
    ifRow := 'N';
    i := restypegroup.first;
    dbms_output.put_line(ItemResType);
    loop
        exit when i is null;
        tmptype := restypegroup(i).value;
        dbms_output.put_line(tmptype);
        if instr(ItemResType,tmptype,1)>0 then
           ifRow := 'Y';
        end if;
        i := restypegroup.next(i);
    end loop;
    --????
    while tmpStartTime<tmpEndTime loop
        gtmpEndTime := to_date(to_char(last_day(tmpStartTime),'yyyymmdd')||'235959','yyyymmddhh24miss');
	      if gtmpEndTime>tmpEndTime then
	         gtmpEndTime := tmpEndTime;
	      end if;

        --??????
	      MonthStr := to_char(tmpStartTime,'yyyymm');
        sql_str := 'delete from ResMoniMonthlyInfo R WHERE R.MonthID='''||MonthStr||''''||type_sql;
	      execute immediate sql_str;

        if ifRow = 'Y' then
            --??????
	          tmpStartStr := to_char(tmpStartTime,'yyyymmddhh24miss');
	          tmpEndStr := to_char(gtmpEndTime,'yyyymmddhh24miss');

            sql_str := 'INSERT INTO ResMoniMonthlyInfo(ResID,DerivedItemCode,ItemPara,MonthID,Value)
			 	                  ( SELECT R.ResID,D.DerivedItemCode,R.ItemPara,'''||MonthStr||''',
			 				                     decode(D.DerivedType,''SUM'',ROUND(SUM(R.Value),4),''AVG'',ROUND(AVG(R.Value),4),''MAX'',ROUND(MAX(R.Value),4),ROUND(MIN(R.VALUE),4))
			                        FROM ResMoniRawInfo R,ResMoniDerivedItemCfg D
			                       WHERE R.MoniItemCode=D.MoniItemCode
                               AND R.Value>=0
					                     AND D.MinDerivedUnit=''M''
			 		                     AND R.RecordTime>=to_date('''||tmpStartStr||''',''yyyymmddhh24miss'')
			                             and R.RecordTime<=to_date('''||tmpEndStr||''',''yyyymmddhh24miss'')'||type_sql||'
                          GROUP BY D.DerivedItemCode,D.MoniItemCode,D.DerivedType,R.ResID,R.ItemPara,'''||MonthStr||''' )';
             execute immediate sql_str;
        end if;

         --?????
         tmpStartStr := to_char(tmpStartTime,'yyyymmdd');
	       tmpEndStr := to_char(gtmpEndTime,'yyyymmdd');

         sql_str := 'INSERT INTO ResMoniMonthlyInfo(ResID,DerivedItemCode,ItemPara,MonthID,Value)
			 	                ( SELECT R.ResID,D.DerivedItemCode,R.ItemPara,'''||MonthStr||''',
			  				                 decode(D.DerivedType,''SUM'',ROUND(SUM(R.Value),4),
									                      ''AVG'',ROUND(AVG(R.Value),4),''MAX'',ROUND(MAX(R.Value),4),
			     					                    ''NONB'',ROUND(MAX(R.Value),4),''MIN'',ROUND(MIN(R.VALUE),4),
			     					                    ''BSUM'',ROUND(SUM(R.Value),4),''BAVG'',ROUND(AVG(R.Value),4),''BMAX'',ROUND(MAX(R.Value),4),
			     					                    ''BNONB'',ROUND(MAX(R.Value),4),''BMIN'',ROUND(MIN(R.VALUE),4),
			     					                    ''SSUM'',ROUND(SUM(R.Value),4),''SAVG'',ROUND(AVG(R.Value),4),''SMAX'',ROUND(MAX(R.Value),4),
			     					                    ''SNONB'',ROUND(MAX(R.Value),4),''SMIN'',ROUND(MIN(R.VALUE),4))
			                    FROM ResMoniDailyInfo R,ResMoniDerivedItemCfg D
			                    WHERE R.DerivedItemCode=D.DerivedItemCode AND D.MinDerivedUnit<>''M''
			 				              AND R.DayID>='''||tmpStartStr||''' AND R.DayID<='''||tmpEndStr||''''||type_sql||'
			                    GROUP BY D.DerivedItemCode,D.DerivedType,R.ResID,R.ItemPara,substr(R.DayID,1,6))';
         execute immediate sql_str;

         --????
	       if ifBP='I' then
	           insert into ressumbp(SumPeriodType,sumtype,groupnum,BPDate) values('M','--',group_num,to_char(tmpStartTime,'yyyymm'));
	           ifBP := 'U';
	       elsif ifBP='U' then
             if Method='CRON' or (Method='SUB' and to_char(tmpStartTime,'yyyymm')>BPTime) then
	               update ressumbp set BPDate=to_char(tmpStartTime,'yyyymm') where sumperiodtype='M' and groupnum=group_num;
             end if;
	       end if;
         select b.bpdate into BPTime from ressumbp b where b.sumperiodtype='M' and b.groupnum=group_num;

         commit;  --??
	       tmpStartTime := add_months(tmpStartTime,1);
    end loop; --??????
   end if; --??????
    num := resgroup.next(num);
    restypegroup.delete;
end loop;--??????

END;
/
