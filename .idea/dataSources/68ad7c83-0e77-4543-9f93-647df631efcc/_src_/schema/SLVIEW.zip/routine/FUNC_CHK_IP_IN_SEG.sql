CREATE function func_chk_ip_in_seg
(
    i_ip               varchar2,        --ip
    i_ipsegment        varchar2,        --ip?
    i_ip_type          number default 1,--ip??, 0???IP; 1???IP; 2??????IP
    i_ipsegment_type   number default 0 --IP????0?IP||'/'||MASK  ??????
)
return number deterministic
is
    v_nip        number(10);
    v_nipstart   number(10);
    v_nipend     number(10);
    v_nipseg     varchar2(255);
begin
    if not i_ip_type in (1,2,3) or not i_ipsegment_type = 0 then
        return -1;
    end if;

    v_nip    := case when i_ip_type in (0, 1) then func_trans_ip_str2int(i_ip) else to_number(i_ip) end;

    v_nipseg := fun_transipmask(i_ipsegment,2);

    if (i_ipsegment_type = 0) then
        v_nipstart := to_number(substr(v_nipseg, 1, instr(v_nipseg, '-')-1));
        v_nipend   := to_number(substr(v_nipseg, instr(v_nipseg, '-')+1));
    end if;

    return case when v_nip between v_nipstart and v_nipend then 1 else 0 end;

exception when others then
    return -1;
end func_chk_ip_in_seg;

/
