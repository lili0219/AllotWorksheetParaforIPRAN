CREATE PROCEDURE genportalarmlevel
IS
    l_portdescr varchar2(300) ;
    l_portdescrdetail varchar2(300) ;
BEGIN
    -- ?????
    delete from  reporttemptable ;
    commit ;


    --??"????????"??PortAlarmLevelRule?????ruleseq?????????????????????
    for l_rec in (select RuleID,DefineType,NodeCode,DevPropCode,DevTag,PortDescrDetail,PortDescr,PortDescrMatchType,CirPropCode,AlarmLevel
                from PortAlarmLevelRule order by ruleseq) loop

        -- ???????Device???????????????????????????????????+???DEFAULT?merge????ReportTempTable
        if l_rec.definetype='Device' then
            -- ??????Devtag???????restag?
            if l_rec.devtag is not null then
                Merge into ReportTempTable a
                    Using (select deviceid,'DEFAULT' portdescr,l_rec.alarmlevel alarmlevel,l_rec.ruleid ruleid
                from device aa,restag bb,node cc
                where aa.deviceid=bb.resid
                    and (l_rec.DevPropCode is null or instr(','||l_rec.DevPropCode||',',','||nvl(aa.devicepropcode,',')||',')>0)
                    and bb.tag=l_rec.devtag and aa.changetype=0 and aa.nodecode=cc.nodecode and instr(cc.nodefullcode,l_rec.nodecode)>0 ) b
                ON  (a.str0=b.deviceid and a.str1=b.portdescr)
                WHEN matched then update set a.num0=b.alarmlevel, a.num1=b.ruleid
                When not matched then insert  (a.str0,a.str1,a.num0,a.num1) values (b.deviceid,b.portdescr,b.alarmlevel,b.ruleid) ;
            -- ??????Devtag????????restag?
            else
                Merge into ReportTempTable a
                    Using (select deviceid,'DEFAULT' portdescr,l_rec.alarmlevel alarmlevel,l_rec.ruleid ruleid
                from device aa,node cc
                where (l_rec.DevPropCode is null or instr(','||l_rec.DevPropCode||',',','||nvl(aa.devicepropcode,',')||',')>0)
                    and aa.changetype=0 and aa.nodecode=cc.nodecode and instr(cc.nodefullcode,l_rec.nodecode)>0 ) b
                ON  (a.str0=b.deviceid and a.str1=b.portdescr)
                WHEN matched then update set a.num0=b.alarmlevel, a.num1=b.ruleid
                When not matched then insert  (a.str0,a.str1,a.num0,a.num1) values (b.deviceid,b.portdescr,b.alarmlevel,b.ruleid) ;
            end if ;

        --	???????Port??????????????????????????????????????????????????"??+??"merge????ReportTempTable
        elsif l_rec.definetype='Port' then
            -- ????????????
            if l_rec.PortDescrMatchType='E' then
                l_portdescr := lower(l_rec.portdescr) ;
            else
                l_portdescr := '%' || lower(l_rec.portdescr) || '%' ;
            end if ;
            l_portdescrdetail := '%' || lower(l_rec.portdescrdetail) || '%' ;


            -- ??????Devtag???????restag?
            if l_rec.devtag is not null then
                -- ??????????????????
                if l_rec.cirpropcode is not null then
                    Merge into ReportTempTable a
                    Using (select aa.deviceid,dd.portdescr,l_rec.alarmlevel alarmlevel,l_rec.ruleid ruleid
                    from device aa,restag bb,node cc,portinfo dd,circuit ee,
                        (select distinct cb.cirpropcode from cirprop ca,cirprop cb
                         where  instr(','||l_rec.cirpropcode||',',','||nvl(ca.cirpropcode,',')||',')>0 and cb.cirpropfullcode like ca.cirpropfullcode||'%') ff
                    where aa.deviceid=bb.resid  and aa.deviceid=dd.deviceid
		              and (l_rec.DevPropCode is null or instr(','||l_rec.DevPropCode||',',','||nvl(aa.devicepropcode,',')||',')>0)
		              and bb.tag=l_rec.devtag and aa.changetype=0 and aa.nodecode=cc.nodecode and instr(cc.nodefullcode,l_rec.nodecode)>0
		              and  lower(dd.portdescr) like l_portdescr and lower(dd.portdescrdetail) like l_portdescrdetail
		              and ((dd.deviceid=ee.adeviceid and dd.portdescr=ee.aintdescr) or (dd.deviceid=ee.bdeviceid and dd.portdescr=ee.bintdescr))
		              and ee.changetype=0 and ee.cirpropcode=ff.cirpropcode ) b
                    ON  (a.str0=b.deviceid and a.str1=b.portdescr)
                    WHEN matched then update set a.num0=b.alarmlevel, a.num1=b.ruleid
                    When not matched then insert  (a.str0,a.str1,a.num0,a.num1) values (b.deviceid,b.portdescr,b.alarmlevel,b.ruleid) ;
                -- ???????????????????
                else
                    Merge into ReportTempTable a
                    Using (select aa.deviceid,dd.portdescr,l_rec.alarmlevel alarmlevel,l_rec.ruleid ruleid
                    from device aa,restag bb,node cc,portinfo dd
                    where aa.deviceid=bb.resid  and aa.deviceid=dd.deviceid
		              and (l_rec.DevPropCode is null or instr(','||l_rec.DevPropCode||',',','||nvl(aa.devicepropcode,',')||',')>0)
		              and bb.tag=l_rec.devtag and aa.changetype=0 and aa.nodecode=cc.nodecode and instr(cc.nodefullcode,l_rec.nodecode)>0
		              and  lower(dd.portdescr) like l_portdescr and lower(dd.portdescrdetail) like l_portdescrdetail ) b
                    ON  (a.str0=b.deviceid and a.str1=b.portdescr)
                    WHEN matched then update set a.num0=b.alarmlevel, a.num1=b.ruleid
                    When not matched then insert  (a.str0,a.str1,a.num0,a.num1) values (b.deviceid,b.portdescr,b.alarmlevel,b.ruleid) ;
                end if ;

            -- ??????Devtag????????restag?
            else
               -- ??????????????????
                if l_rec.cirpropcode is not null then
                    Merge into ReportTempTable a
                    Using (select aa.deviceid,dd.portdescr,l_rec.alarmlevel alarmlevel,l_rec.ruleid ruleid
                    from device aa,node cc,portinfo dd,circuit ee,
                        (select distinct cb.cirpropcode from cirprop ca,cirprop cb
                         where  instr(','||l_rec.cirpropcode||',',','||nvl(ca.cirpropcode,',')||',')>0 and cb.cirpropfullcode like ca.cirpropfullcode||'%') ff
                    where aa.deviceid=dd.deviceid
		              and (l_rec.DevPropCode is null or instr(','||l_rec.DevPropCode||',',','||nvl(aa.devicepropcode,',')||',')>0)
		              and aa.changetype=0 and aa.nodecode=cc.nodecode and instr(cc.nodefullcode,l_rec.nodecode)>0
		              and  lower(dd.portdescr) like l_portdescr and lower(dd.portdescrdetail) like l_portdescrdetail
		              and ((dd.deviceid=ee.adeviceid and dd.portdescr=ee.aintdescr) or (dd.deviceid=ee.bdeviceid and dd.portdescr=ee.bintdescr))
		              and ee.changetype=0 and ee.cirpropcode=ff.cirpropcode ) b
                    ON  (a.str0=b.deviceid and a.str1=b.portdescr)
                    WHEN matched then update set a.num0=b.alarmlevel, a.num1=b.ruleid
                    When not matched then insert  (a.str0,a.str1,a.num0,a.num1) values (b.deviceid,b.portdescr,b.alarmlevel,b.ruleid) ;
                -- ???????????????????
                else
                    Merge into ReportTempTable a
                    Using (select aa.deviceid,dd.portdescr,l_rec.alarmlevel alarmlevel,l_rec.ruleid ruleid
                    from device aa,node cc,portinfo dd
                    where aa.deviceid=dd.deviceid
		              and (l_rec.DevPropCode is null or instr(','||l_rec.DevPropCode||',',','||nvl(aa.devicepropcode,',')||',')>0)
		              and aa.changetype=0 and aa.nodecode=cc.nodecode and instr(cc.nodefullcode,l_rec.nodecode)>0
		              and  lower(dd.portdescr) like l_portdescr and lower(dd.portdescrdetail) like l_portdescrdetail ) b
                    ON  (a.str0=b.deviceid and a.str1=b.portdescr)
                    WHEN matched then update set a.num0=b.alarmlevel, a.num1=b.ruleid
                    When not matched then insert  (a.str0,a.str1,a.num0,a.num1) values (b.deviceid,b.portdescr,b.alarmlevel,b.ruleid) ;
                end if ;
            end if ;

        end if ;

    end loop ;

-- ?ReportTempTable???merge?PortAlarmLevel???merge????????PortAlarmLevel???????ruleid=0?????
    Merge into PortAlarmLevel  a
    Using (select str0,str1,num0,num1
    from reporttemptable
    where (str0,str1) not in (select deviceid,portdescr from portalarmlevel where ruleid=0)) b
    ON  (b.str0=a.deviceid and b.str1=a.portdescr)
	 WHEN matched then update set a.alarmlevel=b.num0, a.ruleid=b.num1
	When not matched then insert  (a.deviceid,a.portdescr,a.alarmlevel,a.ruleid) values (b.str0,b.str1,b.num0,b.num1) ;

-- ?PortAlarmLevel????ruleid>0??deviceid+portdescr?reporttemptable?????????
    delete from portalarmlevel where ruleid>0 and (deviceid,portdescr) not in (select str0,str1 from reporttemptable) ;

-- ??PortAlarmLevelRule???????LastLoadTime??????
    update PortAlarmLevelRule set lastloadtime=sysdate ;

    commit ;


END;
/
