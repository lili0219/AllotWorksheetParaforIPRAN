CREATE PROCEDURE DATACLEAN
   ( i_end_date IN date DEFAULT sysdate)
   IS
   l_rowcount integer;
   l_err_string varchar2(200);
BEGIN
    /*???10??????*/
    begin
        slvw_partition.add_partition(i_end_date+10);
    exception
        when others then
            null;
    end ;

    /*????*/
    begin
        slvw_partition.trunc_partition(i_end_date);
    exception
        when others then
            null;
    end ;

    /*????????????????30?*/
    begin
        slvw_partition.drop_partition(i_end_date - 31);
    exception
        when others then
            null;
    end ;

    /*??????????*/
    begin
        /*???????????*/
        delete resmonicurinfo where recordtime < i_end_date - 2 ;
/*        l_rowcount := sql%rowcount;
        INSERT INTO  ERRLOGINFO( LOGTIME , ERRORCODE , ERRORPROGRAM , ERRORDESC , ERRORDETAIL )
        values (sysdate,'DMG6001','DATACLEAN','????????????->'||to_char(i_end_date,'yyyy-mm-dd hh24:mi:ss'),'??'||to_char(l_rowcount)||'???'); */
        commit;
    exception
        when others then
            l_err_string := substr(sqlerrm,1,100) ;
            INSERT INTO  ERRLOGINFO( LOGTIME , ERRORCODE , ERRORPROGRAM , ERRORDESC , ERRORDETAIL )
            values (sysdate,'DMG2001','DATACLEAN','????????????->'||to_char(i_end_date,'yyyy-mm-dd hh24:mi:ss'),l_err_string);
            commit;
    end ;

    /*???????*/
    begin
        /*?????????????*/
        delete onlineuser where logintime < i_end_date - 1 ;
/*        l_rowcount := sql%rowcount;
        INSERT INTO  ERRLOGINFO( LOGTIME , ERRORCODE , ERRORPROGRAM , ERRORDESC , ERRORDETAIL )
        values (sysdate,'DMG6001','DATACLEAN','?????????->'||to_char(i_end_date,'yyyy-mm-dd hh24:mi:ss'),'??'||to_char(l_rowcount)||'???');*/
        commit;
    exception
        when others then
            l_err_string := substr(sqlerrm,1,100) ;
            INSERT INTO  ERRLOGINFO( LOGTIME , ERRORCODE , ERRORPROGRAM , ERRORDESC , ERRORDETAIL )
            values (sysdate,'DMG2001','DATACLEAN','?????????->'||to_char(i_end_date,'yyyy-mm-dd hh24:mi:ss'),l_err_string);
            commit;
    end ;

END;
/
