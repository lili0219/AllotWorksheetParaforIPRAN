CREATE PROCEDURE refreshnoderesrela
IS
BEGIN
   EXECUTE IMMEDIATE 'truncate table NodeResRela';

   INSERT INTO noderesrela
               (nodecode, restype, resmodel)
      SELECT DISTINCT c.nodecode, a.restypeid, NVL (a.resmodelid, 'N')
                 FROM res a, node b, node c
                WHERE a.nodecodea = b.nodecode
                  AND b.nodefullcode LIKE c.nodefullcode || '%'
      UNION
      SELECT DISTINCT c.nodecode, a.restypeid, NVL (a.resmodelid, 'N')
                 FROM res a, node b, node c
                WHERE a.nodecodeb IS NOT NULL
                  AND a.nodecodeb = b.nodecode
                  AND b.nodefullcode LIKE c.nodefullcode || '%';

   COMMIT;
END;
/
