CREATE PROCEDURE alarmbenchcommoving
IS
   TYPE engcur IS REF CURSOR;

   l_engcur        engcur;
   l_probedidcur   engcur;
   l_sqlcur        engcur;
   l_resid         alarmbasevalue.resid%TYPE;
   l_respara       alarmbasevalue.respara%TYPE;
   l_itemid        alarmbasevalue.itemid%TYPE;
   l_period        alarmbasevalue.period%TYPE;
   l_maxtime       DATE;
   l_mintime       DATE;
   l_value         NUMBER;
   l_alarmcondid   alarmbasevalue.alarmcondid%TYPE;
   sqlstr          VARCHAR (2000);
   executetime     NUMBER;
   l_start         NUMBER;
   l_sqlnum        NUMBER;
   l_probeid       resgroup.probeid%TYPE;
   l_updatenum     NUMBER;
   l_err           VARCHAR (2000);
BEGIN
   OPEN l_probedidcur FOR
      SELECT DISTINCT probeid
                 FROM resgroup
                WHERE coltype = 'FLUX' OR coltype = 'PERF';

   LOOP
      FETCH l_probedidcur
       INTO l_probeid;

      EXIT WHEN l_probedidcur%NOTFOUND;

      OPEN l_sqlcur FOR
         SELECT SQL, seq
           FROM alarmcomsql
          WHERE TYPE = 'moving';

      --WHERE  seq = 67;
      LOOP
         FETCH l_sqlcur
          INTO sqlstr, l_sqlnum;

         EXIT WHEN l_sqlcur%NOTFOUND;
         --DBMS_OUTPUT.put_line (SUBSTR (sqlstr, 0, 255));
         --DBMS_OUTPUT.put_line (SUBSTR (sqlstr, 254, 255));
         --DBMS_OUTPUT.put_line (SUBSTR (sqlstr, 508, 255));
         --DBMS_OUTPUT.put_line (SUBSTR (sqlstr, 762, LENGTH (sqlstr) - 762));
         sqlstr := SUBSTR (sqlstr, 0, LENGTH (sqlstr) - 1);
         l_start := DBMS_UTILITY.get_time;

         OPEN l_engcur FOR sqlstr USING l_probeid;

         BEGIN
            INSERT INTO alarmcomlog
                        (seq, probeid
                        )
                 VALUES (l_sqlnum, l_probeid
                        );

            COMMIT;
         EXCEPTION
            WHEN OTHERS
            THEN
               DBMS_OUTPUT.put_line ('time sql' || SQLERRM);
         END;

         BEGIN
            LOOP
               FETCH l_engcur
                INTO l_resid, l_respara, l_itemid, l_alarmcondid, l_period,
                     l_value, l_maxtime, l_mintime;

               EXIT WHEN l_engcur%NOTFOUND;

               UPDATE alarmbasevalue
                  SET basevalue = l_value,
                      starttime = l_mintime,
                      endtime = l_maxtime
                WHERE resid = l_resid
                  AND respara = DECODE (l_respara, 'NONE', '-1', l_respara)
                  AND itemid = l_itemid
                  AND period = TO_NUMBER (l_period)
                  AND alarmcondid = l_alarmcondid
                  AND dayofweek = -1;

               l_updatenum := SQL%ROWCOUNT;
               COMMIT;

               IF (l_updatenum = 0)
               THEN
                  INSERT INTO alarmbasevalue
                              (resid, respara, alarmcondid, itemid, period,
                               dataitemid, baseitemtype, basevalue,
                               starttime, endtime)
                     SELECT l_resid,
                            DECODE (l_respara, 'NONE', '-1', l_respara),
                            l_alarmcondid, l_itemid, TO_NUMBER (l_period),
                            dataitemid, baseitemtype, l_value, l_mintime,
                            l_maxtime
                       FROM alarmconditionitem
                      WHERE l_alarmcondid = alarmcondid AND itemid = l_itemid;

                  COMMIT;
               END IF;
            END LOOP;
         EXCEPTION
            WHEN OTHERS
            THEN
               DBMS_OUTPUT.put_line ('insert new alarmbase sql' || SQLERRM);
               l_err := SUBSTR (SQLERRM, 1, 2000);

               UPDATE alarmcomlog
                  SET err = l_err
                WHERE seq = l_sqlnum AND probeid = l_probeid;

               COMMIT;
         END;

         --????
         BEGIN
            executetime := ROUND ((DBMS_UTILITY.get_time - l_start) / 100, 2);

            UPDATE alarmcomlog
               SET exetime = executetime
             WHERE seq = l_sqlnum AND probeid = l_probeid;

            COMMIT;
         EXCEPTION
            WHEN OTHERS
            THEN
               DBMS_OUTPUT.put_line ('update time sql' || SQLERRM);
         END;

         CLOSE l_engcur;
      END LOOP;

      CLOSE l_sqlcur;
   END LOOP;

   CLOSE l_probedidcur;
-- dbms_output.put_line(((sysdate()-executetime)*24*60*1000));
EXCEPTION
   WHEN OTHERS
   THEN
      NULL;                    --DBMS_OUTPUT.put_line (all SQLERRM, 0, 255));
END;
/
