CREATE VIEW PORTCARDINFO AS select a.DeviceID, a.LPDescr, 'L', a.LPType, a.LPIndex, a.LPSpeed, a.VPI, a.VCI, a.DLCI, a.AdminStatus, a.OperStatus, b.CardIndex,a.PortDescrDetail,b.PortMode,b.Distance
from LPInfo a, PPInfo b
where a.ChangeType = 0 and a.DeviceID = b.deviceid(+) and a.PPDescr = b.ppdescr(+) and nvl(b.changetype,0) = 0
union
select DeviceID, PPDescr, 'P', PPType, PPIndex, PPSpeed, -1, -1, -1, AdminStatus, OperStatus, CardIndex, PortDescrDetail,PortMode,Distance
from PPInfo
where ChangeType = 0
/
