CREATE VIEW RPT_DEVICETAGFULL AS select d.deviceid,t.tagfull
from device d, restagfull t
where d.deviceid = t.resid(+)
      and d.changetype=0
/
