CREATE VIEW MR_CVCARDDESCR AS select distinct b.paravaluea carddescr,
            b.paravalueb cvdescr
from cardinfo a,convertcfg b
where a.carddescr=b.paravaluea and
      b.devicetype='CV' and
      b.paraname='MR_CV_CardDescr' and
      a. carddescr is not null
union
select distinct carddescr carddescr,
            carddescr cvdescr
from cardinfo a
where a.carddescr not in
( select paravaluea from  convertcfg where paraname='MR_CV_CardDescr' )  and
a. carddescr is not null
Union
Select null,'??' from dual
with read only
/
