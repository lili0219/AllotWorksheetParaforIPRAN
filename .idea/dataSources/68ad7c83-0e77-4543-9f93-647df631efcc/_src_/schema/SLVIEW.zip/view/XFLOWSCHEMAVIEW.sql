CREATE VIEW XFLOWSCHEMAVIEW AS select fs.schemaid,fs.schemaname,fv.xflowviewid,fv.xflowviewname from xFlowSchema fs, xFlowViewInstance fvi, xFlowView fv where fs.schemaid = fvi.schemaid and fvi.xflowviewid = fv.xflowviewid and fv.xflowviewid !='G001' and fs.xflowappid=1 and fs.schematype=2 and fs.isenabled=1
/
