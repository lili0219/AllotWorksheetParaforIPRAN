CREATE VIEW RPT_SUBNODE AS select l1.nodecode  NodeCode,
       l2.nodecode  SubNodeCode,
       l2.nodename  SubNodeName
from node l1,
     node l2,
     node l3
where (l1.nodecode = subStr( l2.NodeFullCode, (l2.nodelevel-2)*7+1 ,'6' ) and l1.nodecode != l2.nodecode)
      and (l3.nodefullcode like '%'||l2.nodecode||'%' and l3.isleaf = 1)
union
select nodecode,
       nodecode,
       nodename
from node
where isleaf = 1
/
