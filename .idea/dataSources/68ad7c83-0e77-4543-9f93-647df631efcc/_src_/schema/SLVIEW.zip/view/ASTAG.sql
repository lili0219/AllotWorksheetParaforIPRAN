CREATE VIEW ASTAG AS select ASNumber,NetName
from bgpas
/
