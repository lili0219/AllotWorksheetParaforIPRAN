CREATE VIEW NMSRESVIEW AS select link.vpnlinkid,link.AccessLineCode ACCESSNO,link.vrfname VRFNAME,link.extcircuitid extcircuitid,
dev.loopaddress PELOOPBACK,link.peintdescr LOGICPORTCODE,
link.peportip PEIP,link.ceportip CEIP,CC.LOOPADDRESS SWLOOPBACK,link.portspeed RATE,
link.peintdescr peintdescr ,link.encapattr encapattr
from mplsvpnlink link,Pe pe,Device dev,
(
select l.vpnlinkid,d.LoopAddress from MPLSVPNLink l,PEExtCircuit e,PE p,Device d where l.ExtCircuitID=e.ExtCircuitID and e.EndDeviceID=p.PEID and p.DeviceID=d.DeviceID and d.changetype=0
) CC
where
 link.peid=pe.peid and pe.deviceid=dev.deviceid and dev.changetype=0
and link.vpnlinkid = CC.VPNLINKID(+)
/
