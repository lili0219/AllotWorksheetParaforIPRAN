CREATE VIEW DHCCARDVIEW AS select a.DeviceID,a.CardIndex,a.ChangeType,a.CardSN,a.CardType,a.CardDescr,a.FatherIndex,a.HwVersionNo,a.SlotCode,a.HWModel,a.HWClass,a.HWCaseid,a.hwtype,a.cardcode from cardinfo a,dhcdeviceview b,(select DEVICEID,CARDcode,count(*) as cardcount
 from cardinfo where changetype=0 and cardcode is not null group by DEVICEID,cardcode)c where a.deviceid=b.deviceid and a.HWClass in ('optical','subcard','card') and a.changetype=0 and a.deviceid=c.deviceid and a.cardcode=c.cardcode and c.cardcount=1
with read only
/
