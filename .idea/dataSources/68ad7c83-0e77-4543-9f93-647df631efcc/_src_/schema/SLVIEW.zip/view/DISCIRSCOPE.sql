CREATE VIEW DISCIRSCOPE AS select circuitid from circuit where changetype=0
with read only
/
