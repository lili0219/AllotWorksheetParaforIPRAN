CREATE VIEW DHCDEVICEVIEW AS select a.DeviceID,a.ChangeType,a.DeviceName,a.LoopAddress,a.DeviceModelCode,a.DetailModelCode,a.OSVersion,a.NodeCode,a.DeviceSN,a.devicemac,b.vendor,a.devicepropcode from device a,devicemodel b where a.DeviceTypeCode in ('DEV_IP_R','DEV_IP_S','DEV_IP_N','DEV_IP_B') AND a.changetype =0 and a.DeviceModelCode=b.devicemodelcode
with read only
/
