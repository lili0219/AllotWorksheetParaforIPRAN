CREATE VIEW REP_PE_SERVPOT_USD AS select p.deviceid deviceid,
p.portdescr ppdescr,
ppspeed portspeed
from DevServPortInfo p
where IsNetPort='N'
/
