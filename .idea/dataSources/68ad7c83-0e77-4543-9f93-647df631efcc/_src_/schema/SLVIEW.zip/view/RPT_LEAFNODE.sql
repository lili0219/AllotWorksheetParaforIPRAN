CREATE VIEW RPT_LEAFNODE AS select distinct
       n2.nodecode NodeCode,
       n3.nodecode LFNodeCode,
       n3.nodename LFNodeName
from   node n3,
       node n2,
       node n1
where  n3.isleaf='1' and
       (n1.nodecode = subStr( n2.NodeFullCode, (n2.nodelevel-2)*7+1 ,'6' ) and n1.nodecode != n2.nodecode)
      and (n3.nodefullcode like '%'||n2.nodecode||'%' and n3.isleaf = 1)
/
