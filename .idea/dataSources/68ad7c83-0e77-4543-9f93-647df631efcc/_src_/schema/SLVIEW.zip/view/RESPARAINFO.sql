CREATE VIEW RESPARAINFO AS select deviceid as resid,portdescr as respara, PORTDESCRDETAIL as resparadesc from portinfo
union all
select deviceid as resid,'SLOT '||slotcode as respara, NULL as resparadesc from slotinfo where changetype=0
union all
select deviceid as resid,'card in SLOT '||slotcode as respara, '???:'||cardsn||',???'||cardtype as resparadesc from cardinfo where changetype=0
/
