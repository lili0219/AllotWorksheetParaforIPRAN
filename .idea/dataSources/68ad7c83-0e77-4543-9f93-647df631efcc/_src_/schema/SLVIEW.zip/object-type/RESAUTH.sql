CREATE TYPE "RESAUTH"                                                                                                                                                                                                                                                                                                                                                       as object (
    ResID CHAR(8)
)
/
