CREATE TYPE "RESAUTHRESULT"                                                                                                                                                                                                                                                                                                                                                       as table of ResAuth
/
