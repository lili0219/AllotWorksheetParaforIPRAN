CREATE TYPE "NODEAUTHRESULT"                                                                                                                                                                                                                                                                                                                                                       as table of NodeAuth
/
