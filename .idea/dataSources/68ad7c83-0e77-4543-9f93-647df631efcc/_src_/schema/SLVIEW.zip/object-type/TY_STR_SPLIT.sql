CREATE TYPE "TY_STR_SPLIT"                                                                                                                                                                                                                                                                                                                                                       IS TABLE OF VARCHAR2 (4000);
/
