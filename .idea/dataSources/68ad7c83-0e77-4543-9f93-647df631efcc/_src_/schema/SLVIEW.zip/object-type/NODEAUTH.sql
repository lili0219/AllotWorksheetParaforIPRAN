CREATE TYPE "NODEAUTH"                                                                                                                                                                                                                                                                                                                                                       as object (
    NodeCode CHAR(6)
)
/
