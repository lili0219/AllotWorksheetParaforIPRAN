CREATE TRIGGER TRG_CG
AFTER INSERT OR UPDATE OF CGID, CGNAME, NODECODEA, NODECODEB, REMARK OR DELETE
  ON CG
FOR EACH ROW
  begin
    /*???????*/
    if (inserting) then
        begin
            insert into res(resid,resname,restypeid,nodecodea,nodecodeb,ipaddressa,ipaddressb,remark)
            values (:new.cgid,:new.cgname,'CIG_COM',:new.nodecodea,:new.nodecodeb,null,null,:new.remark);
        exception
            when others then
                update res
                set resname = :new.cgname,
                    restypeid = 'CIG_COM',
                    nodecodea = :new.nodecodea,
                    nodecodeb = :new.nodecodeb,
                    ipaddressa = null,
                    ipaddressb = null,
                    remark = :new.remark
                where resid = :new.cgid ;
        end ;
     /*???????*/
     elsif (updating) then
        update res
        set resid = :new.cgid,
            resname = :new.cgname,
            restypeid = 'CIG_COM',
            nodecodea = :new.nodecodea,
            nodecodeb = :new.nodecodeb,
            ipaddressa = null,
            ipaddressb = null,
            remark = :new.remark
        where resid = :old.cgid ;
    /*???????*/
    elsif (deleting) then
        delete res where resid = :old.cgid ;
    end if;
end ;
/
