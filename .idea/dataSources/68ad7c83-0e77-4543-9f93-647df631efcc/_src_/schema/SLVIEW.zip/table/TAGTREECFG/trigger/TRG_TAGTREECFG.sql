CREATE TRIGGER TRG_TAGTREECFG
AFTER INSERT OR UPDATE OF TAGTREENODEFULLCODE
  ON TAGTREECFG
FOR EACH ROW
  BEGIN
   IF :NEW.TYPE = 'FP' or :NEW.TYPE = 'BAS'
   THEN
      UPDATE tagtreenodecode_res
         SET tagtreenodefullcode = :NEW.tagtreenodefullcode
       WHERE tagtreenodecode = :NEW.tagtreenodecode;
   END IF;
END;
/
