CREATE TRIGGER TRG_BGPNEICFG
AFTER INSERT OR UPDATE OF NEIID, CHANGETYPE, NEINAME, DEVICEID, NEIIP OR DELETE
  ON BGPNEICFG
FOR EACH ROW WHEN (FOR EACH ROW )
declare
    l_nodecodea res.nodecodea%type;
    l_ipaddressa res.ipaddressa%type;
begin
    /*????????A????IP??*/
    if (:new.changetype = 0) then
        begin
            select nodecode,loopaddress into l_nodecodea,l_ipaddressa
            from device
            where deviceid = :new.deviceid
                and changetype = 0 ;
        exception
            when no_data_found then
                l_nodecodea := null;
                l_ipaddressa := null;
        end ;
    end if;

    /*????BGP??*/
    if (inserting or (updating and :new.changetype = 0 and :old.changetype!=0)) then
        begin
            insert into res(resid,resname,restypeid,nodecodea,nodecodeb,ipaddressa,ipaddressb)
            values (:new.neiid,:new.neiname,'ROU_BGPNEI',l_nodecodea,null,l_ipaddressa,:new.neiip);
        exception
            when others then
                update res
                set resname = :new.neiname,
                    restypeid = 'ROU_BGPNEI',
                    nodecodea = l_nodecodea,
                    nodecodeb = null,
                    ipaddressa = l_ipaddressa,
                    ipaddressb = :new.neiip
                where resid = :new.neiid ;
        end ;
     /*??????*/
     elsif (updating and :new.changetype = 0 and :old.changetype=0) then
        update res
        set resid = :new.neiid,
            resname = :new.neiname,
            restypeid = 'ROU_BGPNEI',
            nodecodea = l_nodecodea,
            nodecodeb = null,
            ipaddressa = l_ipaddressa,
            ipaddressb = :new.neiip
        where resid = :old.neiid ;
    /*??????*/
    elsif (deleting or (updating and :new.changetype != 0 and :old.changetype=0)) then
        delete res where resid = :old.neiid ;
    end if;
end ;
/
