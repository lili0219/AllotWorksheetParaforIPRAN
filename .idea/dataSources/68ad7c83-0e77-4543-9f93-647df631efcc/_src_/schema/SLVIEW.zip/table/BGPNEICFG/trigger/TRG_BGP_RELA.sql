CREATE TRIGGER TRG_BGP_RELA
AFTER INSERT OR UPDATE OF CHANGETYPE, NEINAME, DEVICEID OR DELETE
  ON BGPNEICFG
FOR EACH ROW
  BEGIN

    /*??????*/
    IF (INSERTING AND :NEW.ChangeType=0) THEN
        /*????*/
        BEGIN
        INSERT INTO RESRELATION (ARESID, ARESPARA, ARESCLASSID,BRESID, BRESPARA, BRESNAME,BRESCLASSNAME, RELATYPE)
        VALUES ( :NEW.DeviceID, '-1','DEV' , :NEW.NeiID, '-1', :NEW.NeiName,'BGP??' , 'REFERED');
        EXCEPTION
            WHEN OTHERS THEN
                UPDATE RESRELATION
                SET BRESNAME = :NEW.NeiName
                WHERE BResID=:OLD.NeiID;
        END ;
    /*??????*/
    ELSIF (DELETING OR (UPDATING AND :NEW.changetype = -1 AND :OLD.changetype=0)) THEN
      DELETE FROM RESRELATION WHERE AResID = :OLD.DeviceID AND ARESPARA='-1' and BResID=:OLD.NeiID AND BResPara='-1';
     /*??????*/
     ELSIF (UPDATING AND :NEW.changetype = 0 AND :OLD.changetype = 0) THEN
        BEGIN
        /*??????*/
        DELETE FROM RESRELATION WHERE BResID=:OLD.NeiID;
        /*??????*/
        INSERT INTO RESRELATION (ARESID, ARESPARA, ARESCLASSID,BRESID, BRESPARA, BRESNAME,BRESCLASSNAME, RELATYPE)
        VALUES ( :NEW.DeviceID, '-1','DEV' , :NEW.NeiID, '-1', :NEW.NeiName,'BGP??' , 'REFERED');
        EXCEPTION
            WHEN OTHERS THEN
                UPDATE RESRELATION
                SET BRESNAME = :NEW.NeiName
                WHERE BResID=:OLD.NeiID;
        END ;
    END IF;
END ;
/
