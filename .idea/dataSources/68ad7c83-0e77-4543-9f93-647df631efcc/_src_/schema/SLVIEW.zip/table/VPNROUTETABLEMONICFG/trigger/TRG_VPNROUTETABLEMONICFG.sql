CREATE TRIGGER TRG_VPNROUTETABLEMONICFG
AFTER INSERT OR UPDATE OF VPNROUTETABLEID, VPNROUTETABLENAME, PEID, VALIDFLAG OR DELETE
  ON VPNROUTETABLEMONICFG
FOR EACH ROW WHEN (FOR EACH ROW )
declare
    	l_nodecodea res.nodecodea%type;
    	l_ipaddressa res.ipaddressa%type;
 begin
 	/*????????A????IP??*/
 	if (:new.ValidFlag = 0) then
 		begin
                	select d.nodecode,d.loopaddress into l_nodecodea,l_ipaddressa
                	from pe p,device d
                	where p.deviceid=d.deviceid and p.peid=:new.peid
                	and d.changetype = 0 ;
                exception
            		when no_data_found then
                	l_nodecodea := null;
                	l_ipaddressa := null;
        	end ;
    	end if;

    	/*??*/
    	if (inserting or (updating and :new.ValidFlag = 0 and :old.ValidFlag!=0)) then
        	begin
        		insert into res(resid,resname,restypeid,nodecodea,nodecodeb,ipaddressa,ipaddressb)
            		values (:new.VpnRouteTableID,:new.VpnRouteTableName,'RTB_VPN',l_nodecodea,null,l_ipaddressa,null);
        	exception
            		when others then
                	update res
                	set resname = :new.VpnRouteTableName,
                    	restypeid = 'RTB_VPN',
                    	nodecodea = l_nodecodea,
                	nodecodeb = null,
                    	ipaddressa = l_ipaddressa,
                    	ipaddressb = null
                	where resid = :new.VpnRouteTableID ;
        	end ;
        /*??*/
        elsif (updating and :new.ValidFlag = 0 and :old.ValidFlag=0) then
        	update res
        	set resid = :new.VpnRouteTableID,
            	resname = :new.VpnRouteTableName,
            	restypeid = 'RTB_VPN',
            	nodecodea = l_nodecodea,
            	nodecodeb = null,
            	ipaddressa = l_ipaddressa,
            	ipaddressb = null
        	where resid = :old.VpnRouteTableID ;
        /*??*/
    	elsif (deleting or (updating and :new.ValidFlag != 0 and :old.ValidFlag=0)) then
        	delete res where resid = :old.VpnRouteTableID ;
    	end if;
end ;
/
