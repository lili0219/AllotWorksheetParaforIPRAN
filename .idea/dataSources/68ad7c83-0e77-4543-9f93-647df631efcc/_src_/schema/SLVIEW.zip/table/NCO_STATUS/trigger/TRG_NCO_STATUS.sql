CREATE TRIGGER TRG_NCO_STATUS
BEFORE INSERT OR UPDATE OR DELETE
  ON NCO_STATUS
FOR EACH ROW
  DECLARE
   l_alarmtypeid           alertgroupmap.alarmtypeid%TYPE;
   l_resid                 alarmsummary.resid%TYPE;
   l_slviewserialid        nco_status.slviewserialid%TYPE;
   l_insertalarm           PLS_INTEGER;
   l_new_firstoccurrence   DATE;
   l_respara               alarmsummary.respara%TYPE;
   isip                    BOOLEAN;
   num                     NUMBER;
BEGIN
   l_insertalarm := 0;

/*??????*/
   IF INSERTING AND :NEW.severity > 0
   THEN
      l_insertalarm := 1;
      l_new_firstoccurrence := :NEW.firstoccurrence;
/*??????*/
   ELSIF UPDATING ('DELETEDAT') OR DELETING
   THEN
/*?????SLVIEW??,????????????*/
      RETURN;
/*??????*/
   ELSE
/*?????SLVIEW??,??????*/
      IF (:OLD.slviewserialid > 0)
      THEN
         UPDATE alarmsummary
            SET lastoccurtime = :NEW.lastoccurrence,
                times = times + :NEW.tally - NVL (:OLD.tally, 0),
                summary =
                   SUBSTRB (   SUBSTR (summary,
                                          0,
                                          decode(INSTR (summary, '::::'),0,0,INSTR (summary, '::::') + 3)
                                         )
                               || :NEW.summary,
                               0,
                               255
                              ),
                keyword = :NEW.keyword,
                stoptime = NULL,
                additionalinfo =
                   DECODE (:NEW.additionalinfo,
                           NULL, additionalinfo,
                           :NEW.additionalinfo
                          )
          WHERE sumalarmid = :NEW.slviewserialid;

/*?????????,??????*/
         IF SQL%ROWCOUNT = 0 AND :NEW.severity > 0
         THEN
            l_insertalarm := 1;
            l_new_firstoccurrence := :NEW.lastoccurrence;
            :NEW.tally := 1;
         END IF;
      ELSIF (trunc(:NEW.lastoccurrence,'hh') != trunc(:OLD.lastoccurrence,'hh')) THEN
            l_insertalarm := 1;
            l_new_firstoccurrence := :NEW.lastoccurrence;
            :NEW.tally := 1;
      END IF;
   END IF;

/*??????*/
   IF (l_insertalarm = 1)
   THEN
      num := INSTR (:NEW.node, '.', 1, 3);

      IF (num = 0)
      THEN
         isip := FALSE;
      ELSE
         BEGIN
            num := TO_NUMBER (REPLACE (:NEW.node, '.', '0'));
            isip := TRUE;
         EXCEPTION
            WHEN OTHERS
            THEN
               isip := FALSE;
         END;
      END IF;

/*??????????*/
/*????loopback????*/
      IF isip
      THEN
         BEGIN
            SELECT deviceid
              INTO l_resid
              FROM device a, node b
             WHERE a.loopaddress = :NEW.node
               AND a.changetype = 0
               AND a.nodecode = b.nodecode
               AND b.nodefullcode LIKE '%' || :NEW.servername || '%'
               AND ROWNUM = 1;
         EXCEPTION
            WHEN NO_DATA_FOUND
            THEN
               l_resid := NULL;
         END;

/*????,???????*/
         IF l_resid IS NULL
         THEN
            BEGIN
               SELECT hostid
                 INTO l_resid
                 FROM HOST a, node b
                WHERE a.ipaddress = :NEW.node
                  AND a.changetype = 0
                  AND a.nodecode = b.nodecode
                  AND b.nodefullcode LIKE '%' || :NEW.servername || '%'
                  AND ROWNUM = 1;
            EXCEPTION
               WHEN NO_DATA_FOUND
               THEN
                  l_resid := NULL;
            END;
         END IF;

/*?????,?????????*/
         IF l_resid IS NULL
         THEN
            BEGIN
               SELECT a.deviceid
                 INTO l_resid
                 FROM devaddr a, device b, node c
                WHERE a.ipaddress = :NEW.node
                  AND a.deviceid = b.deviceid
                  AND b.nodecode = c.nodecode
                  AND a.changetype = 0
                  AND b.changetype = 0
                  AND c.nodefullcode LIKE '%' || :NEW.servername || '%'
                  AND ROWNUM = 1;
            EXCEPTION
/*????,????*/
               WHEN NO_DATA_FOUND
               THEN
                  RETURN;
            END;
         END IF;
      ELSE
         BEGIN
            SELECT a.resid
              INTO l_resid
              FROM res a
             WHERE a.resid = :NEW.node AND ROWNUM = 1;
         EXCEPTION
/*????,????*/
            WHEN NO_DATA_FOUND
            THEN
               RETURN;
         END;
      END IF;

      /*??????*/
      IF :NEW.alertkey LIKE 'ifindex.%'
      THEN
         l_respara := SUBSTR (:NEW.alertkey, 9, LENGTH (:NEW.alertkey) - 8);

         BEGIN
            SELECT portdescr
              INTO l_respara
              FROM portinfo
             WHERE deviceid = l_resid AND portindex = l_respara AND ROWNUM = 1;
         EXCEPTION
            WHEN NO_DATA_FOUND
            THEN
               l_respara := :NEW.alertkey;
         END;
      ELSE
         l_respara := :NEW.alertkey;
      END IF;

/*?????????*/
      BEGIN
         SELECT alarmtypeid
           INTO l_alarmtypeid
           FROM alertgroupmap
          WHERE alertgroup = :NEW.alertgroup AND manager = :NEW.manager;
      EXCEPTION
         WHEN NO_DATA_FOUND
         THEN
            l_alarmtypeid := 'DS0000';
      END;

/*??????,??????????*/
      IF (l_alarmtypeid != 'DS0000')
      THEN
/*???????*/
         UPDATE    alarmsummary
               SET lastoccurtime = :NEW.lastoccurrence,
                   times = times + :NEW.tally,
                   summary =
                      SUBSTRB (   SUBSTR (summary,
                                          0,
                                          decode(INSTR (summary, '::::'),0,0,INSTR (summary, '::::') + 3)
                                         )
                               || :NEW.summary,
                               0,
                               255
                              ),
                   keyword = :NEW.keyword,
                   stoptime = NULL,
                   additionalinfo =
                      DECODE (:NEW.additionalinfo,
                              NULL, additionalinfo,
                              :NEW.additionalinfo
                             )
             WHERE resid = l_resid
               AND respara = NVL (l_respara, '-1')
               AND alarmtypeid = l_alarmtypeid
               AND ROWNUM = 1
         RETURNING sumalarmid
              INTO l_slviewserialid;

/*?????????,??????*/
         IF SQL%ROWCOUNT = 0
         THEN
/*???????*/
            INSERT INTO alarmsummary
                        (sumalarmid, alarmtypeid, resid,
                         respara, starttime,
                         lastoccurtime, times, getmethod,
                         alarmlevel, summary, ackstatus,
                         handlestatus, keyword, additionalinfo
                        )
                 VALUES (alarmsummaryseq.NEXTVAL, l_alarmtypeid, l_resid,
                         NVL (l_respara, '-1'), l_new_firstoccurrence,
                         :NEW.lastoccurrence, :NEW.tally, 'Syslog',
                         :NEW.severity, SUBSTRB (:NEW.summary, 0, 255), '0',
                         '1', :NEW.keyword, :NEW.additionalinfo
                        )
              RETURNING sumalarmid
                   INTO l_slviewserialid;
         END IF;
/*???????,?????????*/
      ELSE
         INSERT INTO alarmsummary
                     (sumalarmid, alarmtypeid, resid,
                      respara, starttime,
                      lastoccurtime, times, getmethod,
                      alarmlevel, summary, ackstatus,
                      handlestatus, keyword, additionalinfo
                     )
              VALUES (alarmsummaryseq.NEXTVAL, l_alarmtypeid, l_resid,
                      NVL (l_respara, '-1'), l_new_firstoccurrence,
                      :NEW.lastoccurrence, :NEW.tally, 'Syslog',
                      :NEW.severity, SUBSTRB (:NEW.summary, 0, 255), '0',
                      '1', :NEW.keyword, :NEW.additionalinfo
                     )
           RETURNING sumalarmid
                INTO l_slviewserialid;
      END IF;

/*????????*/
      :NEW.slviewserialid := l_slviewserialid;
   END IF;
END;
/
