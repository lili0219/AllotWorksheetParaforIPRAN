CREATE TRIGGER TRG_ENDPOINT
AFTER INSERT OR UPDATE OF ENDPOINTID, CHANGETYPE, DEVICEID, IPADDRESS OR DELETE
  ON ENDPOINT
FOR EACH ROW WHEN (FOR EACH ROW )
declare
    l_nodecode res.nodecodea%type;
    l_ipaddress res.ipaddressa%type;
begin
    /*?????????????IP?????????*/
    if (:new.changetype = 0) then
        /*?????????????*/
        if (:new.deviceid is not null) then
            begin
                select nodecode,loopaddress into l_nodecode,l_ipaddress
                from device
                where deviceid = :new.deviceid
                    and changetype = 0 ;
            exception
                when no_data_found then
                    l_nodecode := null;
                    l_ipaddress := null;
            end ;
        /*??????IP*/
        else
            l_nodecode := null;
            l_ipaddress := :new.ipaddress;
        end if;

        /*???????IP??*/
        /*A?*/
        update res
        set ipaddressa = l_ipaddress,
            nodecodea = l_nodecode
        where resid in (select a.pathid resid
                        from path a
                        where a.changetype = 0
                            and a.startpointid = :new.endpointid);

        /*B?*/
        update res
        set ipaddressb = l_ipaddress,
            nodecodeb = l_nodecode
        where resid in (select a.pathid resid
                        from path a
                        where a.changetype = 0
                            and a.endpointid = :new.endpointid);

    end if;

    /*????????????????????????????IP??;*/
    if ((updating and :new.changetype = 0 and :old.changetype=0 and :new.endpointid != :old.endpointid)
        or deleting or (updating and :new.changetype != 0 and :old.changetype=0))  then
        /*A?*/
        update res
        set ipaddressa = null,
            nodecodea = null
        where resid in (select a.pathid resid
                        from path a
                        where a.changetype = 0
                            and a.startpointid = :old.endpointid);

        /*B?*/
        update res
        set ipaddressb = null,
            nodecodeb = null
        where resid in (select a.pathid resid
                        from path a
                        where a.changetype = 0
                            and a.endpointid = :old.endpointid);
    end if;

end ;
/
