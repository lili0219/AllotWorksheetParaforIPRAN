CREATE TRIGGER TRG_PATH_RELA
AFTER INSERT OR UPDATE OF CHANGETYPE, PATHNAME, STARTPOINTID, ENDPOINTID OR DELETE
  ON PATH
FOR EACH ROW
  DECLARE
    l_adeviceid ENDPOINT.DEVICEID%TYPE;
    l_bdeviceid ENDPOINT.DEVICEID%TYPE;
BEGIN
    /*????????????????*/
    IF (:NEW.changetype = 0) THEN
        /*??????start???id*/
        BEGIN
            SELECT deviceid INTO l_adeviceid
            FROM ENDPOINT
            WHERE ENDPOINTID = :NEW.StartPointID AND changetype = 0 ;
        EXCEPTION
            WHEN NO_DATA_FOUND THEN
                l_adeviceid := NULL;
        END;
        /*?????end???id*/
        BEGIN
            SELECT deviceid INTO l_bdeviceid
            FROM ENDPOINT
            WHERE ENDPOINTID = :NEW.EndPointID AND changetype = 0 ;
        EXCEPTION
            WHEN NO_DATA_FOUND THEN
                l_bdeviceid := NULL;
        END;
    END IF;

    /*?????? ??changetype=1 2 3???*/
    IF (INSERTING AND :NEW.changetype=0) THEN
        /*????*/
        BEGIN
        IF (l_adeviceid IS NOT NULL) THEN
            INSERT INTO RESRELATION (ARESID, ARESPARA, ARESCLASSID,BRESID, BRESPARA, BRESNAME,BRESCLASSNAME, RELATYPE)
            VALUES ( l_adeviceid, '-1','DEV' , :NEW.PathID, '-1', :NEW.PathName,'??' , 'REFERED');
        END IF;
        IF (l_bdeviceid IS NOT NULL) THEN
            INSERT INTO RESRELATION (ARESID, ARESPARA, ARESCLASSID,BRESID, BRESPARA, BRESNAME,BRESCLASSNAME, RELATYPE)
            VALUES ( l_bdeviceid, '-1','DEV' , :NEW.PathID, '-1', :NEW.PathName,'??' , 'REFERED');
        END IF;
        EXCEPTION
            WHEN OTHERS THEN
                UPDATE RESRELATION
                SET BRESNAME = :NEW.PathName
                WHERE BResID=:OLD.PathID;
        END ;
    /*??????*/
    ELSIF (DELETING OR (UPDATING AND :NEW.changetype = -1 AND :OLD.changetype=0)) THEN
      BEGIN
        DELETE FROM RESRELATION WHERE BResID=:OLD.PathID;
      END;
     /*??????*/
     ELSIF (UPDATING AND :NEW.changetype = 0 AND :OLD.changetype = 0) THEN
        BEGIN
          /*??????*/
          DELETE FROM RESRELATION WHERE BResID=:OLD.PathID;
        /*????*/
        IF (l_adeviceid IS NOT NULL) THEN
            INSERT INTO RESRELATION (ARESID, ARESPARA, ARESCLASSID,BRESID, BRESPARA, BRESNAME,BRESCLASSNAME, RELATYPE)
            VALUES ( l_adeviceid, '-1','DEV' , :NEW.PathID, '-1', :NEW.PathName,'??' , 'REFERED');
        END IF;
        IF (l_bdeviceid IS NOT NULL) THEN
            INSERT INTO RESRELATION (ARESID, ARESPARA, ARESCLASSID,BRESID, BRESPARA, BRESNAME,BRESCLASSNAME, RELATYPE)
            VALUES ( l_bdeviceid, '-1','DEV' , :NEW.PathID, '-1', :NEW.PathName,'??' , 'REFERED');
        END IF;
        EXCEPTION
            WHEN OTHERS THEN
                UPDATE RESRELATION
                SET BRESNAME = :NEW.PathName
                WHERE BResID=:OLD.PathID;
        END ;
    END IF;
END ;
/
