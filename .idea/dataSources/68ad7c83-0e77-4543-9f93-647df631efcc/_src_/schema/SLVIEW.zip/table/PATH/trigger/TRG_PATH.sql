CREATE TRIGGER TRG_PATH
AFTER INSERT OR UPDATE OF PATHID, CHANGETYPE, PATHNAME, PATHTYPEID OR DELETE
  ON PATH
FOR EACH ROW WHEN (FOR EACH ROW )
DECLARE
   l_nodecodea    res.nodecodea%TYPE;
   l_nodecodeb    res.nodecodeb%TYPE;
   l_ipaddressa   res.ipaddressa%TYPE;
   l_ipaddressb   res.ipaddressb%TYPE;
   l_deviceid     endpoint.deviceid%TYPE;
BEGIN
   /*?????????????IP??*/
   IF (:NEW.changetype = 0)
   THEN
      /*??A????IP??*/
      BEGIN
         SELECT b.nodecode, b.loopaddress
           INTO l_nodecodea, l_ipaddressa
           FROM endpoint a, device b
          WHERE a.endpointid = :NEW.startpointid
            AND a.deviceid = b.deviceid
            AND a.changetype = 0
            AND b.changetype = 0;
      EXCEPTION
         WHEN NO_DATA_FOUND
         THEN
            l_nodecodea := NULL;
            l_ipaddressa := NULL;
      END;

      /*??B????IP??*/
      BEGIN
         SELECT deviceid, ipaddress
           INTO l_deviceid, l_ipaddressb
           FROM endpoint
          WHERE endpointid = :NEW.endpointid AND changetype = 0;
      EXCEPTION
         WHEN NO_DATA_FOUND
         THEN
            l_deviceid := NULL;
            l_ipaddressb := NULL;
      END;

      IF (l_deviceid IS NOT NULL)
      THEN
         BEGIN
            SELECT nodecode, loopaddress
              INTO l_nodecodeb, l_ipaddressb
              FROM device
             WHERE deviceid = l_deviceid AND changetype = 0;
         EXCEPTION
            WHEN NO_DATA_FOUND
            THEN
               l_nodecodeb := NULL;
               l_ipaddressb := NULL;
         END;
      ELSE
         l_nodecodeb := NULL;
      END IF;

      IF (:NEW.testtypecode = 'pingagent' or :NEW.testtypecode = 'tcpagent')
      THEN
         l_nodecodea := :NEW.nodecode;
         l_nodecodeb := NULL;
      END IF;
   END IF;

   /*??????*/
   IF (INSERTING OR (UPDATING AND :NEW.changetype = 0 AND :OLD.changetype != 0)
      )
   THEN
      BEGIN
         INSERT INTO res
                     (resid, resname, restypeid,
                      nodecodea, nodecodeb, ipaddressa, ipaddressb
                     )
              VALUES (:NEW.pathid, :NEW.pathname, :NEW.pathtypeid,
                      l_nodecodea, l_nodecodeb, l_ipaddressa, l_ipaddressb
                     );
      EXCEPTION
         WHEN OTHERS
         THEN
            UPDATE res
               SET resname = :NEW.pathname,
                   restypeid = :NEW.pathtypeid,
                   nodecodea = l_nodecodea,
                   nodecodeb = l_nodecodeb,
                   ipaddressa = l_ipaddressa,
                   ipaddressb = l_ipaddressb
             WHERE resid = :NEW.pathid;
      END;
   /*??????*/
   ELSIF (UPDATING AND :NEW.changetype = 0 AND :OLD.changetype = 0)
   THEN
      UPDATE res
         SET resid = :NEW.pathid,
             resname = :NEW.pathname,
             restypeid = :NEW.pathtypeid,
             nodecodea = l_nodecodea,
             nodecodeb = l_nodecodeb,
             ipaddressa = l_ipaddressa,
             ipaddressb = l_ipaddressb
       WHERE resid = :OLD.pathid;
   /*??????*/
   ELSIF (   DELETING
          OR (UPDATING AND :NEW.changetype != 0 AND :OLD.changetype = 0)
         )
   THEN
      DELETE      res
            WHERE resid = :OLD.pathid;
   END IF;
END;
/
