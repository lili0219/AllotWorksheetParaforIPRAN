CREATE TRIGGER TRG_SERVTASKLOGDETAIL
AFTER UPDATE OF EXECSTATUS
  ON SERVTASKLOGDETAILOLD
FOR EACH ROW
  declare
begin
  IF (:NEW.execstatus = 'F')
  THEN
    update worksheet set status='A'
    where wsnbr in
    (
      select w2.wsnbr from servtask s1,servtaskschedule sche1,worksheet w1,batchws b1,worksheet w2,servtask st2
      where s1.taskid=:NEW.taskid and st2.taskid=sche1.taskid and sche1.endtime >= sysdate + 5
        and s1.wsnbr=w1.wsnbr and w1.batchwsid=b1.batchwsid and b1.errflag=1
        and b1.batchwsid=w2.batchwsid and w2.wsnbr=st2.wsnbr
        and st2.tasktype='cfgdeploy'
        and st2.taskid not in (select taskid from servtasklog where exectime > sysdate - 5)
    );

    delete from servcfgtaskextratmp
    where taskid in
    (
      select st2.taskid from servtask s1,servtaskschedule sche1,worksheet w1,batchws b1,worksheet w2,servtask st2
      where s1.taskid=:NEW.taskid and st2.taskid=sche1.taskid and sche1.endtime >= sysdate + 5
        and s1.wsnbr=w1.wsnbr and w1.batchwsid=b1.batchwsid and b1.errflag=1
        and b1.batchwsid=w2.batchwsid and w2.wsnbr=st2.wsnbr
        and st2.tasktype='cfgdeploy'
        and st2.taskid not in (select taskid from servtasklog where exectime > sysdate - 5)
    );

    delete from servcfgtaskpara
    where taskid in
    (
      select st2.taskid from servtask s1,servtaskschedule sche1,worksheet w1,batchws b1,worksheet w2,servtask st2
      where s1.taskid=:NEW.taskid and st2.taskid=sche1.taskid and sche1.endtime >= sysdate + 5
        and s1.wsnbr=w1.wsnbr and w1.batchwsid=b1.batchwsid and b1.errflag=1
        and b1.batchwsid=w2.batchwsid and w2.wsnbr=st2.wsnbr
        and st2.tasktype='cfgdeploy'
        and st2.taskid not in (select taskid from servtasklog where exectime > sysdate - 5)
    );

    delete from servcfgtaskdetail
    where taskid in
    (
      select st2.taskid from servtask s1,servtaskschedule sche1,worksheet w1,batchws b1,worksheet w2,servtask st2
      where s1.taskid=:NEW.taskid and st2.taskid=sche1.taskid and sche1.endtime >= sysdate + 5
        and s1.wsnbr=w1.wsnbr and w1.batchwsid=b1.batchwsid and b1.errflag=1
        and b1.batchwsid=w2.batchwsid and w2.wsnbr=st2.wsnbr
        and st2.tasktype='cfgdeploy'
        and st2.taskid not in (select taskid from servtasklog where exectime > sysdate - 5)
    );

    delete from servtaskschedule
    where taskid in
    (
      select st2.taskid from servtask s1,servtaskschedule sche1,worksheet w1,batchws b1,worksheet w2,servtask st2
      where s1.taskid=:NEW.taskid and st2.taskid=sche1.taskid and sche1.endtime >= sysdate + 5
        and s1.wsnbr=w1.wsnbr and w1.batchwsid=b1.batchwsid and b1.errflag=1
        and b1.batchwsid=w2.batchwsid and w2.wsnbr=st2.wsnbr
        and st2.tasktype='cfgdeploy'
        and st2.taskid not in (select taskid from servtasklog where exectime > sysdate - 5)
    );

    delete from servtask where taskid in
    (
      select st2.taskid from servtask s1,servtaskschedule sche1,worksheet w1,batchws b1,worksheet w2,servtask st2
      where s1.taskid=:NEW.taskid and st2.taskid=sche1.taskid and sche1.endtime >= sysdate + 5
        and s1.wsnbr=w1.wsnbr and w1.batchwsid=b1.batchwsid and b1.errflag=1
        and b1.batchwsid=w2.batchwsid and w2.wsnbr=st2.wsnbr
        and st2.tasktype='cfgdeploy'
        and st2.taskid not in (select taskid from servtasklog where exectime > sysdate - 5)
    );
  END IF;

end TRG_SERVTASKLOGDETAIL;
/
