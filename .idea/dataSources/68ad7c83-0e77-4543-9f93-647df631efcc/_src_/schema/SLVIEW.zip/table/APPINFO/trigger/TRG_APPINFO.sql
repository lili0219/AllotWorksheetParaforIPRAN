CREATE TRIGGER TRG_APPINFO
AFTER INSERT OR UPDATE OF APPID, NODECODE, APPTYPEID, APPNAME, IPADDRESS, VALIDFLAG OR DELETE
  ON APPINFO
FOR EACH ROW WHEN (FOR EACH ROW )
DECLARE
   l_vendor   appsystype.vendor%TYPE;
BEGIN
   BEGIN
      SELECT vendor
        INTO l_vendor
        FROM appsystype
       WHERE appsystypeid = :NEW.appsystypeid;
   EXCEPTION
      WHEN OTHERS
      THEN
         NULL;
   END;

   /*??????*/
   IF (INSERTING OR (UPDATING AND :NEW.validflag = 0 AND :OLD.validflag != 0))
   THEN
      BEGIN
         INSERT INTO res
                     (resid, resname, restypeid,
                      nodecodea, nodecodeb, ipaddressa, ipaddressb,ResModelID, vendor
                     )
              VALUES (:NEW.appid, :NEW.appname, :NEW.apptypeid,
                      :NEW.nodecode, NULL, :NEW.ipaddress, NULL,:new.AppSysTypeID, l_vendor
                     );
      EXCEPTION
         WHEN OTHERS
         THEN
            UPDATE res
               SET resname = :NEW.appname,
                   restypeid = :NEW.apptypeid,
                   nodecodea = :NEW.nodecode,
                   nodecodeb = NULL,
                   ipaddressa = :NEW.ipaddress,
                   ipaddressb = NULL,
                   ResModelID=:new.AppSysTypeID,
                   vendor = l_vendor
             WHERE resid = :NEW.appid;
      END;

      /* ?noderesrela? */
      BEGIN
         INSERT INTO noderesrela
                     (nodecode, restype, resmodel)
            SELECT DISTINCT c.nodecode, :NEW.apptypeid,
                            NVL (:NEW.AppSysTypeID, 'N')
                       FROM node b, node c
                      WHERE b.nodecode = :NEW.nodecode
                        AND b.nodefullcode LIKE c.nodefullcode || '%'
                        AND c.nodecode NOT IN (
                               SELECT nodecode
                                 FROM noderesrela
                                WHERE restype = :NEW.apptypeid
                                  AND resmodel = NVL (:NEW.AppSysTypeID, 'N')) ;

      EXCEPTION
         WHEN OTHERS
         THEN
            NULL;
      END;

   /*??????*/
   ELSIF (UPDATING AND :NEW.validflag = 0 AND :OLD.validflag = 0)
   THEN
      UPDATE res
         SET resid = :NEW.appid,
             resname = :NEW.appname,
             restypeid = :NEW.apptypeid,
             nodecodea = :NEW.nodecode,
             nodecodeb = NULL,
             ipaddressa = :NEW.ipaddress,
             ipaddressb = NULL,
             ResModelID=:new.AppSysTypeID,
             vendor = l_vendor
       WHERE resid = :OLD.appid;
   /*??????*/
   ELSIF (DELETING OR (UPDATING AND :NEW.validflag != 0 AND :OLD.validflag = 0))
   THEN
      DELETE      res
            WHERE resid = :OLD.appid;
   END IF;
END;
/
