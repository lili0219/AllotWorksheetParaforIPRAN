CREATE TRIGGER TRG_HOST
AFTER INSERT OR UPDATE OF HOSTID, CHANGETYPE, HOSTNAME, HOSTTYPECODE, NODECODE, IPADDRESS, HOSTPROPCODE, OSVENDOR OR DELETE
  ON HOST
FOR EACH ROW WHEN (FOR EACH ROW )
BEGIN
   /*??????*/
   IF (INSERTING OR (UPDATING AND :NEW.changetype = 0 AND :OLD.changetype != 0)
      )
   THEN
      BEGIN
         INSERT INTO res
                     (resid, resname, restypeid,
                      nodecodea, nodecodeb, ipaddressa, ipaddressb,ResModelID,
                      vendor, resprop
                     )
              VALUES (:NEW.hostid, :NEW.hostname, :NEW.hosttypecode,
                      :NEW.nodecode, NULL, :NEW.ipaddress, NULL,:new.hosttypecode,
                      :NEW.osvendor, :NEW.hostpropcode
                     );
      EXCEPTION
         WHEN OTHERS
         THEN
            UPDATE res
               SET resname = :NEW.hostname,
                   restypeid = :NEW.hosttypecode,
                   nodecodea = :NEW.nodecode,
                   nodecodeb = NULL,
                   ipaddressa = :NEW.ipaddress,
                   ipaddressb = NULL,
                   ResModelID = :new.hosttypecode,
                   vendor = :NEW.osvendor,
                   resprop = :NEW.hostpropcode
             WHERE resid = :NEW.hostid;
      END;
   /*??????*/
   ELSIF (UPDATING AND :NEW.changetype = 0 AND :OLD.changetype = 0)
   THEN
      UPDATE res
         SET resid = :NEW.hostid,
             resname = :NEW.hostname,
             restypeid = :NEW.hosttypecode,
             nodecodea = :NEW.nodecode,
             nodecodeb = NULL,
             ipaddressa = :NEW.ipaddress,
             ipaddressb = NULL,
             ResModelID = :new.hosttypecode,
             vendor = :NEW.osvendor,
             resprop = :NEW.hostpropcode
       WHERE resid = :OLD.hostid;
   /*??????*/
   ELSIF (   DELETING
          OR (UPDATING AND :NEW.changetype != 0 AND :OLD.changetype = 0)
         )
   THEN
      DELETE      res
            WHERE resid = :OLD.hostid;
   END IF;
END;
/
