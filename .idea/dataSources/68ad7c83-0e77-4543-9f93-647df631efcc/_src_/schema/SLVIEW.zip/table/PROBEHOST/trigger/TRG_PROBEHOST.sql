CREATE TRIGGER TRG_PROBEHOST
AFTER INSERT OR UPDATE OF PROBEID OR DELETE
  ON PROBEHOST
FOR EACH ROW
  DECLARE
   PRAGMA AUTONOMOUS_TRANSACTION;
   l_exist    NUMBER;
   sql_stmt   VARCHAR2 (200);
BEGIN
   BEGIN
      SELECT 1
        INTO l_exist
        FROM user_tab_partitions
       WHERE table_name = 'RESCURINFO'
             AND partition_name = 'P_' || :OLD.probeid;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         l_exist := 0;
   END;

   IF (l_exist = 1 AND :OLD.probeid <> 'PRS00000')
   THEN
      sql_stmt := 'alter table RESCURINFO drop partition P_' || :OLD.probeid;

      EXECUTE IMMEDIATE sql_stmt;
   END IF;

   IF (:NEW.probeid IS NOT NULL)
   THEN
      BEGIN
         SELECT 1
           INTO l_exist
           FROM user_tab_partitions
          WHERE table_name = 'RESCURINFO'
            AND partition_name = 'P_' || :NEW.probeid;
      EXCEPTION
         WHEN NO_DATA_FOUND
         THEN
            l_exist := 0;
      END;

      IF (l_exist = 0)
      THEN
         sql_stmt :=
               'alter table RESCURINFO add partition P_'
            || :NEW.probeid
            || ' values ('''
            || :NEW.probeid
            || ''')';

         EXECUTE IMMEDIATE sql_stmt;
      END IF;
   END IF;
END;
/
