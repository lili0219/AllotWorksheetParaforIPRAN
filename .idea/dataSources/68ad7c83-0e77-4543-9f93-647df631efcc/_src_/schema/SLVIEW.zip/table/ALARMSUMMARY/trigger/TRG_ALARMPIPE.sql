CREATE TRIGGER TRG_ALARMPIPE
AFTER INSERT OR UPDATE OR DELETE
  ON ALARMSUMMARY
FOR EACH ROW
  DECLARE
   l_username   VARCHAR2 (30);
   l_pipename   VARCHAR2 (40);
   l_result     PLS_INTEGER;
BEGIN
   -- ?????
   SELECT username
     INTO l_username
     FROM user_users;

   --??????PIPE??
   l_pipename := 'ALARM_' || l_username;
   DBMS_PIPE.reset_buffer;

   -- ????
   IF DELETING OR ((UPDATING OR INSERTING) AND :NEW.stoptime IS NOT NULL)
   THEN
      DBMS_PIPE.pack_message ('delete');
   ELSIF INSERTING
   THEN
      DBMS_PIPE.pack_message ('add');
   ELSE
      DBMS_PIPE.pack_message ('modify');
   END IF;

   -- ??????
   IF DELETING OR ((UPDATING OR INSERTING) AND :NEW.stoptime IS NOT NULL)
   THEN
      DBMS_PIPE.pack_message (TO_CHAR (:OLD.sumalarmid));
      DBMS_PIPE.pack_message (:OLD.alarmtypeid);
      DBMS_PIPE.pack_message (:OLD.resid);
      DBMS_PIPE.pack_message (:OLD.respara);
      DBMS_PIPE.pack_message (TO_CHAR (:OLD.starttime,
                                       'yyyy-mm-dd hh24:mi:ss')
                             );
      DBMS_PIPE.pack_message (TO_CHAR (:OLD.lastoccurtime,
                                       'yyyy-mm-dd hh24:mi:ss'
                                      )
                             );
      DBMS_PIPE.pack_message (TO_CHAR (:OLD.times));
      DBMS_PIPE.pack_message (TO_CHAR (:OLD.alarmlevel));
      DBMS_PIPE.pack_message (:OLD.summary);
      DBMS_PIPE.pack_message (:OLD.ensummary);
      DBMS_PIPE.pack_message (:OLD.ackstatus);
      DBMS_PIPE.pack_message (TO_CHAR (:OLD.acktime, 'yyyy-mm-dd hh24:mi:ss'));
      DBMS_PIPE.pack_message (:OLD.ackuserid);
      DBMS_PIPE.pack_message (TO_CHAR (:OLD.engiid));
      DBMS_PIPE.pack_message (TO_CHAR (:OLD.stoptime, 'yyyy-mm-dd hh24:mi:ss'));
      DBMS_PIPE.pack_message (:OLD.additionalinfo);
   ELSE
      DBMS_PIPE.pack_message (TO_CHAR (:NEW.sumalarmid));
      DBMS_PIPE.pack_message (:NEW.alarmtypeid);
      DBMS_PIPE.pack_message (:NEW.resid);
      DBMS_PIPE.pack_message (:NEW.respara);
      DBMS_PIPE.pack_message (TO_CHAR (:NEW.starttime,
                                       'yyyy-mm-dd hh24:mi:ss')
                             );
      DBMS_PIPE.pack_message (TO_CHAR (:NEW.lastoccurtime,
                                       'yyyy-mm-dd hh24:mi:ss'
                                      )
                             );
      DBMS_PIPE.pack_message (TO_CHAR (:NEW.times));
      DBMS_PIPE.pack_message (TO_CHAR (:NEW.alarmlevel));
      DBMS_PIPE.pack_message (:NEW.summary);
      DBMS_PIPE.pack_message (:NEW.ensummary);
      DBMS_PIPE.pack_message (:NEW.ackstatus);
      DBMS_PIPE.pack_message (TO_CHAR (:NEW.acktime, 'yyyy-mm-dd hh24:mi:ss'));
      DBMS_PIPE.pack_message (:NEW.ackuserid);
      DBMS_PIPE.pack_message (TO_CHAR (:NEW.engiid));
      DBMS_PIPE.pack_message (TO_CHAR (:NEW.stoptime, 'yyyy-mm-dd hh24:mi:ss'));
      DBMS_PIPE.pack_message (:NEW.additionalinfo);
   END IF;

   -- ????
   l_result := DBMS_PIPE.send_message (l_pipename, 0, 4096000);

   -- ?????????PIPE
   IF (l_result = 1)
   THEN
      DBMS_PIPE.PURGE (l_pipename);
   END IF;

--??????PIPE??
   l_pipename := 'RESALARM_' || l_username;
   DBMS_PIPE.reset_buffer;

   -- ????
   IF INSERTING
   THEN
      DBMS_PIPE.pack_message ('add');
   ELSIF UPDATING
   THEN
      DBMS_PIPE.pack_message ('modify');
   ELSE
      DBMS_PIPE.pack_message ('delete');
   END IF;

   -- ??????
   IF DELETING
   THEN
      DBMS_PIPE.pack_message (TO_CHAR (:OLD.sumalarmid));
      DBMS_PIPE.pack_message (:OLD.alarmtypeid);
      DBMS_PIPE.pack_message (:OLD.resid);
      DBMS_PIPE.pack_message (:OLD.respara);
      DBMS_PIPE.pack_message (TO_CHAR (:OLD.starttime,
                                       'yyyy-mm-dd hh24:mi:ss')
                             );
      DBMS_PIPE.pack_message (TO_CHAR (:OLD.lastoccurtime,
                                       'yyyy-mm-dd hh24:mi:ss'
                                      )
                             );
      DBMS_PIPE.pack_message (TO_CHAR (:OLD.times));
      DBMS_PIPE.pack_message (TO_CHAR (:OLD.alarmlevel));
      DBMS_PIPE.pack_message (:OLD.summary);
      DBMS_PIPE.pack_message (:OLD.ensummary);
      DBMS_PIPE.pack_message (:OLD.ackstatus);
      DBMS_PIPE.pack_message (:OLD.ackuserid);
      DBMS_PIPE.pack_message (TO_CHAR (:OLD.acktime, 'yyyy-mm-dd hh24:mi:ss'));
      DBMS_PIPE.pack_message (:OLD.handlestatus);
      DBMS_PIPE.pack_message (:OLD.transfaultuserid);
      DBMS_PIPE.pack_message (TO_CHAR (:OLD.transfaulttime,
                                       'yyyy-mm-dd hh24:mi:ss'
                                      )
                             );
      DBMS_PIPE.pack_message (TO_CHAR (:OLD.engiid));
      DBMS_PIPE.pack_message (:OLD.getmethod);
      DBMS_PIPE.pack_message (:OLD.keyword);
      DBMS_PIPE.pack_message (TO_CHAR (:OLD.stoptime, 'yyyy-mm-dd hh24:mi:ss'));
      DBMS_PIPE.pack_message (:OLD.additionalinfo);
      DBMS_PIPE.pack_message (:OLD.alarmmemo);
   ELSE
      DBMS_PIPE.pack_message (TO_CHAR (:NEW.sumalarmid));
      DBMS_PIPE.pack_message (:NEW.alarmtypeid);
      DBMS_PIPE.pack_message (:NEW.resid);
      DBMS_PIPE.pack_message (:NEW.respara);
      DBMS_PIPE.pack_message (TO_CHAR (:NEW.starttime,
                                       'yyyy-mm-dd hh24:mi:ss')
                             );
      DBMS_PIPE.pack_message (TO_CHAR (:NEW.lastoccurtime,
                                       'yyyy-mm-dd hh24:mi:ss'
                                      )
                             );
      DBMS_PIPE.pack_message (TO_CHAR (:NEW.times));
      DBMS_PIPE.pack_message (TO_CHAR (:NEW.alarmlevel));
      DBMS_PIPE.pack_message (:NEW.summary);
      DBMS_PIPE.pack_message (:NEW.ensummary);
      DBMS_PIPE.pack_message (:NEW.ackstatus);
      DBMS_PIPE.pack_message (:NEW.ackuserid);
      DBMS_PIPE.pack_message (TO_CHAR (:NEW.acktime, 'yyyy-mm-dd hh24:mi:ss'));
      DBMS_PIPE.pack_message (:NEW.handlestatus);
      DBMS_PIPE.pack_message (:NEW.transfaultuserid);
      DBMS_PIPE.pack_message (TO_CHAR (:NEW.transfaulttime,
                                       'yyyy-mm-dd hh24:mi:ss'
                                      )
                             );
      DBMS_PIPE.pack_message (TO_CHAR (:NEW.engiid));
      DBMS_PIPE.pack_message (:NEW.getmethod);
      DBMS_PIPE.pack_message (:NEW.keyword);
      DBMS_PIPE.pack_message (TO_CHAR (:NEW.stoptime, 'yyyy-mm-dd hh24:mi:ss'));
      DBMS_PIPE.pack_message (:NEW.additionalinfo);
      DBMS_PIPE.pack_message (:NEW.alarmmemo);
   END IF;

   -- ????
   l_result := DBMS_PIPE.send_message (l_pipename, 0, 4096000);

   -- ?????????PIPE
   IF (l_result = 1)
   THEN
      DBMS_PIPE.PURGE (l_pipename);
   END IF;
EXCEPTION
   WHEN OTHERS
   THEN
      NULL;
END;
/
