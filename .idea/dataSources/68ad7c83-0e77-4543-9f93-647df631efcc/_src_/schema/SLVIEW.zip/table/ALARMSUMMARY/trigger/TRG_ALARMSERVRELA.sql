CREATE TRIGGER TRG_ALARMSERVRELA
AFTER INSERT OR DELETE
  ON ALARMSUMMARY
FOR EACH ROW
  declare
    l_pipename varchar2(40) ;
    l_result pls_integer ;

begin
    -- ???????PIPE??
    select 'AL_REF_SERV_'||username into l_pipename from user_users ;

    dbms_pipe.reset_buffer ;
    -- ????
    if inserting then
        dbms_pipe.pack_message('add') ;
    elsif updating then
        dbms_pipe.pack_message('modify') ;
    else
        dbms_pipe.pack_message('delete') ;
    end if;

    -- ??????
    if deleting then
        dbms_pipe.pack_message(to_char(:old.sumalarmid));
        dbms_pipe.pack_message(:old.alarmtypeid);
        dbms_pipe.pack_message(:old.resid);
        dbms_pipe.pack_message(:old.respara);
        dbms_pipe.pack_message(to_char(:old.starttime,'yyyymmddhh24miss'));
        dbms_pipe.pack_message(to_char(:old.lastoccurtime,'yyyymmddhh24miss'));
        dbms_pipe.pack_message(to_char(:old.times));
        dbms_pipe.pack_message(to_char(:old.alarmlevel));
        dbms_pipe.pack_message(:old.summary);
        dbms_pipe.pack_message(:old.ensummary);
         dbms_pipe.pack_message(to_char(:old.engiid));
    else
        dbms_pipe.pack_message(to_char(:new.sumalarmid));
        dbms_pipe.pack_message(:new.alarmtypeid);
        dbms_pipe.pack_message(:new.resid);
        dbms_pipe.pack_message(:new.respara);
        dbms_pipe.pack_message(to_char(:new.starttime,'yyyymmddhh24miss'));
        dbms_pipe.pack_message(to_char(:new.lastoccurtime,'yyyymmddhh24miss'));
        dbms_pipe.pack_message(to_char(:new.times));
        dbms_pipe.pack_message(to_char(:new.alarmlevel));
        dbms_pipe.pack_message(:new.summary);
        dbms_pipe.pack_message(:new.ensummary);
         dbms_pipe.pack_message(to_char(:new.engiid));
    end if;

    -- ????
    l_result := dbms_pipe.send_message(l_pipename,0,4096000) ;

    -- ?????????PIPE
    if (l_result = 1) then
        dbms_pipe.purge(l_pipename) ;
    end if;

exception
    when others then
        null ;
end ;
/
