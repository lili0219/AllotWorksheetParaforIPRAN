CREATE TRIGGER TRG_A1_ENGI
BEFORE INSERT
  ON ALARMSUMMARY
FOR EACH ROW
  DECLARE
TYPE engcur IS REF CURSOR;

l_engcur engcur;
l_engiid engiinfo.engiid%TYPE;
l_respara engirefres.respara%TYPE;
l_alarmtypemask engityperesgroup.alarmtypemask%TYPE;
l_alarmlevelset engityperesgroup.alarmlevelset%TYPE;
l_timeseg engiinfo.timeseg%TYPE;
l_timesegs VARCHAR (20);
l_timesege VARCHAR (20);
l_timesegtemp VARCHAR (40);
l_alarmstarttime VARCHAR (20);
pos NUMBER;
pos2 NUMBER;
l_match BOOLEAN;
paratemp VARCHAR (40);
BEGIN
	:NEW.engiid := 0;

	OPEN l_engcur FOR
	SELECT ei.engiid, er.respara, eg.alarmtypemask, eg.alarmlevelset,
	ei.timeseg
	FROM engityperesgroup eg, engirefres er, engiinfo ei
	WHERE :NEW.starttime >= ei.starttime
	AND :NEW.starttime <= ei.endtime
	AND ei.engiid = er.engiid
	AND er.resid = :NEW.resid
	AND ei.engiid = er.engiid
	AND eg.resgroupid = er.resgroupid
	AND eg.engitypeid = ei.engitypeid;

	LOOP
		FETCH l_engcur
		INTO l_engiid, l_respara, l_alarmtypemask, l_alarmlevelset, l_timeseg;

		EXIT WHEN l_engcur%NOTFOUND;

		-- ??????????
		IF ( l_alarmtypemask = 'ALL' OR INSTR (l_alarmtypemask, :NEW.alarmtypeid, 1, 1) > 0	) then
			l_match := true ;
		else
			l_match := false ;
		end if ;

		--???????????????????????????
		IF (l_match and l_timeseg IS NOT NULL)
		THEN
			l_match := FALSE;
			l_alarmstarttime := TO_CHAR (:NEW.starttime, 'hh24mi');

			LOOP
				pos := INSTR (l_timeseg, ',');

				IF pos <> 0
				THEN
					l_timesegtemp := SUBSTR (l_timeseg, 0, pos - 1);
					l_timeseg := SUBSTR (l_timeseg, pos + 1, LENGTH (l_timeseg));
				ELSE
					l_timesegtemp := l_timeseg;
				END IF;

				pos2 := INSTR (l_timesegtemp, '_');

				IF (pos2 <> 0)
				THEN
					l_timesegs := SUBSTR (l_timesegtemp, 0, pos2 - 1);
					l_timesege := SUBSTR (l_timesegtemp, pos2 + 1, LENGTH (l_timesegtemp));

					IF (l_timesegs <= l_timesege)
					THEN
						IF ( l_alarmstarttime >= l_timesegs	AND l_alarmstarttime <= l_timesege	)
						THEN
							l_match := TRUE;
						END IF;
					ELSE
						IF ( l_alarmstarttime >= l_timesegs	OR l_alarmstarttime <= l_timesege)
						THEN
							l_match := TRUE;
						END IF;
					END IF;
				END IF;

				EXIT WHEN pos = 0 OR l_match;
			END LOOP;
		END IF;

		-- ??????????
		IF (l_match )	THEN

			l_match := false ;

			-- ???????
			IF (l_respara like 'REGEXP:%' ) THEN
				l_respara := substr(l_respara,8) ;
				if regexp_instr(:NEW.respara,l_respara)>0 then
					l_match := true ;
				end if ;
			-- ????????
			ELSE
				LOOP
					pos := INSTR (l_respara, '|', 1, 1);

					IF (pos = 0)
					THEN
						paratemp := l_respara;
					ELSE
						paratemp := SUBSTR (l_respara, 0, pos - 1);
						l_respara := SUBSTR (l_respara, pos + 1, LENGTH (l_respara));
					END IF;

					paratemp := REPLACE (paratemp, '*', '%');

					--dbms_output.put_line('paratemp is:'||paratemp);
					--dbms_output.put_line('NEW.respara:'||:NEW.respara);
					IF UPPER (:NEW.respara) LIKE UPPER (paratemp)
					THEN
						l_match := true ;
						exit;
					END IF ;

					EXIT WHEN pos = 0;
				END LOOP;
			END IF ;
		END IF;

		--???????,??????????????
		IF ( l_match)
		THEN
			:NEW.engiid := l_engiid;

			IF (l_alarmlevelset IS NOT NULL)
			THEN
				:NEW.alarmlevel := l_alarmlevelset;
			END IF;

			RETURN;
		END IF;
	END LOOP;

	CLOSE l_engcur;

EXCEPTION
	WHEN OTHERS	THEN
		NULL;
END;
/
