CREATE TRIGGER TRG_ALARM_CHANGEMSG
AFTER UPDATE OF LASTOCCURTIME, TIMES, SUMMARY, FATHERALARMID, STOPTIME, ADDITIONALINFO
  ON ALARMSUMMARY
FOR EACH ROW
  DECLARE
  L_changeFlag number(1);
  l_lastocctime Date;
  l_times alarmsummary.times%TYPE;
  l_summary alarmsummary.summary%TYPE;
  l_stoptime alarmsummary.stoptime%TYPE;
  l_additionalinfo alarmsummary.additionalinfo%TYPE;
  l_FatherAlarmID alarmsummary.FatherAlarmID%TYPE;
BEGIN
  L_changeFlag := 0;

  --lastoccurtime
  IF nvl(:OLD.lastoccurtime, sysdate + 1) <> nvl(:NEW.lastoccurtime, sysdate + 1) THEN
     L_changeFlag := 1;
     l_lastoccurtime = :NEW.lastoccurtime;
  END;

  --times
  IF nvl(:OLD.times, 0) <> nvl(:NEW.times, 0) THEN
     L_changeFlag := 1;
     l_times = :NEW.times;
  END;

  --summary
  IF nvl(:OLD.summary, '') <> nvl(:NEW.summary, '') THEN
     L_changeFlag := 1;
     l_summary = :NEW.summary;
  END;

  --STOPTIME
  IF nvl(:OLD.STOPTIME, sysdate + 1) <> nvl(:NEW.STOPTIME, sysdate + 1) THEN
     L_changeFlag := 1;
     l_stoptime = :NEW.STOPTIME;
  END;

  --additionalinfo
  IF nvl(:OLD.additionalinfo, '') <> nvl(:NEW.additionalinfo, '') THEN
     L_changeFlag := 1;
     l_additionalinfo = :NEW.additionalinfo;
  END;

  --FatherAlarmID
  IF nvl(:OLD.FatherAlarmID, '') <> nvl(:NEW.FatherAlarmID, '') THEN
     L_changeFlag := 1;
     l_FatherAlarmID = :NEW.FatherAlarmID;
  END;

  IF (L_changeFlag = 1) THEN
    INSERT INTO AlarmTransChangeMsgQueue
      (SUMALARMID,
       lastoccurtime,
       times,
       summary,
       stoptime,
       additionalinfo,
       FatherAlarmID)
    VALUES
      (:NEW.SUMALARMID,
       l_lastocctime,
       l_summary,
       l_stoptime,
       l_additionalinfo,
       l_FatherAlarmID);
  END IF;
END;
/
