CREATE TRIGGER TRG_USERINFO
AFTER INSERT OR UPDATE OR DELETE
  ON USERINFO
FOR EACH ROW
  declare
  v_changetime date;
begin
  v_changetime := sysdate;

  ---?????????????????
  if deleting then
    delete userpasshis where netuserid = :old.netuserid;
  elsif inserting or (updating and :new.userpass <> :old.userpass) then
    ---???????????????????
    ---????????????????????
    insert into userpasshis
      (netuserid, changetime, userpass, userdespass,Modifier)
    values
      (:new.netuserid, sysdate, :new.userpass, :new.userdespass,:new.Modifier);

  end if;

end;
/
