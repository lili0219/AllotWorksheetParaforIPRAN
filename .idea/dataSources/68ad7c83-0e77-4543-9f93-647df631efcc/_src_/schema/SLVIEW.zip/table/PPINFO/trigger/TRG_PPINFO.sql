CREATE TRIGGER TRG_PPINFO
AFTER INSERT OR UPDATE OR DELETE
  ON PPINFO
FOR EACH ROW WHEN (FOR EACH ROW )
DECLARE
   l_fullipaddress   portinfo.fullipaddress%TYPE;
   l_ipaddress       portinfo.ipaddress%TYPE;
   l_netmask         portinfo.netmask%TYPE;
BEGIN
   IF (:OLD.changetype = 0)
   THEN
      DELETE FROM portinfo
            WHERE deviceid = :OLD.deviceid
              AND portdescr = :OLD.ppdescr
              AND portclass = 'P';
   END IF;

   IF (:NEW.changetype = 0)
   THEN
      BEGIN
         SELECT ipaddress, netmask
           INTO l_ipaddress, l_netmask
           FROM (SELECT *
                   FROM devaddr
                  WHERE changetype = 0 AND seqnum = 0) addr
          WHERE :NEW.deviceid = addr.deviceid(+) AND :NEW.ppdescr = addr.intdescr(+);
      EXCEPTION
         WHEN OTHERS
         THEN
            l_ipaddress := NULL;
            l_netmask := NULL;
            l_fullipaddress := NULL;
      END;

      IF (l_ipaddress IS NOT NULL)
      THEN
         l_fullipaddress := to_fullip (l_ipaddress);
      END IF;

      BEGIN
         INSERT INTO portinfo
                     (deviceid, portdescr, portclass, porttype,
                      portindex, portspeed, vpi, vci, dlci,
                      adminstatus, operstatus,
                      portdescrdetail, portmode, distance,
                      ppdescr, ipaddress, netmask, fullipaddress,
                      ifspeed
                     )
              VALUES (:NEW.deviceid, :NEW.ppdescr, 'P', :NEW.pptype,
                      :NEW.ppindex, :NEW.ppspeed, -1, -1, -1,
                      :NEW.adminstatus, :NEW.operstatus,
                      :NEW.portdescrdetail, :NEW.portmode, :NEW.distance,
                      :NEW.ppdescr, l_ipaddress, l_netmask, l_fullipaddress,
                      :NEW.ifspeed
                     );
      EXCEPTION
         WHEN OTHERS
         THEN
            UPDATE portinfo
               SET porttype = :NEW.pptype,
                   portindex = :NEW.ppindex,
                   portspeed = :NEW.ppspeed,
                   vpi = -1,
                   vci = -1,
                   dlci = -1,
                   adminstatus = :NEW.adminstatus,
                   operstatus = :NEW.operstatus,
                   portdescrdetail = :NEW.portdescrdetail,
                   portmode = :NEW.portmode,
                   distance = :NEW.distance,
                   ppdescr = :NEW.ppdescr,
                   ipaddress = l_ipaddress,
                   netmask = l_netmask,
                   fullipaddress = l_fullipaddress,
                   ifspeed = :NEW.ifspeed
             WHERE deviceid = :NEW.deviceid
               AND portdescr = :NEW.ppdescr
               AND portclass = 'P';
      END;
   END IF;
END;
/
