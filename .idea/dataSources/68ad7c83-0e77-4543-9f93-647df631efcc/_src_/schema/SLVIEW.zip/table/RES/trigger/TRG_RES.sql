CREATE TRIGGER TRG_RES
AFTER INSERT OR UPDATE OF RESID, RESTYPEID, NODECODEA, NODECODEB, RESPROP, VENDOR OR DELETE
  ON RES
FOR EACH ROW
  DECLARE
   l_resclassid   VARCHAR2 (20);
   l_changetype number(1);
   l_changeversion number(20) ;
   l_resid 		CHAR(8) ;
BEGIN

   l_changetype := 0 ;
   IF INSERTING THEN
   		l_changetype := 1 ;
   		l_resid := :new.resid ;
   ELSIF DELETING THEN
   		l_changetype := -1 ;
   		l_resid := :old.resid ;
   ELSIF (nvl(:new.nodecodea,'NULL')<>nvl(:old.nodecodea,'NULL') or nvl(:new.nodecodeb,'NULL')<>nvl(:old.nodecodeb,'NULL')
   		  or nvl(:new.resprop,'NULL')<>nvl(:old.resprop,'NULL') or nvl(:new.vendor,'NULL')<>nvl(:old.vendor,'NULL')
   		  or nvl(:new.restypeid,'NULL')<>nvl(:old.restypeid,'NULL')) THEN
   		l_changetype := 2 ;
   		l_resid := :new.resid ;
   END IF ;

   IF (l_changetype <> 0) THEN
	    l_resclassid := substr(l_resid,1,3) ;

	   	UPDATE resupdate
	      SET updatetime = SYSDATE,
	      	  changeversion = nvl(changeversion,0)+1
	    WHERE resclassid = l_resclassid
   		returning changeversion into l_changeversion;

	   	IF SQL%ROWCOUNT = 0
	   	THEN
	    	INSERT INTO resupdate(resclassid, updatetime,changeversion)
	      	VALUES (l_resclassid, SYSDATE ,1)
	   		returning changeversion into l_changeversion;
	   	END IF;

   		insert into resupdatelog (changeversion,changetime,resid,changetype,resclassid)
   		values (l_changeversion,sysdate,l_resid,l_changetype,l_resclassid) ;

	END IF ;

EXCEPTION
   WHEN OTHERS
   THEN
      NULL;
END;
/
