CREATE TRIGGER TRG_SWPORTDETAIL
AFTER INSERT OR UPDATE OR DELETE
  ON SWPORTDETAIL
FOR EACH ROW
  declare
    v_portid  swportdetail.port_id%type;
    v_apnrate swportdetail.apnrate%type;
begin
    if inserting or updating then
        v_portid := :new.port_id;

        merge  into swportdetail_tmp t
        using  (select :new.port_id port_id, :new.apnname apnname from dual) s
        on     (t.port_id = s.port_id and t.apnname = s.apnname)
        when   matched then
        update
        set    t.apnrate = :new.apnrate
        when   not matched then
        insert (port_id, apnname, apnrate)
        values (s.port_id, s.apnname, :new.apnrate);
    elsif deleting then
        v_portid := :old.port_id;

        delete from swportdetail_tmp where port_id = :old.port_id and apnname = :old.apnname;
    end if;

    begin
        select sum(nvl(apnrate, 0)) into v_apnrate from swportdetail_tmp where port_id = v_portid;
    exception when no_data_found then
        v_apnrate := 0;
    end;

    update resportinfo
    set    portratio = to_char(round(100 * v_apnrate / port_rate, 2))
    where  port_id = v_portid;
exception when others then
    null;
end trg_swportdetail;
/
