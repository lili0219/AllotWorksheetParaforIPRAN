CREATE TRIGGER TRG_NEWSERVALARM
BEFORE INSERT OR DELETE
  ON SERVALARMSUMMARY
FOR EACH ROW
  BEGIN
    if inserting then
        dbms_alert.signal('NEWSERVALARM','New ServAlarm is coming.');
    end if ;
END;
/
