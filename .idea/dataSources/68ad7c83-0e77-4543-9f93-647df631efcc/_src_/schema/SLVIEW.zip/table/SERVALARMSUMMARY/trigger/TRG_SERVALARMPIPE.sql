CREATE TRIGGER TRG_SERVALARMPIPE
AFTER INSERT OR UPDATE OR DELETE
  ON SERVALARMSUMMARY
FOR EACH ROW
  DECLARE
    l_username VARCHAR2(30) ;
    l_pipename VARCHAR2(40) ;
    l_result PLS_INTEGER ;

BEGIN
    -- ?????
    SELECT username INTO l_username FROM user_users ;

    --??????PIPE??
    l_pipename :=  'SERVALARM_' || l_username ;
    DBMS_PIPE.RESET_BUFFER ;
    -- ????
    IF INSERTING THEN
        DBMS_PIPE.PACK_MESSAGE('add') ;
    ELSIF UPDATING THEN
        DBMS_PIPE.PACK_MESSAGE('modify') ;
    ELSE
        DBMS_PIPE.PACK_MESSAGE('delete') ;
    END IF;

    -- ??????
    IF DELETING THEN
        DBMS_PIPE.PACK_MESSAGE(TO_CHAR(:OLD.ServSumAlarmID));
        DBMS_PIPE.PACK_MESSAGE(:OLD.ServAlarmTypeID);
        DBMS_PIPE.PACK_MESSAGE(:OLD.ServID);
        DBMS_PIPE.PACK_MESSAGE(TO_CHAR(:OLD.starttime,'yyyy-mm-dd hh24:mi:ss'));
        DBMS_PIPE.PACK_MESSAGE(TO_CHAR(:OLD.ALARMLEVEL));
        DBMS_PIPE.PACK_MESSAGE(:OLD.SUMMARY);
        DBMS_PIPE.PACK_MESSAGE(:OLD.Remark);
        DBMS_PIPE.PACK_MESSAGE(:OLD.AckStatus);
        DBMS_PIPE.PACK_MESSAGE(:OLD.AckUserID);
        DBMS_PIPE.PACK_MESSAGE(TO_CHAR(:OLD.AckTime,'yyyy-mm-dd hh24:mi:ss'));
        DBMS_PIPE.PACK_MESSAGE(to_char(:OLD.engiid));
    DBMS_PIPE.PACK_MESSAGE(:OLD.ServAccessPoint);
    ELSE
        DBMS_PIPE.PACK_MESSAGE(TO_CHAR(:NEW.ServSumAlarmID));
        DBMS_PIPE.PACK_MESSAGE(:NEW.ServAlarmTypeID);
        DBMS_PIPE.PACK_MESSAGE(:NEW.ServID);
        DBMS_PIPE.PACK_MESSAGE(TO_CHAR(:NEW.starttime,'yyyy-mm-dd hh24:mi:ss'));
        DBMS_PIPE.PACK_MESSAGE(TO_CHAR(:NEW.ALARMLEVEL));
        DBMS_PIPE.PACK_MESSAGE(:NEW.SUMMARY);
        DBMS_PIPE.PACK_MESSAGE(:NEW.Remark);
        DBMS_PIPE.PACK_MESSAGE(:NEW.AckStatus);
        DBMS_PIPE.PACK_MESSAGE(:NEW.AckUserID);
        DBMS_PIPE.PACK_MESSAGE(TO_CHAR(:NEW.AckTime,'yyyy-mm-dd hh24:mi:ss'));
        DBMS_PIPE.PACK_MESSAGE(to_char(:new.engiid));
    DBMS_PIPE.PACK_MESSAGE(:new.ServAccessPoint);
    END IF;

    -- ????
    l_result := DBMS_PIPE.SEND_MESSAGE(l_pipename,0,2048000) ;

    -- ?????????PIPE
    IF (l_result = 1) THEN
        DBMS_PIPE.PURGE(l_pipename) ;
    END IF;

--??????PIPE??
    l_pipename :=  'SERVALARMTRANS_' || l_username ;
    DBMS_PIPE.RESET_BUFFER ;
    -- ????
    IF INSERTING THEN
        DBMS_PIPE.PACK_MESSAGE('add') ;
    ELSIF UPDATING THEN
        DBMS_PIPE.PACK_MESSAGE('modify') ;
    ELSE
        DBMS_PIPE.PACK_MESSAGE('delete') ;
    END IF;

    -- ??????
    IF DELETING THEN
        DBMS_PIPE.PACK_MESSAGE(TO_CHAR(:OLD.ServSumAlarmID));
        DBMS_PIPE.PACK_MESSAGE(:OLD.ServID);
        DBMS_PIPE.PACK_MESSAGE(:OLD.ServAlarmTypeID);
        DBMS_PIPE.PACK_MESSAGE(TO_CHAR(:OLD.starttime,'yyyy-mm-dd hh24:mi:ss'));
        DBMS_PIPE.PACK_MESSAGE(TO_CHAR(:OLD.ALARMLEVEL));
        DBMS_PIPE.PACK_MESSAGE(:OLD.AckStatus);
        DBMS_PIPE.PACK_MESSAGE(:OLD.AckUserID);
        DBMS_PIPE.PACK_MESSAGE(TO_CHAR(:OLD.AckTime,'yyyy-mm-dd hh24:mi:ss'));
        DBMS_PIPE.PACK_MESSAGE(:OLD.SUMMARY);
    DBMS_PIPE.PACK_MESSAGE(:OLD.ServAccessPoint);
    ELSE
        DBMS_PIPE.PACK_MESSAGE(TO_CHAR(:NEW.ServSumAlarmID));
        DBMS_PIPE.PACK_MESSAGE(:NEW.ServID);
        DBMS_PIPE.PACK_MESSAGE(:NEW.ServAlarmTypeID);
        DBMS_PIPE.PACK_MESSAGE(TO_CHAR(:NEW.starttime,'yyyy-mm-dd hh24:mi:ss'));
        DBMS_PIPE.PACK_MESSAGE(TO_CHAR(:NEW.ALARMLEVEL));
        DBMS_PIPE.PACK_MESSAGE(:NEW.AckStatus);
        DBMS_PIPE.PACK_MESSAGE(:NEW.AckUserID);
        DBMS_PIPE.PACK_MESSAGE(TO_CHAR(:NEW.AckTime,'yyyy-mm-dd hh24:mi:ss'));
        DBMS_PIPE.PACK_MESSAGE(:NEW.SUMMARY);
    DBMS_PIPE.PACK_MESSAGE(:new.ServAccessPoint);
    END IF;

    -- ????
    l_result := DBMS_PIPE.SEND_MESSAGE(l_pipename,0,2048000) ;

    -- ?????????PIPE
    IF (l_result = 1) THEN
        DBMS_PIPE.PURGE(l_pipename) ;
    END IF;

EXCEPTION
    WHEN OTHERS THEN
        NULL ;
END ;
/
