CREATE TRIGGER TRG_NODE
AFTER INSERT OR UPDATE OR DELETE
  ON NODE
FOR EACH ROW
  DECLARE
    l_changetype ISCIDMAPPING.CHANGE_TYPE%TYPE;
BEGIN
     BEGIN
            SELECT CHANGE_TYPE INTO l_changetype
            FROM ISCIDMAPPING
            WHERE VPN_RES_ID = :NEW.nodecode AND RES_TYPE='REGION';
     EXCEPTION
            WHEN NO_DATA_FOUND THEN
                l_changetype := 'N' ;
     END ;
    IF(INSERTING AND l_changetype = 'N') THEN
     INSERT INTO ISCIDMAPPING ( VPN_RES_ID, RES_TYPE, ISC_RES_ID, ISC_RES_NAME,CHANGE_TYPE )
     VALUES (:NEW.nodecode, 'REGION', '', '', 'A');
    ELSIF(INSERTING AND l_changetype <> 'N') THEN
     UPDATE ISCIDMAPPING SET CHANGE_TYPE='M' WHERE VPN_RES_ID=:NEW.nodecode AND RES_TYPE='REGION';
    ELSIF(DELETING) THEN
        BEGIN
            SELECT CHANGE_TYPE INTO l_changetype
            FROM ISCIDMAPPING
            WHERE VPN_RES_ID = :OLD.nodecode AND RES_TYPE='REGION';
        EXCEPTION
            WHEN NO_DATA_FOUND THEN
                l_changetype := 'N' ;
        END ;
        IF (l_changetype = 'A') THEN
            DELETE FROM ISCIDMAPPING WHERE VPN_RES_ID = :OLD.nodecode AND RES_TYPE='REGION';
        ELSIF (l_changetype <> 'N' OR l_changetype IS NULL) THEN
            UPDATE ISCIDMAPPING SET CHANGE_TYPE = 'D' WHERE VPN_RES_ID = :OLD.nodecode AND RES_TYPE='REGION';
        END IF;
    ELSIF(UPDATING) THEN
     IF (l_changetype <> 'A' AND l_changetype <> 'N') OR (l_changetype IS NULL) THEN
            UPDATE ISCIDMAPPING SET CHANGE_TYPE='M' WHERE VPN_RES_ID=:NEW.nodecode AND RES_TYPE='REGION';
     END IF;

 END IF;
END ;
/
