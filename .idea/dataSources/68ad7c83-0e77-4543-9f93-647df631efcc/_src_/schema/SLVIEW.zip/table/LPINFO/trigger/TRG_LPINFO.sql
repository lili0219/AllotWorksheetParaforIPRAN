CREATE TRIGGER TRG_LPINFO
AFTER INSERT OR UPDATE OR DELETE
  ON LPINFO
FOR EACH ROW WHEN (FOR EACH ROW )
DECLARE
   l_fullipaddress   portinfo.fullipaddress%TYPE;
   l_ipaddress       portinfo.ipaddress%TYPE;
   l_netmask         portinfo.netmask%TYPE;
BEGIN
   IF (:OLD.changetype = 0)
   THEN
      DELETE FROM portinfo
            WHERE deviceid = :OLD.deviceid
              AND portdescr = :OLD.lpdescr
              AND portclass = 'L';

   END IF;

   IF (:NEW.changetype = 0)
   THEN
      BEGIN
         SELECT ipaddress, netmask
           INTO l_ipaddress, l_netmask
           FROM (SELECT *
                   FROM devaddr
                  WHERE changetype = 0 AND seqnum = 0) addr
          WHERE :NEW.deviceid = addr.deviceid(+) AND :NEW.lpdescr = addr.intdescr(+);
      EXCEPTION
         WHEN OTHERS
         THEN
            l_ipaddress := NULL;
            l_netmask := NULL;
            l_fullipaddress := NULL;
      END;

      IF (l_ipaddress IS NOT NULL)
      THEN
         l_fullipaddress := to_fullip (l_ipaddress);
      END IF;

      BEGIN
         INSERT INTO portinfo
                     (deviceid, portdescr, portclass, porttype,
                      portindex, portspeed, vpi, vci,
                      dlci, adminstatus, operstatus,
                      portdescrdetail, portmode, distance, ppdescr,
                      ipaddress, netmask, fullipaddress,
                      ifspeed
                     )
              VALUES (:NEW.deviceid, :NEW.lpdescr, 'L', :NEW.lptype,
                      :NEW.lpindex, :NEW.lpspeed, :NEW.vpi, :NEW.vci,
                      :NEW.dlci, :NEW.adminstatus, :NEW.operstatus,
                      :NEW.portdescrdetail, '', '', :NEW.ppdescr,
                      l_ipaddress, l_netmask, l_fullipaddress,
                      :NEW.ifspeed
                     );
      EXCEPTION
         WHEN OTHERS
         THEN
            UPDATE portinfo
               SET porttype = :NEW.lptype,
                   portindex = :NEW.lpindex,
                   portspeed = :NEW.lpspeed,
                   vpi = :NEW.vpi,
                   vci = :NEW.vci,
                   dlci = :NEW.dlci,
                   adminstatus = :NEW.adminstatus,
                   operstatus = :NEW.operstatus,
                   portdescrdetail = :NEW.portdescrdetail,
                   portmode = '',
                   distance = '',
                   ppdescr = :NEW.ppdescr,
                   ipaddress = l_ipaddress,
                   netmask = l_netmask,
                   fullipaddress = l_fullipaddress,
                   ifspeed = :NEW.ifspeed
             WHERE deviceid = :NEW.deviceid
               AND portdescr = :NEW.lpdescr
               AND portclass = 'L';
      END;
   END IF;
END;
/
