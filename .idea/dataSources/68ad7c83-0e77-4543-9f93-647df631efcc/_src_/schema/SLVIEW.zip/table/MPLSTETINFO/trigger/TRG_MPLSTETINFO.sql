CREATE TRIGGER TRG_MPLSTETINFO
AFTER INSERT OR UPDATE OF TETID, CHANGETYPE, TETCNAME, ADEVICEID, AADDRESS, BADDRESS OR DELETE
  ON MPLSTETINFO
FOR EACH ROW WHEN (FOR EACH ROW )
declare
    l_nodecodea res.nodecodea%type;
begin
    /*????????A????IP??*/
    if (:new.changetype = 0) then
        begin
            select nodecode into l_nodecodea
            from device
            where deviceid = :new.adeviceid
                and changetype = 0 ;
        exception
            when no_data_found then
                l_nodecodea := null;
        end ;
    end if;

    /*????TUNNEL*/
    if (inserting or (updating and :new.changetype = 0 and :old.changetype!=0)) then
        begin
            insert into res(resid,resname,restypeid,nodecodea,nodecodeb,ipaddressa,ipaddressb)
            values (:new.tetid,:new.tetcname,'TET_IP_COM',l_nodecodea,null,:new.aaddress,:new.baddress);
        exception
            when others then
                update res
                set resname = :new.tetname,
                    restypeid = 'TET_IP_COM',
                    nodecodea = l_nodecodea,
                    nodecodeb = null,
                    ipaddressa = :new.aaddress,
                    ipaddressb = :new.baddress
                where resid = :new.tetid ;
        end ;
     /*????TUNNEL*/
     elsif (updating and :new.changetype = 0 and :old.changetype=0) then
        update res
        set resid = :new.tetid,
            resname = :new.tetname,
            restypeid = 'TET_IP_COM',
            nodecodea = l_nodecodea,
            nodecodeb = null,
            ipaddressa = :new.aaddress,
            ipaddressb = :new.baddress
        where resid = :old.tetid ;
    /*????TUNNEL*/
    elsif (deleting or (updating and :new.changetype != 0 and :old.changetype=0)) then
        delete res where resid = :old.tetid ;
    end if;
end ;
/
