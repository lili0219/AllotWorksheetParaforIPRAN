CREATE TRIGGER TRG_RESTAG
AFTER INSERT OR UPDATE OR DELETE
  ON RESTAG
FOR EACH ROW
  DECLARE
   l_resid     restag.resid%TYPE;
   l_resclassid VARCHAR2(20) ;
   l_changeversion NUMBER(20) ;
   l_remark    VARCHAR2(200) ;
   l_tagfull   restagfull.tagfull%type ;
BEGIN

    IF (DELETING) THEN
    	l_resid := :old.resid ;
    	l_remark := 'TAG DEL: ' || :old.tag ;
    ELSE
    	l_resid := :new.resid ;
    	l_remark := 'TAG ADD: ' || :new.tag ;
    END IF ;

    l_resclassid := substr(l_resid,1,3) ;

   	UPDATE resupdate
      SET updatetime = SYSDATE,
      	  changeversion = nvl(changeversion,0)+1
    WHERE resclassid = l_resclassid
	returning changeversion into l_changeversion;

   	IF SQL%ROWCOUNT = 0
   	THEN
    	INSERT INTO resupdate(resclassid, updatetime,changeversion)
      	VALUES (l_resclassid, SYSDATE ,1)
   		returning changeversion into l_changeversion;
   	END IF;

	insert into resupdatelog (changeversion,changetime,resid,changetype,resclassid,remark)
	values (l_changeversion,sysdate,l_resid,2,l_resclassid,l_remark) ;

	/*restag???????,??????tag???restagfull??tagfull??,?????????*/
   IF (INSERTING) THEN

		UPDATE restagfull
		SET tagfull = tagfull || :NEW.tag || ' '
		WHERE resid = :NEW.resid;

		IF (SQL%ROWCOUNT = 0) THEN
			INSERT INTO restagfull(resid, tagfull) VALUES (:NEW.resid, ' ' || :NEW.tag || ' ');
		END IF;
   END IF;

	/*   restag????,????????tag?restagfull??tagfull????,?tagfull????????????*/
   IF (DELETING) THEN
		UPDATE restagfull
		SET tagfull = REPLACE (tagfull, ' ' || :OLD.tag || ' ', ' ')
		WHERE resid = :OLD.resid
		RETURNING tagfull into l_tagfull;

		IF ((SQL%ROWCOUNT = 1) and (l_tagfull=' ')) then
			DELETE FROM restagfull WHERE resid = :OLD.resid;
      	END IF;
   END IF;
END;
/
