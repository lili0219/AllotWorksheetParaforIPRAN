CREATE TRIGGER TRG_RESPARATAG
BEFORE INSERT OR UPDATE OR DELETE
  ON RESPARATAG
FOR EACH ROW
  DECLARE
   l_hasdata   CHAR;
   l_tag       VARCHAR2 (2000);
   l_resid     resparatagfull.resid%TYPE;
   l_respara   resparatagfull.respara%TYPE;
   l_hasstr    NUMBER;
BEGIN
/*restag??????????????tag???restagfull??tagfull????????????*/
   IF (INSERTING)
   THEN
      BEGIN
         SELECT resid, respara
           INTO l_resid, l_respara
           FROM resparatagfull
          WHERE resid = :NEW.resid AND respara = :NEW.respara;
      EXCEPTION
         WHEN NO_DATA_FOUND
         THEN
            l_hasdata := 'N';
      END;

      IF (l_hasdata = 'N')
      THEN
         INSERT INTO resparatagfull
                     (resid, respara, tagfull,
                      resparatype
                     )
              VALUES (:NEW.resid, :NEW.respara, :NEW.tag || ' ',
                      :NEW.resparatype
                     );
      ELSE
         UPDATE resparatagfull
            SET tagfull = tagfull || :NEW.tag || ' '
          WHERE resid = :NEW.resid AND respara = :NEW.respara;
      END IF;
   END IF;

/*   restag?????????????tag?restagfull??tagfull?????
  ?tagfull????????????*/
   IF (DELETING)
   THEN
      BEGIN
         SELECT tagfull
           INTO l_tag
           FROM resparatagfull
          WHERE resid = :OLD.resid
            AND respara = :OLD.respara
            AND LTRIM (RTRIM (tagfull)) = :OLD.tag;
      EXCEPTION
         WHEN NO_DATA_FOUND
         THEN
            l_hasdata := 'N';
      END;

      IF (l_hasdata = 'N')
      THEN
         SELECT INSTR (tagfull, :OLD.tag)
           INTO l_hasstr
           FROM resparatagfull
          WHERE resid = :OLD.resid AND respara = :OLD.respara;

         /*???????tag*/
         IF (l_hasstr <> 1)
         THEN
            UPDATE resparatagfull
               SET tagfull = REPLACE (tagfull, ' ' || :OLD.tag || ' ', ' ')
             WHERE resid = :OLD.resid AND respara = :OLD.respara;
         ELSE
            UPDATE resparatagfull
               SET tagfull = SUBSTR (tagfull, LENGTH (:OLD.tag) + 2)
             WHERE resid = :OLD.resid AND respara = :OLD.respara;
         END IF;
      ELSE
         /*??????tag?????*/
         DELETE FROM resparatagfull
               WHERE resid = :OLD.resid AND respara = :OLD.respara;
      END IF;
   END IF;
END;
/
