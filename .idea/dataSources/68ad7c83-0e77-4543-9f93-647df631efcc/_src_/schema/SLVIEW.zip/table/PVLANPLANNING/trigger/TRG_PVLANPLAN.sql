CREATE TRIGGER TRG_PVLANPLAN
AFTER INSERT OR UPDATE OR DELETE
  ON PVLANPLANNING
FOR EACH ROW
  declare
  v_begin number;
  v_end   number;

begin

  if (inserting) then
    for v_id in :new.idstart .. :new.idend loop

      insert into pvlanplandetail values (:new.pvlanseqno, v_id);
    end loop;
    commit;
  elsif (updating) then
    delete from pvlanplandetail where pvlanseqno = :old.pvlanseqno;
    for v_id in :new.idstart .. :new.idend loop
      insert into pvlanplandetail values (:new.pvlanseqno, v_id);
    end loop;
    commit;
  elsif (deleting) then
    delete from pvlanplandetail where pvlanseqno = :old.pvlanseqno;
    commit;
  end if;

exception
  when others then
    null;
end;
/
