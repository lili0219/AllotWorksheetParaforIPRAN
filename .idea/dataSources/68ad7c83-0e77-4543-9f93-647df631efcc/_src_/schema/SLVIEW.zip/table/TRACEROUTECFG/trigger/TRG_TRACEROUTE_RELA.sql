CREATE TRIGGER TRG_TRACEROUTE_RELA
AFTER INSERT OR UPDATE OF CHANGETYPE, ROUTENAME, DEVICEID OR DELETE
  ON TRACEROUTECFG
FOR EACH ROW
  BEGIN

    /*??????*/
    IF (INSERTING AND :NEW.ChangeType=0) THEN
        /*????*/
        BEGIN
        INSERT INTO RESRELATION (ARESID, ARESPARA, ARESCLASSID,BRESID, BRESPARA, BRESNAME,BRESCLASSNAME, RELATYPE)
        VALUES ( :NEW.DeviceID, '-1','DEV' , :NEW.RouteID, '-1', :NEW.RouteName,'Traceroute??' , 'REFERED');
        EXCEPTION
            WHEN OTHERS THEN
                UPDATE RESRELATION
                SET BRESNAME = :NEW.RouteName
                WHERE BResID=:OLD.RouteID;
        END ;
    /*??????*/
    ELSIF (DELETING OR (UPDATING AND :NEW.changetype = -1 AND :OLD.changetype=0)) THEN
      DELETE FROM RESRELATION WHERE AResID = :OLD.DeviceID AND ARESPARA='-1' and BResID=:OLD.RouteID AND BResPara='-1';
     /*??????*/
     ELSIF (UPDATING AND :NEW.changetype = 0 AND :OLD.changetype = 0) THEN
        BEGIN
        /*??????*/
        DELETE FROM RESRELATION WHERE BResID=:OLD.RouteID;
        /*??????*/
        INSERT INTO RESRELATION (ARESID, ARESPARA, ARESCLASSID,BRESID, BRESPARA, BRESNAME,BRESCLASSNAME, RELATYPE)
        VALUES ( :NEW.DeviceID, '-1','DEV' , :NEW.RouteID, '-1', :NEW.RouteName,'Traceroute??' , 'REFERED');
        EXCEPTION
            WHEN OTHERS THEN
                UPDATE RESRELATION
                SET BRESNAME = :NEW.RouteName
                WHERE BResID=:OLD.RouteID;
        END ;
    END IF;
END ;
/
