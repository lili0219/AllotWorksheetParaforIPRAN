CREATE TRIGGER TRG_TRACEROUTECFG
AFTER INSERT OR UPDATE OF ROUTEID, CHANGETYPE, ROUTENAME, DEVICEID, OPPOSITEIP OR DELETE
  ON TRACEROUTECFG
FOR EACH ROW WHEN (FOR EACH ROW )
declare
    l_nodecodea res.nodecodea%type;
    l_ipaddressa res.ipaddressa%type;
begin
    /*????????A????IP??*/
    if (:new.changetype = 0) then
        begin
            select nodecode,loopaddress into l_nodecodea,l_ipaddressa
            from device
            where deviceid = :new.deviceid
                and changetype = 0 ;
        exception
            when no_data_found then
                l_nodecodea := null;
                l_ipaddressa := null;
        end ;
    end if;

    /*??????*/
    if (inserting or (updating and :new.changetype = 0 and :old.changetype!=0)) then
        begin
            insert into res(resid,resname,restypeid,nodecodea,nodecodeb,ipaddressa,ipaddressb)
            values (:new.routeid,:new.routename,'ROU_TRACEROUTE',l_nodecodea,null,l_ipaddressa,:new.oppositeip);
        exception
            when others then
                update res
                set resname = :new.routename,
                    restypeid = 'ROU_TRACEROUTE',
                    nodecodea = l_nodecodea,
                    nodecodeb = null,
                    ipaddressa = l_ipaddressa,
                    ipaddressb = :new.oppositeip
                where resid = :new.routeid ;
        end ;
     /*??????*/
     elsif (updating and :new.changetype = 0 and :old.changetype=0) then
        update res
        set resid = :new.routeid,
            resname = :new.routename,
            restypeid = 'ROU_TRACEROUTE',
            nodecodea = l_nodecodea,
            nodecodeb = null,
            ipaddressa = l_ipaddressa,
            ipaddressb = :new.oppositeip
        where resid = :old.routeid ;
    /*??????*/
    elsif (deleting or (updating and :new.changetype != 0 and :old.changetype=0)) then
        delete res where resid = :old.routeid ;
    end if;
end ;
/
