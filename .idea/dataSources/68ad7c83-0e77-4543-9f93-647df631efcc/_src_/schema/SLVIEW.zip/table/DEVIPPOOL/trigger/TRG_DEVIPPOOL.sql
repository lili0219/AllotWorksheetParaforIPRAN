CREATE TRIGGER TRG_DEVIPPOOL
BEFORE INSERT OR UPDATE OF STARTIP, MASK
  ON DEVIPPOOL
FOR EACH ROW
  DECLARE
   ipsegment    VARCHAR2 (500);
   sipsegment   VARCHAR2 (500);
   nipsegment   VARCHAR2 (500);
/******************************************************************************
   NAME:       trg_devippool
   PURPOSE:

   REVISIONS:
   Ver        Date        Author           Description
   ---------  ----------  ---------------  ------------------------------------
   1.0        2009-12-15             1. Created this trigger.
******************************************************************************/
BEGIN
   ipsegment := to_ipsegment (:NEW.startip, :NEW.MASK);

   IF ipsegment IS NOT NULL AND INSTRB (ipsegment, '***') > 0
   THEN
      sipsegment := SUBSTR (ipsegment, 0, INSTRB (ipsegment, '***') - 1);
      nipsegment := SUBSTR (ipsegment, INSTRB (ipsegment, '***') + 3);

      IF (nipsegment IS NOT NULL AND INSTRB (nipsegment, '-') > 0)
      THEN
         :NEW.nstartip := SUBSTR (nipsegment, 0, INSTRB (nipsegment, '-') - 1);
         :NEW.nendip := SUBSTR (nipsegment, INSTRB (nipsegment, '-') + 1);
      END IF;
   END IF;
EXCEPTION
   WHEN OTHERS
   THEN
      -- Consider logging the error and then re-raise
      NULL;
END trg_devippool;
/
