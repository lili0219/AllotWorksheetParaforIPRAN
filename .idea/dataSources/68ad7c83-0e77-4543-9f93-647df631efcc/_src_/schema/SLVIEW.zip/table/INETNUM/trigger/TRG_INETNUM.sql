CREATE TRIGGER TRG_INETNUM
BEFORE INSERT OR UPDATE OF INETNUM
  ON INETNUM
FOR EACH ROW
  DECLARE
   pos          NUMBER;
   l_startnum   NUMBER;
   l_endnum     NUMBER;
   l_startip    VARCHAR2 (39);
   l_endip      VARCHAR2 (39);
   l_end        NUMBER;
   l_startpos   NUMBER;
   l_endpos     NUMBER;
   l_num        NUMBER;
BEGIN
   pos := INSTR (:NEW.inetnum, '-');

   IF (:NEW.ipversion = 'IPv4')
   THEN
      IF (pos = 16)
      THEN
         l_startip := SUBSTR (:NEW.inetnum, 1, 15);
         l_endip := SUBSTR (:NEW.inetnum, 17, 15);
         l_startnum :=
              TO_NUMBER (SUBSTR (l_startip, 1, 3)) * 256 * 256 * 256
            + TO_NUMBER (SUBSTR (l_startip, 5, 3)) * 256 * 256
            + TO_NUMBER (SUBSTR (l_startip, 9, 3)) * 256
            + TO_NUMBER (SUBSTR (l_startip, 13, 3));
         l_endnum :=
              TO_NUMBER (SUBSTR (l_endip, 1, 3)) * 256 * 256 * 256
            + TO_NUMBER (SUBSTR (l_endip, 5, 3)) * 256 * 256
            + TO_NUMBER (SUBSTR (l_endip, 9, 3)) * 256
            + TO_NUMBER (SUBSTR (l_endip, 13, 3));
         :NEW.inetnumsum := l_endnum - l_startnum + 1;
      --DBMS_OUTPUT.put_line (':NEW.inetnumsum :' || :NEW.inetnumsum);
      END IF;
   ELSIF (:NEW.ipversion = 'IPv6')
   THEN
      IF (pos = 40)
      THEN
         l_startip := SUBSTR (:NEW.inetnum, 1, 39);
         l_endip := SUBSTR (:NEW.inetnum, 41, 39);
         l_num := 0;

         FOR i IN 1 .. 7
         LOOP
            l_startpos := INSTRB (l_startip, ':');
            l_endpos := INSTRB (l_endip, ':');

            IF    l_startpos = 0
               OR l_endpos = 0
               OR l_startpos <> 5
               OR l_endpos <> 5
            THEN
               RETURN;
            END IF;

            l_num :=
                 l_num
               +   (  hxtoten (SUBSTRB (l_endip, 1, 4))
                    - hxtoten (SUBSTRB (l_startip, 1, 4))
                   )
                 * POWER (16,32 - i * 4);
            l_startip := SUBSTR (l_startip, 6);
            l_endip := SUBSTR (l_endip, 6);
         END LOOP;

         IF LENGTHB (l_startip) <> 4 OR LENGTHB (l_endip) <> 4
         THEN
            RETURN;
         END IF;

        :NEW.inetnumsum := l_num + (hxtoten (l_endip) - hxtoten (l_startip));
      END IF;
   END IF;
EXCEPTION
   WHEN OTHERS
   THEN
      NULL;
END;
/
