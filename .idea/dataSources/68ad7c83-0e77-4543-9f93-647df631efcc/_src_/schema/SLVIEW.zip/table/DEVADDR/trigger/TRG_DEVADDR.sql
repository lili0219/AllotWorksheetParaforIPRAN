CREATE TRIGGER TRG_DEVADDR
AFTER INSERT OR UPDATE OF DEVICEID, INTDESCR, CHANGETYPE, SEQNUM, IPADDRESS OR DELETE
  ON DEVADDR
FOR EACH ROW WHEN (FOR EACH ROW )
DECLARE
   l_fullipaddress   portinfo.fullipaddress%TYPE;
begin
    /*??????????IP??*/
    if (:old.changetype = 0 and :old.seqnum=0) then
        /*A?*/
        update res
        set ipaddressa = null
        where resid in (select a.circuitid resid
                        from circuit a
                        where a.changetype = 0
                            and a.adeviceid = :old.deviceid
                            and a.aintdescr=:old.intdescr );

        /*B?*/
        update res
        set ipaddressb = null
        where resid in (select a.circuitid resid
                        from circuit a
                        where a.changetype = 0
                            and a.bdeviceid = :old.deviceid
                            and a.bintdescr=:old.intdescr );
       /*????*/
       UPDATE portinfo
         SET ipaddress = NULL,
             netmask = NULL,
             fullipaddress = NULL
       WHERE deviceid = :OLD.deviceid AND portdescr = :OLD.intdescr;
    end if;

    /*??????????IP??*/
    if (:new.changetype = 0 and :new.seqnum=0) then
        /*A?*/
        update res
        set ipaddressa = :new.ipaddress
        where resid in (select a.circuitid resid
                        from circuit a
                        where a.changetype = 0
                            and a.adeviceid = :new.deviceid
                            and a.aintdescr=:new.intdescr );

        /*B?*/
        update res
        set ipaddressb = :new.ipaddress
        where resid in (select a.circuitid resid
                        from circuit a
                        where a.changetype = 0
                            and a.bdeviceid = :new.deviceid
                            and a.bintdescr=:new.intdescr );

       /*????*/
      IF (:NEW.ipaddress IS NOT NULL)
      THEN
         l_fullipaddress := to_fullip (:NEW.ipaddress);
      END IF;

      UPDATE portinfo
         SET ipaddress = :NEW.ipaddress,
             netmask = :NEW.netmask,
             fullipaddress = l_fullipaddress
       WHERE deviceid = :NEW.deviceid AND portdescr = :NEW.intdescr;
    end if;
end ;
/
