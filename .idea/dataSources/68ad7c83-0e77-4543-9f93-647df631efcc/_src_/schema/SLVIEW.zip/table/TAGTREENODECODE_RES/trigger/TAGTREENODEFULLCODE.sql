CREATE TRIGGER TAGTREENODEFULLCODE
BEFORE INSERT OR UPDATE OF TAGTREENODECODE
  ON TAGTREENODECODE_RES
FOR EACH ROW
  DECLARE
   l_tagtreenodefullcode   tagtreecfg.tagtreenodefullcode%TYPE;
BEGIN
   SELECT a.tagtreenodefullcode
     INTO :NEW.tagtreenodefullcode
     FROM tagtreecfg a
    WHERE a.tagtreenodecode = :NEW.tagtreenodecode;
EXCEPTION
   WHEN OTHERS
   THEN
      NULL;
END;
/
