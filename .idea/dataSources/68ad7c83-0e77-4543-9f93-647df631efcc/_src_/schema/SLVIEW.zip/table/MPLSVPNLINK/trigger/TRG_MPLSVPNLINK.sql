CREATE TRIGGER TRG_MPLSVPNLINK
AFTER INSERT OR UPDATE OR DELETE
  ON MPLSVPNLINK
FOR EACH ROW
  DECLARE
    l_changetype ISCIDMAPPING.CHANGE_TYPE%TYPE;
BEGIN
     BEGIN
            SELECT CHANGE_TYPE INTO l_changetype
            FROM ISCIDMAPPING
            WHERE VPN_RES_ID = TO_CHAR(:NEW.VPNLinkID) AND RES_TYPE='SR';
     EXCEPTION
            WHEN NO_DATA_FOUND THEN
                l_changetype := 'N' ;
     END ;
    IF(INSERTING AND l_changetype = 'N') THEN
        INSERT INTO ISCIDMAPPING ( VPN_RES_ID, RES_TYPE, ISC_RES_ID, ISC_RES_NAME,CHANGE_TYPE )
        VALUES (:NEW.VPNLinkID, 'SR', '', '', 'A');
    ELSIF(DELETING) THEN
        BEGIN
            SELECT CHANGE_TYPE INTO l_changetype
            FROM ISCIDMAPPING
            WHERE VPN_RES_ID = TO_CHAR(:OLD.VPNLinkID) AND RES_TYPE='SR';
        EXCEPTION
            WHEN NO_DATA_FOUND THEN
                l_changetype := 'N' ;
        END ;
        IF (l_changetype = 'A') THEN
            DELETE FROM ISCIDMAPPING WHERE VPN_RES_ID = TO_CHAR(:OLD.VPNLinkID) AND RES_TYPE='SR';
        ELSIF (l_changetype <> 'N'  OR l_changetype IS NULL ) THEN
            UPDATE ISCIDMAPPING SET CHANGE_TYPE = 'D' WHERE VPN_RES_ID = TO_CHAR(:OLD.VPNLinkID) AND RES_TYPE='SR';
        END IF;
    ELSIF(UPDATING) THEN
     IF (l_changetype <> 'A' AND l_changetype <> 'N') OR (l_changetype IS NULL) THEN
            UPDATE ISCIDMAPPING SET CHANGE_TYPE='M' WHERE VPN_RES_ID=TO_CHAR(:NEW.VPNLinkID) AND RES_TYPE='SR';
     END IF;
 END IF;
END ;
/
