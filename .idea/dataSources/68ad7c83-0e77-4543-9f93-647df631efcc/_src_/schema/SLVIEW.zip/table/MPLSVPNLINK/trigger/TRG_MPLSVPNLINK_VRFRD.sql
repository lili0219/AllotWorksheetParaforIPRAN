CREATE TRIGGER TRG_MPLSVPNLINK_VRFRD
AFTER INSERT OR UPDATE OF VRFNAME, RD OR DELETE
  ON MPLSVPNLINK
FOR EACH ROW
  DECLARE
BEGIN
   DECLARE
      --???????vpnrd????
      CURSOR c_vpnrd(p_vpnid IN VARCHAR2, p_rd IN VARCHAR2) IS
         SELECT vr.linkmatchnum
         FROM vpnrd vr
         WHERE vr.vpnid = p_vpnid AND vr.rd = p_rd;
      --????vpnrd??linkmatchnum???
      v_linkmatchnumbyrd vpnrd.linkmatchnum%TYPE;

      --???????vpnvrf????
      CURSOR c_vpnvrf(p_vpnid IN VARCHAR2, p_vrfname IN VARCHAR2) IS
         SELECT vv.linkmatchnum
         FROM vpnvrf vv
         WHERE vv.vpnid = p_vpnid AND vv.vrfname = p_vrfname;
       --????vpnrd??linkmatchnum???
       v_linkmatchnumbyvrfname vpnvrf.linkmatchnum%TYPE;
   BEGIN
      --mplsvpnlink?????????????
      IF (INSERTING OR UPDATING) THEN
         --??vpnrd?
         IF (INSERTING OR (:OLD.Rd <> :NEW.Rd)) THEN
            OPEN c_vpnrd (:NEW.Vpnid, :NEW.Rd);
            LOOP
               FETCH c_vpnrd INTO v_linkmatchnumbyrd;
               IF (c_vpnrd%FOUND) THEN
                  UPDATE vpnrd vr
                  SET vr.linkmatchnum = (v_linkmatchnumbyrd + 1)
                  WHERE vr.vpnid = :NEW.Vpnid AND vr.rd = :NEW.Rd;
               ELSE
                  INSERT INTO vpnrd(vpnid, rd, linkmatchnum)
                  VALUES(:NEW.Vpnid, :NEW.Rd, 1);
               END IF;
               EXIT;
            END LOOP;
            CLOSE c_vpnrd;
         END IF;
         --??vpnvrf?
         IF (INSERTING OR (:OLD.Vrfname <> :NEW.Vrfname)) THEN
            OPEN c_vpnvrf (:NEW.Vpnid, :NEW.Vrfname);
            LOOP
               FETCH c_vpnvrf INTO v_linkmatchnumbyvrfname;
               IF (c_vpnvrf%FOUND) THEN
                  UPDATE vpnvrf vv
                  SET vv.linkmatchnum = (v_linkmatchnumbyvrfname + 1)
                  WHERE vv.vpnid = :NEW.Vpnid AND vv.vrfname = :NEW.Vrfname;
               ELSE
                  INSERT INTO vpnvrf(vpnid, vrfname, linkmatchnum)
                  VALUES(:NEW.Vpnid, :NEW.Vrfname, 1);
               END IF;
               EXIT;
            END LOOP;
            CLOSE c_vpnvrf;
         END IF;
      END IF;
      --mplsvpnlink?????????????
      IF (DELETING OR UPDATING) THEN
         --??vpnrd?
         IF (DELETING OR (:OLD.Rd <> :NEW.Rd)) THEN
            OPEN c_vpnrd (:OLD.Vpnid, :OLD.Rd);
               LOOP
                  FETCH c_vpnrd INTO v_linkmatchnumbyrd;
                  EXIT WHEN c_vpnrd%NOTFOUND;
                  IF (v_linkmatchnumbyrd = 1) THEN
                     DELETE
                     FROM vpnrd vr
                     WHERE vr.vpnid = :OLD.Vpnid AND vr.rd = :OLD.Rd;
                  ELSE
                     UPDATE vpnrd vr
                     SET vr.linkmatchnum = (v_linkmatchnumbyrd - 1)
                     WHERE vr.vpnid = :OLD.Vpnid AND vr.rd = :OLD.Rd;
                  END IF;
               END LOOP;
            CLOSE c_vpnrd;
         END IF;
         --??vpnvrf?
         IF (DELETING OR (:OLD.Vrfname <> :NEW.Vrfname)) THEN
            OPEN c_vpnvrf (:OLD.Vpnid, :OLD.Vrfname);
               LOOP
                  FETCH c_vpnvrf INTO v_linkmatchnumbyvrfname;
                  EXIT WHEN c_vpnvrf%NOTFOUND;
                  IF (v_linkmatchnumbyvrfname = 1) THEN
                     DELETE
                     FROM vpnvrf vv
                     WHERE vv.vpnid = :OLD.Vpnid AND vv.vrfname = :OLD.Vrfname;
                  ELSE
                     UPDATE vpnvrf vv
                     SET vv.linkmatchnum = (v_linkmatchnumbyvrfname - 1)
                     WHERE vv.vpnid = :OLD.Vpnid AND vv.vrfname = :OLD.Vrfname;
                  END IF;
               END LOOP;
            CLOSE c_vpnrd;
         END IF;
      END IF;
   EXCEPTION
      WHEN OTHERS THEN
         DBMS_OUTPUT.PUT_LINE('????!');
   END;
END TRG_MPLSVPNLINK_VRFRD;
/
