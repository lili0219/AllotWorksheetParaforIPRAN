CREATE TRIGGER TRG_PE
AFTER INSERT OR UPDATE OR DELETE
  ON PE
FOR EACH ROW
  DECLARE
    l_changetype ISCIDMAPPING.CHANGE_TYPE%TYPE;
    l_hasdata    CHAR;
BEGIN
     BEGIN
            SELECT CHANGE_TYPE INTO l_changetype
            FROM ISCIDMAPPING
            WHERE VPN_RES_ID = :NEW.peid AND RES_TYPE='PE';
     EXCEPTION
            WHEN NO_DATA_FOUND THEN
                l_changetype := 'N' ;
     END ;
     --????ISCIDMAPPING?????
     IF(INSERTING AND l_changetype = 'N') THEN
       BEGIN
            INSERT INTO ISCIDMAPPING ( VPN_RES_ID, RES_TYPE, ISC_RES_ID, ISC_RES_NAME,CHANGE_TYPE )
            VALUES (:NEW.peid, 'PE', '', '', 'A');
         BEGIN
            SELECT CHANGE_TYPE INTO l_hasdata
            FROM ISCIDMAPPING
            WHERE VPN_RES_ID = :NEW.DEVICEID AND RES_TYPE='DEVICE';
         EXCEPTION
            WHEN NO_DATA_FOUND THEN
                l_hasdata := 'N' ;
         END ;
         IF(l_hasdata = 'N') THEN
            INSERT INTO ISCIDMAPPING ( VPN_RES_ID, RES_TYPE, ISC_RES_ID, ISC_RES_NAME,CHANGE_TYPE )
             VALUES (:NEW.DEVICEID, 'DEVICE', '', '', 'A');
         ELSE
            UPDATE ISCIDMAPPING SET CHANGE_TYPE='M' WHERE VPN_RES_ID=:NEW.DEVICEID AND RES_TYPE='DEVICE';
         END IF;
       END;
      ELSIF(INSERTING AND l_changetype <> 'N') THEN
         UPDATE ISCIDMAPPING SET CHANGE_TYPE='M' WHERE VPN_RES_ID=:NEW.peid AND RES_TYPE='PE';
         UPDATE ISCIDMAPPING SET CHANGE_TYPE='M' WHERE VPN_RES_ID=:NEW.DEVICEID AND RES_TYPE='DEVICE';
      ELSIF(DELETING) THEN
          BEGIN
            SELECT CHANGE_TYPE INTO l_changetype
            FROM ISCIDMAPPING
            WHERE VPN_RES_ID = :OLD.peid AND RES_TYPE='PE';
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
                l_changetype := 'N' ;
          END ;
          IF (l_changetype = 'A') THEN
            DELETE FROM ISCIDMAPPING WHERE VPN_RES_ID = :OLD.peid AND RES_TYPE='PE';
            DELETE FROM ISCIDMAPPING WHERE VPN_RES_ID = :OLD.DEVICEID AND RES_TYPE='DEVICE';
          --l_changetype IS NULL ??????????
          ELSIF (l_changetype <> 'N' OR l_changetype IS NULL) THEN
            UPDATE ISCIDMAPPING SET CHANGE_TYPE = 'D' WHERE VPN_RES_ID = :OLD.peid AND RES_TYPE='PE';
            UPDATE ISCIDMAPPING SET CHANGE_TYPE = 'D' WHERE VPN_RES_ID = :OLD.DEVICEID AND RES_TYPE='DEVICE';
          END IF;
     ELSIF(UPDATING) THEN
        IF (l_changetype <> 'A' AND l_changetype <> 'N')  OR (l_changetype IS NULL) THEN
            UPDATE ISCIDMAPPING SET CHANGE_TYPE='M' WHERE VPN_RES_ID=:NEW.peid AND RES_TYPE='PE';
            UPDATE ISCIDMAPPING SET CHANGE_TYPE='M' WHERE VPN_RES_ID=:NEW.DEVICEID AND RES_TYPE='DEVICE';
        END IF;
     END IF;
 END;
/
