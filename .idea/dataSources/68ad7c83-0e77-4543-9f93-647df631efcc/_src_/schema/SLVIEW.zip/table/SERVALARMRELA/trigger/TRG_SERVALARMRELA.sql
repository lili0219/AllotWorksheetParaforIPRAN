CREATE TRIGGER TRG_SERVALARMRELA
AFTER INSERT
  ON SERVALARMRELA
FOR EACH ROW
  declare
    l_username varchar2(30) ;
    l_pipename varchar2(40) ;
    l_result pls_integer ;

begin
    -- ?????
    select username into l_username from user_users ;

    --??????PIPE??
    l_pipename :=  'SERVALARMRELA_' || l_username ;

    -- ????
    dbms_pipe.reset_buffer ;
    dbms_pipe.pack_message(to_char(:new.ServSumAlarmID));
    dbms_pipe.pack_message(to_char(:new.SumAlarmID));

    -- ????
    l_result := dbms_pipe.send_message(l_pipename,0,102400) ;

    -- ?????????PIPE
    if (l_result = 1) then
        dbms_pipe.purge(l_pipename) ;
    end if;



exception
    when others then
        null ;
end ;
/
