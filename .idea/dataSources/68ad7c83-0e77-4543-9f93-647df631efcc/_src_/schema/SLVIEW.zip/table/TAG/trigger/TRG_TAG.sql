CREATE TRIGGER TRG_TAG
AFTER UPDATE OF VALIDFLAG OR DELETE
  ON TAG
FOR EACH ROW
  BEGIN

   IF (DELETING or :new.validflag<>1)
   THEN
	  UPDATE userinfo
	  set AuthUpdateTime=sysdate
	  where netuserid in (select netuserid FROM userresauth
            WHERE restypeid = 'TAG' AND resid = :OLD.tag) ;

      DELETE FROM userresauth
            WHERE restypeid = 'TAG' AND resid = :OLD.tag;

      UPDATE tagtreecfg
         SET tag = NULL,
             isleaf = 0
       WHERE tag = :OLD.tag;
   END IF;
END;
/
