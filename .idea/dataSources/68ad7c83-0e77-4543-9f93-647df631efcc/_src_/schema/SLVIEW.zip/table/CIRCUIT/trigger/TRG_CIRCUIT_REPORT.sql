CREATE TRIGGER TRG_CIRCUIT_REPORT
AFTER INSERT OR UPDATE OF CHANGETYPE, CIRCUITNAME, ADEVICEID, BDEVICEID, CIRPROPCODE OR DELETE
  ON CIRCUIT
FOR EACH ROW WHEN (FOR EACH ROW )
declare
  l_nodenum number;
  v_paravalue varchar2(512);
begin

  select paravalue
    into v_paravalue
    from syspara
   where paraname = 'IsStatDelCirForFPReport';


  --????????
  if (deleting or
     (v_paravalue !=1 and updating and :new.changetype != 0 and :old.changetype = 0)) then
    delete from tagtreenodecode_res where resid = :old.circuitid;
  end if;
  if (inserting or (updating and :new.changetype = 0)) then
    l_nodenum := 0;
    begin
      if (:new.bdeviceid is not null) then
        insert into reporttemptable
          (str0)
          select distinct m1.tagtreenodecode
            from device         d,
                 node           n,
                 device         bd,
                 node           bn,
                 cirprop        cp,
                 fpcirmatchrule m1,
                 fpcirmatchrule m2,
                 fpcirmatchrule m3,
                 fpcirmatchrule m4
           where :new.adeviceid = d.deviceid
             and d.nodecode = n.nodecode
             and m1.tagtreenodecode = m2.tagtreenodecode
             and m1.matchattribute = 'ANodeCode'
             and n.nodefullcode like '%' || m1.matchvalue || '%'
             and :new.cirpropcode = cp.cirpropcode
             and m2.matchattribute = 'CirPropCode'
             and cp.cirpropfullcode like '%' || m2.matchvalue || '%'
             and m1.tagtreenodecode = m3.tagtreenodecode
             and m3.matchattribute = 'CircuitName'
             and regexp_like(:new.circuitname, m3.matchvalue)
             and :new.bdeviceid = bd.deviceid(+)
             and bd.nodecode = bn.nodecode(+)
             and m1.tagtreenodecode = m4.tagtreenodecode
             and m4.matchattribute = 'BNodeCode'
             and nvl(bn.nodefullcode, 'NOD999') like
                 '%' || m4.matchvalue || '%';
        select count(str0) into l_nodenum from reporttemptable;
      else
        insert into reporttemptable
          (str0)
          select distinct m1.tagtreenodecode
            from device         d,
                 node           n,
                 device         bd,
                 node           bn,
                 cirprop        cp,
                 fpcirmatchrule m1,
                 fpcirmatchrule m2,
                 fpcirmatchrule m3,
                 fpcirmatchrule m4
           where :new.adeviceid = d.deviceid
             and d.nodecode = n.nodecode
             and m1.tagtreenodecode = m2.tagtreenodecode
             and m1.matchattribute = 'ANodeCode'
             and n.nodefullcode like '%' || m1.matchvalue || '%'
             and :new.cirpropcode = cp.cirpropcode
             and m2.matchattribute = 'CirPropCode'
             and cp.cirpropfullcode like '%' || m2.matchvalue || '%'
             and m1.tagtreenodecode = m3.tagtreenodecode
             and m3.matchattribute = 'CircuitName'
             and regexp_like(:new.circuitname, m3.matchvalue)
             and bd.nodecode = bn.nodecode(+)
             and m1.tagtreenodecode = m4.tagtreenodecode
             and m4.matchattribute = 'BNodeCode'
             and nvl(bn.nodefullcode, 'NOD999') like
                 '%' || m4.matchvalue || '%';
        select count(str0) into l_nodenum from reporttemptable;
      end if;
    exception
      when others then
        null;
    end;
    if (l_nodenum > 0) then
      /*
      --????????
      DELETE FROM tagtreenodecode_res t
      WHERE t.resid = :NEW.circuitid
      AND NOT EXISTS (SELECT 1
      FROM reporttemptable r
      WHERE t.tagtreenodecode = r.str0);
      --????????????????
      DELETE FROM reporttemptable r
      WHERE EXISTS (
      SELECT 1
      FROM tagtreenodecode_res t
      WHERE t.tagtreenodecode = r.str0
      AND t.resid = :NEW.circuitid);
      */
      --?????????TAG??
      begin
        delete from tagtreenodecode_res t where t.resid = :new.circuitid;
      exception
        when others then
          null;
      end;
      --???????
      begin
        if (:new.bdeviceid is not null) then
          insert into tagtreenodecode_res
            (tagtreenodecode, resid, operrela, remark, tagtreenodefullcode)
            select distinct m1.tagtreenodecode,
                            :new.circuitid,
                            m5.matchvalue,
                            null,
                            tcfg.tagtreenodefullcode
              from device         d,
                   node           n,
                   device         bd,
                   node           bn,
                   cirprop        cp,
                   fpcirmatchrule m1,
                   fpcirmatchrule m2,
                   fpcirmatchrule m3,
                   fpcirmatchrule m4,
                   fpcirmatchrule m5,
                   tagtreecfg     tcfg
             where :new.adeviceid = d.deviceid
               and d.nodecode = n.nodecode
               and m1.tagtreenodecode = m2.tagtreenodecode
               and m1.matchattribute = 'ANodeCode'
               and n.nodefullcode like '%' || m1.matchvalue || '%'
               and :new.cirpropcode = cp.cirpropcode
               and m2.matchattribute = 'CirPropCode'
               and cp.cirpropfullcode like '%' || m2.matchvalue || '%'
               and m1.tagtreenodecode = m3.tagtreenodecode
               and m3.matchattribute = 'CircuitName'
               and regexp_like(:new.circuitname, m3.matchvalue)
               and :new.bdeviceid = bd.deviceid(+)
               and bd.nodecode = bn.nodecode(+)
               and m1.tagtreenodecode = m4.tagtreenodecode
               and m4.matchattribute = 'BNodeCode'
               and nvl(bn.nodefullcode, 'NOD999') like
                   '%' || m4.matchvalue || '%'
               and m1.tagtreenodecode = m5.tagtreenodecode
               and m5.matchattribute = 'OperRela'
               and m1.tagtreenodecode = tcfg.tagtreenodecode;
        else
          insert into tagtreenodecode_res
            (tagtreenodecode, resid, operrela, remark, tagtreenodefullcode)
            select distinct m1.tagtreenodecode,
                            :new.circuitid,
                            m5.matchvalue,
                            null,
                            tcfg.tagtreenodefullcode
              from device         d,
                   node           n,
                   device         bd,
                   node           bn,
                   cirprop        cp,
                   fpcirmatchrule m1,
                   fpcirmatchrule m2,
                   fpcirmatchrule m3,
                   fpcirmatchrule m4,
                   fpcirmatchrule m5,
                   tagtreecfg     tcfg
             where :new.adeviceid = d.deviceid
               and d.nodecode = n.nodecode
               and m1.tagtreenodecode = m2.tagtreenodecode
               and m1.matchattribute = 'ANodeCode'
               and n.nodefullcode like '%' || m1.matchvalue || '%'
               and :new.cirpropcode = cp.cirpropcode
               and m2.matchattribute = 'CirPropCode'
               and cp.cirpropfullcode like '%' || m2.matchvalue || '%'
               and m1.tagtreenodecode = m3.tagtreenodecode
               and m3.matchattribute = 'CircuitName'
               and regexp_like(:new.circuitname, m3.matchvalue)
               and bd.nodecode = bn.nodecode(+)
               and m1.tagtreenodecode = m4.tagtreenodecode
               and m4.matchattribute = 'BNodeCode'
               and nvl(bn.nodefullcode, 'NOD999') like
                   '%' || m4.matchvalue || '%'
               and m1.tagtreenodecode = m5.tagtreenodecode
               and m5.matchattribute = 'OperRela'
               and m1.tagtreenodecode = tcfg.tagtreenodecode;
        end if;
      exception
        when others then
          null;
      end;
    end if;
  end if;
end;
/
