CREATE TRIGGER TRG_CIRCUITPIPE
AFTER INSERT OR UPDATE OR DELETE
  ON CIRCUIT
FOR EACH ROW
  declare
    l_username varchar2(30);
    l_pipename varchar2(40);
    l_result pls_integer;

begin
    -- ?????
    select username into l_username from user_users;

    --??????PIPE??
    l_pipename :=  'CIRCUIT_' || l_username;
    dbms_pipe.reset_buffer ;
    dbms_pipe.pack_message('circuit');
    -- ????
    if inserting then
        dbms_pipe.pack_message('add');
    elsif updating then
        dbms_pipe.pack_message('modify');
    else
        dbms_pipe.pack_message('delete');
    end if;

    -- ??????
    if deleting then
        dbms_pipe.pack_message(to_char(:old.circuitid));
dbms_pipe.pack_message(to_char(:old.changetype));
dbms_pipe.pack_message(to_char(:old.circuitname));
dbms_pipe.pack_message(to_char(:old.adeviceid));
dbms_pipe.pack_message(to_char(:old.aintdescr));
dbms_pipe.pack_message(to_char(:old.bdeviceid));
dbms_pipe.pack_message(to_char(:old.bintdescr));
dbms_pipe.pack_message(to_char(:old.cirpropcode));
dbms_pipe.pack_message(to_char(:old.transtypecode));
dbms_pipe.pack_message(to_char(:old.transcircode));
dbms_pipe.pack_message(to_char(:old.bandwidth));
dbms_pipe.pack_message(to_char(:old.cfgfilename));
dbms_pipe.pack_message(to_char(:old.datafiledir));
dbms_pipe.pack_message(to_char(:old.circuitdesc));
dbms_pipe.pack_message(to_char(:old.ismonitor));
dbms_pipe.pack_message(to_char(:old.isstat));
dbms_pipe.pack_message(to_char(:old.circuittypecode));
dbms_pipe.pack_message(to_char(:old.cirendstypecode));
dbms_pipe.pack_message(to_char(:old.recordtime));
dbms_pipe.pack_message(to_char(:old.pingstatus));
dbms_pipe.pack_message(to_char(:old.ifadminstatus));
dbms_pipe.pack_message(to_char(:old.ifoperstatus));
dbms_pipe.pack_message(to_char(:old.opendate));
dbms_pipe.pack_message(to_char(:old.invaliddate));
dbms_pipe.pack_message(to_char(:old.downoccurtime));
dbms_pipe.pack_message(to_char(:old.ipversion));
dbms_pipe.pack_message(to_char(:old.isicmptest));
dbms_pipe.pack_message(to_char(:old.trunklinecode));
dbms_pipe.pack_message(to_char(:old.isqostest));
dbms_pipe.pack_message(to_char(:old.colitemprofile));
dbms_pipe.pack_message(to_char(:old.coltimeplanid));
dbms_pipe.pack_message(to_char(:old.contractbandwidth));
dbms_pipe.pack_message(to_char(:old.bipaddress));
dbms_pipe.pack_message(to_char(:old.isaps));
dbms_pipe.pack_message(to_char(:old.circuitcode));
dbms_pipe.pack_message(to_char(:old.remark));
dbms_pipe.pack_message(to_char(:old.aigpmetric));
dbms_pipe.pack_message(to_char(:old.bigpmetric));
dbms_pipe.pack_message(to_char(:old.circuitchinesename));
dbms_pipe.pack_message(to_char(:old.usestate));
dbms_pipe.pack_message(to_char(:old.isppsmonitor));
    else
        dbms_pipe.pack_message(to_char(:new.circuitid));
dbms_pipe.pack_message(to_char(:new.changetype));
dbms_pipe.pack_message(to_char(:new.circuitname));
dbms_pipe.pack_message(to_char(:new.adeviceid));
dbms_pipe.pack_message(to_char(:new.aintdescr));
dbms_pipe.pack_message(to_char(:new.bdeviceid));
dbms_pipe.pack_message(to_char(:new.bintdescr));
dbms_pipe.pack_message(to_char(:new.cirpropcode));
dbms_pipe.pack_message(to_char(:new.transtypecode));
dbms_pipe.pack_message(to_char(:new.transcircode));
dbms_pipe.pack_message(to_char(:new.bandwidth));
dbms_pipe.pack_message(to_char(:new.cfgfilename));
dbms_pipe.pack_message(to_char(:new.datafiledir));
dbms_pipe.pack_message(to_char(:new.circuitdesc));
dbms_pipe.pack_message(to_char(:new.ismonitor));
dbms_pipe.pack_message(to_char(:new.isstat));
dbms_pipe.pack_message(to_char(:new.circuittypecode));
dbms_pipe.pack_message(to_char(:new.cirendstypecode));
dbms_pipe.pack_message(to_char(:new.recordtime));
dbms_pipe.pack_message(to_char(:new.pingstatus));
dbms_pipe.pack_message(to_char(:new.ifadminstatus));
dbms_pipe.pack_message(to_char(:new.ifoperstatus));
dbms_pipe.pack_message(to_char(:new.opendate));
dbms_pipe.pack_message(to_char(:new.invaliddate));
dbms_pipe.pack_message(to_char(:new.downoccurtime));
dbms_pipe.pack_message(to_char(:new.ipversion));
dbms_pipe.pack_message(to_char(:new.isicmptest));
dbms_pipe.pack_message(to_char(:new.trunklinecode));
dbms_pipe.pack_message(to_char(:new.isqostest));
dbms_pipe.pack_message(to_char(:new.colitemprofile));
dbms_pipe.pack_message(to_char(:new.coltimeplanid));
dbms_pipe.pack_message(to_char(:new.contractbandwidth));
dbms_pipe.pack_message(to_char(:new.bipaddress));
dbms_pipe.pack_message(to_char(:new.isaps));
dbms_pipe.pack_message(to_char(:new.circuitcode));
dbms_pipe.pack_message(to_char(:new.remark));
dbms_pipe.pack_message(to_char(:new.aigpmetric));
dbms_pipe.pack_message(to_char(:new.bigpmetric));
dbms_pipe.pack_message(to_char(:new.circuitchinesename));
dbms_pipe.pack_message(to_char(:new.usestate));
dbms_pipe.pack_message(to_char(:new.isppsmonitor));
    end if;

    -- ????
    l_result := dbms_pipe.send_message(l_pipename,0,102400);

    -- ?????????PIPE
    if (l_result = 1) then
        dbms_pipe.purge(l_pipename);
    end if;

exception
    when others then
        null;
end;
/
