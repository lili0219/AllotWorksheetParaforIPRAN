CREATE TRIGGER TRG_CIRCUIT
AFTER INSERT OR UPDATE OF CIRCUITID, CHANGETYPE, CIRCUITNAME, ADEVICEID, AINTDESCR, BDEVICEID, BINTDESCR, CIRPROPCODE, CIRCUITTYPECODE OR DELETE
  ON CIRCUIT
FOR EACH ROW WHEN (FOR EACH ROW )
DECLARE
   l_nodecodea    res.nodecodea%TYPE;
   l_nodecodeb    res.nodecodeb%TYPE;
   l_ipaddressa   res.ipaddressa%TYPE;
   l_ipaddressb   res.ipaddressb%TYPE;
BEGIN
   /*?????????????IP??*/
   IF (:NEW.changetype = 0)
   THEN
      /*??A????IP??*/
      BEGIN
         SELECT nodecode
           INTO l_nodecodea
           FROM device
          WHERE deviceid = :NEW.adeviceid AND changetype = 0;
      EXCEPTION
         WHEN NO_DATA_FOUND
         THEN
            l_nodecodea := NULL;
      END;

      BEGIN
         IF (UPPER (:NEW.ipversion) = 'IPV6')
         THEN
            SELECT ipaddress
              INTO l_ipaddressa
              FROM ipv6devaddr
             WHERE deviceid = :NEW.adeviceid
               AND intdescr = :NEW.aintdescr
               AND changetype = 0
               AND seqnum = 0;
         ELSE
            SELECT ipaddress
              INTO l_ipaddressa
              FROM devaddr
             WHERE deviceid = :NEW.adeviceid
               AND intdescr = :NEW.aintdescr
               AND changetype = 0
               AND seqnum = 0;
         END IF;
      EXCEPTION
         WHEN NO_DATA_FOUND
         THEN
            l_ipaddressa := NULL;
      END;

      /*??B????IP??*/
      IF (:NEW.bdeviceid IS NOT NULL)
      THEN
         BEGIN
            SELECT nodecode
              INTO l_nodecodeb
              FROM device
             WHERE deviceid = :NEW.bdeviceid AND changetype = 0;
         EXCEPTION
            WHEN NO_DATA_FOUND
            THEN
               l_nodecodeb := NULL;
         END;

         BEGIN
            IF (UPPER (:NEW.ipversion) = 'IPV6')
            THEN
               SELECT ipaddress
                 INTO l_ipaddressb
                 FROM ipv6devaddr
                WHERE deviceid = :NEW.bdeviceid
                  AND intdescr = :NEW.bintdescr
                  AND changetype = 0
                  AND seqnum = 0;
            ELSE
               SELECT ipaddress
                 INTO l_ipaddressb
                 FROM devaddr
                WHERE deviceid = :NEW.bdeviceid
                  AND intdescr = :NEW.bintdescr
                  AND changetype = 0
                  AND seqnum = 0;
            END IF;
         EXCEPTION
            WHEN NO_DATA_FOUND
            THEN
               l_ipaddressb := NULL;
         END;
      ELSE
         l_nodecodeb := NULL;
         l_ipaddressb := NULL;
      END IF;
   END IF;

   /*??????*/
   IF (INSERTING OR (UPDATING AND :NEW.changetype = 0 AND :OLD.changetype != 0)
      )
   THEN
      /*????*/
      BEGIN
         INSERT INTO res
                     (resid, resname,
                      restypeid, nodecodea, nodecodeb,
                      ipaddressa, ipaddressb, resprop
                     )
              VALUES (:NEW.circuitid, :NEW.circuitname,
                      :NEW.circuittypecode, l_nodecodea, l_nodecodeb,
                      l_ipaddressa, l_ipaddressb, :NEW.cirpropcode
                     );
      EXCEPTION
         WHEN OTHERS
         THEN
            UPDATE res
               SET resname = :NEW.circuitname,
                   restypeid = :NEW.circuittypecode,
                   nodecodea = l_nodecodea,
                   nodecodeb = l_nodecodeb,
                   ipaddressa = l_ipaddressa,
                   ipaddressb = l_ipaddressb,
                   resprop = :NEW.cirpropcode
             WHERE resid = :NEW.circuitid;
      END;
   /*??????*/
   ELSIF (UPDATING AND :NEW.changetype = 0 AND :OLD.changetype = 0)
   THEN
      UPDATE res
         SET resid = :NEW.circuitid,
             resname = :NEW.circuitname,
             restypeid = :NEW.circuittypecode,
             nodecodea = l_nodecodea,
             nodecodeb = l_nodecodeb,
             ipaddressa = l_ipaddressa,
             ipaddressb = l_ipaddressb,
             resprop = :NEW.cirpropcode
       WHERE resid = :OLD.circuitid;
   /*??????*/
   ELSIF (   DELETING
          OR (UPDATING AND :NEW.changetype != 0 AND :OLD.changetype = 0)
         )
   THEN
      DELETE      res
            WHERE resid = :OLD.circuitid;
   END IF;
END;
/
