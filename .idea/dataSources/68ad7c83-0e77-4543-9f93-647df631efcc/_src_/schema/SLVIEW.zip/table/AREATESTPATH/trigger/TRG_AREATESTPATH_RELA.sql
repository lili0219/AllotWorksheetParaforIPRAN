CREATE TRIGGER TRG_AREATESTPATH_RELA
AFTER INSERT OR UPDATE OF CITYNAME, CHANGETYPE, STARTROUTERCODE OR DELETE
  ON AREATESTPATH
FOR EACH ROW
  BEGIN

    /*????????*/
    IF (INSERTING AND :NEW.ChangeType=0) THEN
        /*????*/
        BEGIN
        INSERT INTO RESRELATION (ARESID, ARESPARA, ARESCLASSID,BRESID, BRESPARA, BRESNAME,BRESCLASSNAME, RELATYPE)
        VALUES ( :NEW.StartRouterCode, '-1','DEV' , :NEW.CityCode, '-1', :NEW.CityName,'????' , 'REFERED');
        EXCEPTION
            WHEN OTHERS THEN
                UPDATE RESRELATION
                SET BRESNAME = :NEW.CityName
                WHERE BResID=:OLD.CityCode;
        END ;
    /*????????*/
    ELSIF (DELETING OR (UPDATING AND :NEW.changetype = -1 AND :OLD.changetype=0)) THEN
      DELETE FROM RESRELATION WHERE BResID=:OLD.CityCode;
     /*????????*/
     ELSIF (UPDATING AND :NEW.changetype = 0 AND :OLD.changetype = 0) THEN
        BEGIN
        /*??????*/
        DELETE FROM RESRELATION WHERE BResID=:OLD.CityCode;
        /*??????*/
        INSERT INTO RESRELATION (ARESID, ARESPARA, ARESCLASSID,BRESID, BRESPARA, BRESNAME,BRESCLASSNAME, RELATYPE)
        VALUES ( :NEW.StartRouterCode, '-1','DEV' , :NEW.CityCode, '-1', :NEW.CityName,'????' , 'REFERED');
        EXCEPTION
            WHEN OTHERS THEN
                UPDATE RESRELATION
                SET BRESNAME = :NEW.CityName
                WHERE BResID=:OLD.CityCode;
        END ;
    END IF;
END ;
/
