CREATE TRIGGER TRG_AREATESTPATH
AFTER INSERT OR UPDATE OF CITYCODE, CITYNAME, CHANGETYPE, STARTROUTERCODE, DESTIP OR DELETE
  ON AREATESTPATH
FOR EACH ROW WHEN (FOR EACH ROW )
declare
    l_nodecodea res.nodecodea%type;
    l_nodecodeb res.nodecodeb%type;
    l_ipaddressa res.ipaddressa%type;
    l_ipaddressb res.ipaddressb%type;
begin
    /*?????????????IP??*/
    if (:new.changetype = 0) then
        /*??A????IP??*/
        begin
            select nodecode,loopaddress into l_nodecodea,l_ipaddressa
            from device
            where deviceid = :new.startroutercode
                and changetype = 0 ;
        exception
            when no_data_found then
                l_nodecodea := null;
                l_ipaddressa := null;
        end ;

        /*??B????IP??*/
        l_nodecodeb := null;
        l_ipaddressb := :new.destip;
    end if;

    /*??????*/
    if (inserting or (updating and :new.changetype = 0 and :old.changetype!=0)) then
        begin
            insert into res(resid,resname,restypeid,nodecodea,nodecodeb,ipaddressa,ipaddressb)
            values (:new.citycode,:new.cityname,'CTY_COM',l_nodecodea,l_nodecodeb,l_ipaddressa,l_ipaddressb);
        exception
            when others then
                update res
                set resname = :new.cityname,
                    restypeid = 'CTY_COM',
                    nodecodea = l_nodecodea,
                    nodecodeb = l_nodecodeb,
                    ipaddressa = l_ipaddressa,
                    ipaddressb = l_ipaddressb
                where resid = :new.citycode ;
        end ;
     /*??????*/
     elsif (updating and :new.changetype = 0 and :old.changetype=0) then
        update res
        set resid = :new.citycode,
            resname = :new.cityname,
            restypeid = 'CTY_COM',
            nodecodea = l_nodecodea,
            nodecodeb = l_nodecodeb,
            ipaddressa = l_ipaddressa,
            ipaddressb = l_ipaddressb
        where resid = :old.citycode ;
    /*??????*/
    elsif (deleting or (updating and :new.changetype != 0 and :old.changetype=0)) then
        delete res where resid = :old.citycode ;
    end if;
end ;
/
