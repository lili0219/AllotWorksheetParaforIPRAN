CREATE TRIGGER TRG_CE
AFTER INSERT OR UPDATE OR DELETE
  ON CE
FOR EACH ROW
  DECLARE
    l_changetype ISCIDMAPPING.CHANGE_TYPE%TYPE;
    l_hasdata    CHAR;
BEGIN
     BEGIN
            SELECT CHANGE_TYPE INTO l_changetype
            FROM ISCIDMAPPING
            WHERE VPN_RES_ID = :NEW.CEID AND RES_TYPE='CE';
     EXCEPTION
            WHEN NO_DATA_FOUND THEN
                l_changetype := 'N' ;
     END ;
     --????ISCIDMAPPING?????
    IF(INSERTING AND l_changetype = 'N') THEN
        INSERT INTO ISCIDMAPPING ( VPN_RES_ID, RES_TYPE, ISC_RES_ID, ISC_RES_NAME,CHANGE_TYPE )
        VALUES (:NEW.CEID, 'CE', '', '', 'A');
        --??CE
        IF(:NEW.ismanaged = 'Y') THEN
          BEGIN
            SELECT CHANGE_TYPE INTO l_hasdata
            FROM ISCIDMAPPING
            WHERE VPN_RES_ID = :NEW.DEVICEID AND RES_TYPE='DEVICE';
            EXCEPTION
            WHEN NO_DATA_FOUND THEN
                l_hasdata := 'N' ;
          END ;
          IF(l_hasdata = 'N') THEN
              INSERT INTO ISCIDMAPPING ( VPN_RES_ID, RES_TYPE, ISC_RES_ID, ISC_RES_NAME,CHANGE_TYPE )
              VALUES (:NEW.DEVICEID, 'DEVICE', '', '', 'A');
          ELSE
              UPDATE ISCIDMAPPING SET CHANGE_TYPE = 'M' WHERE VPN_RES_ID = :NEW.DEVICEID AND RES_TYPE='DEVICE';
          END IF;
        ELSE
           INSERT INTO ISCIDMAPPING ( VPN_RES_ID, RES_TYPE, ISC_RES_ID, ISC_RES_NAME,CHANGE_TYPE )
           VALUES (:NEW.CEID, 'DEVICE', '', '', 'A');
        END IF;
    --????ISCIDMAPPING????
    ELSIF(INSERTING AND l_changetype <> 'N') THEN
        UPDATE ISCIDMAPPING SET CHANGE_TYPE = 'M' WHERE VPN_RES_ID = :NEW.CEID AND RES_TYPE='CE';
        IF(:OLD.ismanaged = 'Y') THEN
              UPDATE ISCIDMAPPING SET CHANGE_TYPE = 'M' WHERE VPN_RES_ID = :NEW.DEVICEID AND RES_TYPE='DEVICE';
            ELSE
              UPDATE ISCIDMAPPING SET CHANGE_TYPE = 'M' WHERE VPN_RES_ID = :NEW.CEID AND RES_TYPE='DEVICE';
         END IF;
    ELSIF(DELETING) THEN
        BEGIN
            SELECT CHANGE_TYPE INTO l_changetype
            FROM ISCIDMAPPING
            WHERE VPN_RES_ID = :OLD.CEID AND RES_TYPE='CE';
        EXCEPTION
            WHEN NO_DATA_FOUND THEN
                l_changetype := 'N' ;
        END ;
        --?????????????
        IF (l_changetype = 'A') THEN
            DELETE FROM ISCIDMAPPING WHERE VPN_RES_ID = :OLD.CEID AND RES_TYPE='CE' ;
            IF(:OLD.ismanaged = 'Y') THEN
              DELETE FROM ISCIDMAPPING WHERE VPN_RES_ID = :OLD.DEVICEID AND RES_TYPE='DEVICE';
            ELSE
              DELETE FROM ISCIDMAPPING WHERE VPN_RES_ID = :OLD.CEID AND RES_TYPE='DEVICE';
            END IF;
        --?????????????????????
        ELSIF (l_changetype <> 'N' OR l_changetype IS NULL) THEN
            UPDATE ISCIDMAPPING SET CHANGE_TYPE = 'D' WHERE VPN_RES_ID = :OLD.CEID AND RES_TYPE='CE' ;
            IF(:OLD.ismanaged = 'Y') THEN
              UPDATE ISCIDMAPPING SET CHANGE_TYPE = 'D' WHERE VPN_RES_ID = :OLD.DEVICEID AND RES_TYPE='DEVICE';
            ELSE
              UPDATE ISCIDMAPPING SET CHANGE_TYPE = 'D' WHERE VPN_RES_ID = :OLD.CEID AND RES_TYPE='DEVICE';
            END IF;
        END IF;
    ELSIF(UPDATING) THEN
      --????????  ???????? ???
      --IF (:OLD.ismanaged = 'N' AND :NEW.ismanaged = 'N') THEN
         --???????
      --   IF (l_changetype <> 'A' AND l_changetype <> 'N') OR (l_changetype IS NULL) THEN
      --      UPDATE ISCIDMAPPING SET CHANGE_TYPE='M' WHERE VPN_RES_ID=:NEW.CEID AND RES_TYPE='CE' ;
      --      UPDATE ISCIDMAPPING SET CHANGE_TYPE = 'M' WHERE VPN_RES_ID = :NEW.CEID AND RES_TYPE='DEVICE';
      --   END IF;
      --END IF;
      --??????
      IF (:OLD.ismanaged = 'Y' AND :NEW.ismanaged = 'Y') THEN
         --???????
         IF (l_changetype <> 'A' AND l_changetype <> 'N') OR (l_changetype IS NULL) THEN
            UPDATE ISCIDMAPPING SET CHANGE_TYPE='M' WHERE VPN_RES_ID=:NEW.CEID AND RES_TYPE='CE' ;
            UPDATE ISCIDMAPPING SET CHANGE_TYPE = 'D' WHERE VPN_RES_ID = :OLD.DEVICEID AND RES_TYPE='DEVICE';
            INSERT INTO ISCIDMAPPING ( VPN_RES_ID, RES_TYPE, ISC_RES_ID, ISC_RES_NAME,CHANGE_TYPE )
                    VALUES (:NEW.DEVICEID, 'DEVICE', '', '', 'A');
         ELSE
            DELETE FROM ISCIDMAPPING WHERE VPN_RES_ID = :OLD.DEVICEID AND RES_TYPE='DEVICE';
            INSERT INTO ISCIDMAPPING ( VPN_RES_ID, RES_TYPE, ISC_RES_ID, ISC_RES_NAME,CHANGE_TYPE )
                    VALUES (:NEW.DEVICEID, 'DEVICE', '', '', 'A');
         END IF;
      END IF;

      --???????
      IF (:OLD.ismanaged = 'Y' AND :NEW.ismanaged = 'N') THEN
         --???????
         IF (l_changetype <> 'A' AND l_changetype <> 'N') OR (l_changetype IS NULL) THEN
            UPDATE ISCIDMAPPING SET CHANGE_TYPE='M' WHERE VPN_RES_ID=:NEW.CEID AND RES_TYPE='CE' ;
            UPDATE ISCIDMAPPING SET CHANGE_TYPE = 'D' WHERE VPN_RES_ID = :OLD.DEVICEID AND RES_TYPE='DEVICE';
            INSERT INTO ISCIDMAPPING ( VPN_RES_ID, RES_TYPE, ISC_RES_ID, ISC_RES_NAME,CHANGE_TYPE )
                    VALUES (:NEW.CEID, 'DEVICE', '', '', 'A');
         ELSE
            DELETE FROM ISCIDMAPPING WHERE VPN_RES_ID = :OLD.DEVICEID AND RES_TYPE='DEVICE';
            INSERT INTO ISCIDMAPPING ( VPN_RES_ID, RES_TYPE, ISC_RES_ID, ISC_RES_NAME,CHANGE_TYPE )
                    VALUES (:NEW.CEID, 'DEVICE', '', '', 'A');
         END IF;
      END IF;
      --???????
      IF (:OLD.ismanaged = 'N' AND :NEW.ismanaged = 'Y') THEN
         --???????
         IF (l_changetype <> 'A' AND l_changetype <> 'N') OR (l_changetype IS NULL) THEN
            UPDATE ISCIDMAPPING SET CHANGE_TYPE='M' WHERE VPN_RES_ID=:NEW.CEID AND RES_TYPE='CE' ;
            UPDATE ISCIDMAPPING SET CHANGE_TYPE = 'D' WHERE VPN_RES_ID = :OLD.CEID AND RES_TYPE='DEVICE';
            INSERT INTO ISCIDMAPPING ( VPN_RES_ID, RES_TYPE, ISC_RES_ID, ISC_RES_NAME,CHANGE_TYPE )
                    VALUES (:NEW.DEVICEID, 'DEVICE', '', '', 'A');
         ELSE
            DELETE FROM ISCIDMAPPING WHERE VPN_RES_ID = :OLD.CEID AND RES_TYPE='DEVICE';
            INSERT INTO ISCIDMAPPING ( VPN_RES_ID, RES_TYPE, ISC_RES_ID, ISC_RES_NAME,CHANGE_TYPE )
                    VALUES (:NEW.DEVICEID, 'DEVICE', '', '', 'A');
         END IF;
      END IF;
    END IF;
END ;
/
