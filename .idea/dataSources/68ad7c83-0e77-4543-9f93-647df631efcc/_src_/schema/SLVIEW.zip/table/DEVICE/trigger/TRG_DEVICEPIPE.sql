CREATE TRIGGER TRG_DEVICEPIPE
AFTER INSERT OR UPDATE OR DELETE
  ON DEVICE
FOR EACH ROW
  declare
    l_username varchar2(30);
    l_pipename varchar2(40);
    l_result pls_integer;

begin
    -- ?????
    select username into l_username from user_users;

    --??????PIPE??
    l_pipename :=  'DEVICE_' || l_username;
    dbms_pipe.reset_buffer ;
    dbms_pipe.pack_message('device');
    -- ????
    if inserting then
        dbms_pipe.pack_message('add');
    elsif updating then
        dbms_pipe.pack_message('modify');
    else
        dbms_pipe.pack_message('delete');
    end if;

    -- ??????
    if deleting then
        dbms_pipe.pack_message(to_char(:old.deviceid));
dbms_pipe.pack_message(to_char(:old.changetype));
dbms_pipe.pack_message(to_char(:old.devicename));
dbms_pipe.pack_message(to_char(:old.loopaddress));
dbms_pipe.pack_message(to_char(:old.devicetypecode));
dbms_pipe.pack_message(to_char(:old.devicemodelcode));
dbms_pipe.pack_message(to_char(:old.detailmodelcode));
dbms_pipe.pack_message(to_char(:old.devicepropcode));
dbms_pipe.pack_message(to_char(:old.osversion));
dbms_pipe.pack_message(to_char(:old.snmpversion));
dbms_pipe.pack_message(to_char(:old.snmpusername));
dbms_pipe.pack_message(to_char(:old.snmpauthprotocol));
dbms_pipe.pack_message(to_char(:old.snmpauthpassword));
dbms_pipe.pack_message(to_char(:old.snmpprivprotocol));
dbms_pipe.pack_message(to_char(:old.rocommunity));
dbms_pipe.pack_message(to_char(:old.rwcommunity));
dbms_pipe.pack_message(to_char(:old.username));
dbms_pipe.pack_message(to_char(:old.password));
dbms_pipe.pack_message(to_char(:old.ftpusername));
dbms_pipe.pack_message(to_char(:old.ftppassword));
dbms_pipe.pack_message(to_char(:old.prompt));
dbms_pipe.pack_message(to_char(:old.groupno));
dbms_pipe.pack_message(to_char(:old.isnew));
dbms_pipe.pack_message(to_char(:old.nodecode));
dbms_pipe.pack_message(to_char(:old.cfgfilename));
dbms_pipe.pack_message(to_char(:old.cfgfiledir));
dbms_pipe.pack_message(to_char(:old.moniflag));
dbms_pipe.pack_message(to_char(:old.pingstatus));
dbms_pipe.pack_message(to_char(:old.snmpgetstatus));
dbms_pipe.pack_message(to_char(:old.snmpsetstatus));
dbms_pipe.pack_message(to_char(:old.lastchecktime));
dbms_pipe.pack_message(to_char(:old.confirmtime));
dbms_pipe.pack_message(to_char(:old.opendate));
dbms_pipe.pack_message(to_char(:old.invaliddate));
dbms_pipe.pack_message(to_char(:old.downoccurtime));
dbms_pipe.pack_message(to_char(:old.remark));
dbms_pipe.pack_message(to_char(:old.snmpprivpassword));
dbms_pipe.pack_message(to_char(:old.isipv6dev));
dbms_pipe.pack_message(to_char(:old.logintype));
dbms_pipe.pack_message(to_char(:old.enablepasswd));
dbms_pipe.pack_message(to_char(:old.colitemprofile));
dbms_pipe.pack_message(to_char(:old.iscfgfilebak));
dbms_pipe.pack_message(to_char(:old.coltimeplanid));
dbms_pipe.pack_message(to_char(:old.mgmttype));
dbms_pipe.pack_message(to_char(:old.pingpkgsize));
dbms_pipe.pack_message(to_char(:old.pingpkgnum));
dbms_pipe.pack_message(to_char(:old.pingtimeout));
    else
        dbms_pipe.pack_message(to_char(:new.deviceid));
dbms_pipe.pack_message(to_char(:new.changetype));
dbms_pipe.pack_message(to_char(:new.devicename));
dbms_pipe.pack_message(to_char(:new.loopaddress));
dbms_pipe.pack_message(to_char(:new.devicetypecode));
dbms_pipe.pack_message(to_char(:new.devicemodelcode));
dbms_pipe.pack_message(to_char(:new.detailmodelcode));
dbms_pipe.pack_message(to_char(:new.devicepropcode));
dbms_pipe.pack_message(to_char(:new.osversion));
dbms_pipe.pack_message(to_char(:new.snmpversion));
dbms_pipe.pack_message(to_char(:new.snmpusername));
dbms_pipe.pack_message(to_char(:new.snmpauthprotocol));
dbms_pipe.pack_message(to_char(:new.snmpauthpassword));
dbms_pipe.pack_message(to_char(:new.snmpprivprotocol));
dbms_pipe.pack_message(to_char(:new.rocommunity));
dbms_pipe.pack_message(to_char(:new.rwcommunity));
dbms_pipe.pack_message(to_char(:new.username));
dbms_pipe.pack_message(to_char(:new.password));
dbms_pipe.pack_message(to_char(:new.ftpusername));
dbms_pipe.pack_message(to_char(:new.ftppassword));
dbms_pipe.pack_message(to_char(:new.prompt));
dbms_pipe.pack_message(to_char(:new.groupno));
dbms_pipe.pack_message(to_char(:new.isnew));
dbms_pipe.pack_message(to_char(:new.nodecode));
dbms_pipe.pack_message(to_char(:new.cfgfilename));
dbms_pipe.pack_message(to_char(:new.cfgfiledir));
dbms_pipe.pack_message(to_char(:new.moniflag));
dbms_pipe.pack_message(to_char(:new.pingstatus));
dbms_pipe.pack_message(to_char(:new.snmpgetstatus));
dbms_pipe.pack_message(to_char(:new.snmpsetstatus));
dbms_pipe.pack_message(to_char(:new.lastchecktime));
dbms_pipe.pack_message(to_char(:new.confirmtime));
dbms_pipe.pack_message(to_char(:new.opendate));
dbms_pipe.pack_message(to_char(:new.invaliddate));
dbms_pipe.pack_message(to_char(:new.downoccurtime));
dbms_pipe.pack_message(to_char(:new.remark));
dbms_pipe.pack_message(to_char(:new.snmpprivpassword));
dbms_pipe.pack_message(to_char(:new.isipv6dev));
dbms_pipe.pack_message(to_char(:new.logintype));
dbms_pipe.pack_message(to_char(:new.enablepasswd));
dbms_pipe.pack_message(to_char(:new.colitemprofile));
dbms_pipe.pack_message(to_char(:new.iscfgfilebak));
dbms_pipe.pack_message(to_char(:new.coltimeplanid));
dbms_pipe.pack_message(to_char(:new.mgmttype));
dbms_pipe.pack_message(to_char(:new.pingpkgsize));
dbms_pipe.pack_message(to_char(:new.pingpkgnum));
dbms_pipe.pack_message(to_char(:new.pingtimeout));
    end if;

    -- ????
    l_result := dbms_pipe.send_message(l_pipename,0,10240);

    -- ?????????PIPE
    if (l_result = 1) then
        dbms_pipe.purge(l_pipename);
    end if;

exception
    when others then
        null;
end;
/
