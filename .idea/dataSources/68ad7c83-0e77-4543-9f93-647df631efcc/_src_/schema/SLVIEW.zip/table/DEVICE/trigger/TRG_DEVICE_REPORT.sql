CREATE TRIGGER TRG_DEVICE_REPORT
AFTER INSERT OR UPDATE OF CHANGETYPE, DEVICENAME, DETAILMODELCODE, DEVICEPROPCODE, NODECODE OR DELETE
  ON DEVICE
FOR EACH ROW WHEN (FOR EACH ROW )
DECLARE
       --?????????tagtreenode?cursor
       --TYPE devtagtreenode_cursor IS REF CURSOR;

       CURSOR devtagtreenode_cursor IS
           SELECT distinct m1.tagtreenodecode,ttc.tagtreenodefullcode
           FROM Node n,ReportResMatchRule m1,ReportResMatchRule m2,ReportResMatchRule m3,ReportResMatchRule m4,ReportResMatchRule m5,TagTreeCfg ttc
           WHERE m1.matchattribute='DevicePropCode'
             AND (:NEW.devicepropcode = m1.matchvalue OR m1.matchvalue = ' ')
             AND m1.tagtreenodecode=m2.tagtreenodecode
             AND m2.matchattribute='DetailModelCode'
             AND regexp_like(NVL(:NEW.detailmodelcode, ',,,'), m2.matchvalue)
             AND m1.tagtreenodecode=m3.tagtreenodecode
             AND m3.matchattribute='DeviceName'
             AND regexp_like(:NEW.devicename,m3.matchvalue)
             AND m1.tagtreenodecode=m4.tagtreenodecode
             AND m4.matchattribute='NodeCode'
             AND :NEW.nodecode=n.nodecode
             AND n.nodefullcode like '%' || m4.matchvalue || '%'
             AND m5.matchattribute='Vendor'
             AND (INSTR(:NEW.Devicemodelcode,'_'||m5.matchvalue||'_')>0  OR m5.matchvalue = ' ')
             AND m1.tagtreenodecode = m5.tagtreenodecode
             AND m1.tagtreenodecode=ttc.tagtreenodecode;
       --????devtagtreenode_val??devtagtreenode_cursor?????
       devtagtreenode_val devtagtreenode_cursor%ROWTYPE;
       --???????????????????????????????(??????true????false)
       ifValidUpdate BOOLEAN;
BEGIN
     --??device??DELETE???????????TagTreeNodeCode_Res???????
     IF (DELETING OR (:OLD.changetype = 0 AND :NEW.changetype != 0)) THEN
        DELETE FROM TagTreeNodeCode_Res ttnr WHERE ttnr.resid=:OLD.deviceid;
     ELSE   --INSERT?UPDATE??
        ifValidUpdate := FALSE;--???

         --??TagTreeNodeCode_Res??????????????tagtreenode??
         --UPDATE??
         IF UPDATING THEN
            --?????????????????????????????
            IF (
                  :OLD.devicename != :NEW.devicename
               OR :OLD.devicepropcode != :NEW.devicepropcode
               OR :OLD.detailmodelcode != :NEW.detailmodelcode
               OR :OLD.nodecode != :NEW.nodecode
               ) THEN
                  --?????
                  ifValidUpdate := TRUE;
                  --???TagTreeNodeCode_Res???????????????tagtreenode??
                  DELETE
                  FROM TagTreeNodeCode_Res ttnr
                  WHERE ttnr.resid = :NEW.deviceid
                  AND EXISTS(
                             SELECT rrmr.TagTreeNodeCode
                             FROM ReportResMatchRule rrmr
                             WHERE rrmr.tagtreenodecode=ttnr.tagtreenodecode
                             );
              END IF;
         END IF;

         --??TagTreeNodeCode_Res?????????????tagtreenode??
         --??INSERT????UPDATE??
         IF INSERTING OR ifValidUpdate THEN
               --???deviceid???tagtreenodecode?tagtreenodefullcode??(tagtreenodecode???)
               --OPEN devtagtreenode_cursor;
               OPEN devtagtreenode_cursor;
               LOOP
                 FETCH devtagtreenode_cursor INTO devtagtreenode_val;
                 EXIT WHEN devtagtreenode_cursor%NOTFOUND;
                   --deviceid???tagtreenodecode?????TagTreeNodeCode_Res??
                   INSERT INTO TagTreeNodeCode_Res(tagtreenodecode, resid, operrela, remark, tagtreenodefullcode)
                   VALUES(devtagtreenode_val.tagtreenodecode, :NEW.deviceid, NULL, NULL, devtagtreenode_val.tagtreenodefullcode);
               END LOOP;
               CLOSE devtagtreenode_cursor;
         END IF;

     END IF;
END;
/
