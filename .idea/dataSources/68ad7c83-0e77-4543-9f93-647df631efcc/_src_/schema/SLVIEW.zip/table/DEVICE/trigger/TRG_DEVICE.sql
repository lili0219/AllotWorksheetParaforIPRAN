CREATE TRIGGER TRG_DEVICE
AFTER INSERT OR UPDATE OF DEVICEID, CHANGETYPE, DEVICENAME, LOOPADDRESS, DEVICETYPECODE, DEVICEMODELCODE, DEVICEPROPCODE, NODECODE, REMARK OR DELETE
  ON DEVICE
FOR EACH ROW WHEN (FOR EACH ROW )
DECLARE
   l_caschange   NUMBER;
   l_hastable    NUMBER;

   TYPE rescurtyp IS REF CURSOR;

   l_rescur      rescurtyp;
   l_resid       res.resid%TYPE;
   l_vendor      devicemodel.vendor%TYPE;
BEGIN
   /*????ID,??,IP??????????????????*/
   IF (    :OLD.changetype = :NEW.changetype
       AND :OLD.deviceid = :NEW.deviceid
       AND :OLD.loopaddress = :NEW.loopaddress
       AND :OLD.nodecode = :NEW.nodecode
      )
   THEN
      l_caschange := 0;
   ELSE
      l_caschange := 1;
   END IF;

   /*?????*/
   IF ((:OLD.changetype = 0) and (nvl(:NEW.changetype,1) <> 0))
   THEN
      DELETE      res
            WHERE resid = :OLD.deviceid;

      /*?????????IP?????*/
      IF (l_caschange = 1)
      THEN
         /*??*/
         BEGIN
            SELECT 1
              INTO l_hastable
              FROM user_tables
             WHERE table_name = 'PATH';
         EXCEPTION
            WHEN NO_DATA_FOUND
            THEN
               l_hastable := 0;
         END;

         IF (l_hastable = 1)
         THEN
            OPEN l_rescur FOR 'select a.pathid  from path a,endpoint b
                                where a.startpointid = b.endpointid  and a.changetype = 0
                                    and b.changetype = 0  and b.deviceid = :1 '
            USING :OLD.deviceid;

            LOOP
               FETCH l_rescur
                INTO l_resid;

               EXIT WHEN l_rescur%NOTFOUND;

               UPDATE res
                  SET nodecodea = NULL,
                      ipaddressa = NULL
                WHERE resid = l_resid;
            END LOOP;

            CLOSE l_rescur;

            OPEN l_rescur FOR 'select a.pathid from path a,endpoint b
                            where a.endpointid = b.endpointid  and a.changetype = 0
                                and b.changetype = 0  and b.deviceid = :1 '
            USING :OLD.deviceid;

            LOOP
               FETCH l_rescur
                INTO l_resid;

               EXIT WHEN l_rescur%NOTFOUND;

               UPDATE res
                  SET nodecodeb = NULL,
                      ipaddressb = NULL
                WHERE resid = l_resid;
            END LOOP;
         END IF;

         /*bge??*/
         BEGIN
            SELECT 1
              INTO l_hastable
              FROM user_tables
             WHERE table_name = 'BGPNEICFG';
         EXCEPTION
            WHEN NO_DATA_FOUND
            THEN
               l_hastable := 0;
         END;

         IF (l_hastable = 1)
         THEN
            OPEN l_rescur FOR 'select a.neiid from bgpneicfg a
                            where a.changetype = 0 and a.deviceid = :1 '
            USING :OLD.deviceid;

            LOOP
               FETCH l_rescur
                INTO l_resid;

               EXIT WHEN l_rescur%NOTFOUND;

               UPDATE res
                  SET nodecodea = NULL,
                      ipaddressa = NULL
                WHERE resid = l_resid;
            END LOOP;

            CLOSE l_rescur;
         END IF;

         /*traceroute*/
         BEGIN
            SELECT 1
              INTO l_hastable
              FROM user_tables
             WHERE table_name = 'TRACEROUTECFG';
         EXCEPTION
            WHEN NO_DATA_FOUND
            THEN
               l_hastable := 0;
         END;

         IF (l_hastable = 1)
         THEN
            OPEN l_rescur FOR 'select a.routeid from traceroutecfg a
                            where a.changetype = 0 and a.deviceid = :1 '
            USING :OLD.deviceid;

            LOOP
               FETCH l_rescur
                INTO l_resid;

               EXIT WHEN l_rescur%NOTFOUND;

               UPDATE res
                  SET nodecodea = NULL,
                      ipaddressa = NULL
                WHERE resid = l_resid;
            END LOOP;

            CLOSE l_rescur;
         END IF;

         /*tunnel*/
         BEGIN
            SELECT 1
              INTO l_hastable
              FROM user_tables
             WHERE table_name = 'MPLSTETINFO';
         EXCEPTION
            WHEN NO_DATA_FOUND
            THEN
               l_hastable := 0;
         END;

         IF (l_hastable = 1)
         THEN
            OPEN l_rescur FOR 'select a.tetid from mplstetinfo a
                            where a.changetype = 0 and a.adeviceid = :1 '
            USING :OLD.deviceid;

            LOOP
               FETCH l_rescur
                INTO l_resid;

               EXIT WHEN l_rescur%NOTFOUND;

               UPDATE res
                  SET nodecodea = NULL
                WHERE resid = l_resid;
            END LOOP;

            CLOSE l_rescur;
         END IF;

         /*????*/
         BEGIN
            SELECT 1
              INTO l_hastable
              FROM user_tables
             WHERE table_name = 'AREATESTPATH';
         EXCEPTION
            WHEN NO_DATA_FOUND
            THEN
               l_hastable := 0;
         END;

         IF (l_hastable = 1)
         THEN
            OPEN l_rescur FOR 'select a.citycode from areatestpath a
                            where a.changetype = 0 and a.startroutercode = :1 '
            USING :OLD.deviceid;

            LOOP
               FETCH l_rescur
                INTO l_resid;

               EXIT WHEN l_rescur%NOTFOUND;

               UPDATE res
                  SET nodecodea = NULL,
                      ipaddressa = NULL
                WHERE resid = l_resid;
            END LOOP;

            CLOSE l_rescur;
         END IF;

         /*??*/
         /*A?*/
         FOR l_rec IN (SELECT a.circuitid resid
                         FROM circuit a
                        WHERE a.changetype = 0 AND a.adeviceid = :OLD.deviceid)
         LOOP
            UPDATE res
               SET nodecodea = NULL
             WHERE resid = l_rec.resid;
         END LOOP;

         /*B?*/
         FOR l_rec IN (SELECT a.circuitid resid
                         FROM circuit a
                        WHERE a.changetype = 0 AND a.bdeviceid = :OLD.deviceid)
         LOOP
            UPDATE res
               SET nodecodeb = NULL
             WHERE resid = l_rec.resid;
         END LOOP;
      END IF;
   END IF;

   /*????????*/
   IF (:NEW.changetype = 0)
   THEN
		BEGIN
			 SELECT vendor
			   INTO l_vendor
			   FROM devicemodel
			  WHERE devicemodelcode = :NEW.devicemodelcode;
		EXCEPTION
			WHEN OTHERS THEN
		    	NULL;
		END;

		/*????*/
		IF (:old.changetype = 0) THEN
			UPDATE res
			   SET resname = :NEW.devicename,
			       restypeid = :NEW.devicetypecode,
			       nodecodea = :NEW.nodecode,
			       nodecodeb = NULL,
			       ipaddressa = :NEW.loopaddress,
			       ipaddressb = NULL,
			       remark = :NEW.remark,
			       resmodelid = :NEW.devicemodelcode,
			       vendor = l_vendor,
			       resprop = :NEW.devicepropcode
			WHERE resid = :NEW.deviceid;

		   	IF (SQL%ROWCOUNT = 0)  THEN
		         INSERT INTO res(resid, resname, restypeid,
		                      nodecodea, nodecodeb, ipaddressa, ipaddressb,
		                      remark, resmodelid, vendor, resprop)
		          VALUES (:NEW.deviceid, :NEW.devicename, :NEW.devicetypecode,
		                  :NEW.nodecode, NULL, :NEW.loopaddress, NULL,
		                  :NEW.remark, :NEW.devicemodelcode, l_vendor, :NEW.devicepropcode);
	        END IF ;
 		/*????*/
	   ELSE
			BEGIN
		         INSERT INTO res(resid, resname, restypeid,
		                      nodecodea, nodecodeb, ipaddressa, ipaddressb,
		                      remark, resmodelid, vendor, resprop)
		          VALUES (:NEW.deviceid, :NEW.devicename, :NEW.devicetypecode,
		                  :NEW.nodecode, NULL, :NEW.loopaddress, NULL,
		                  :NEW.remark, :NEW.devicemodelcode, l_vendor, :NEW.devicepropcode);
			EXCEPTION
			 WHEN OTHERS THEN
			    UPDATE res
			       SET resname = :NEW.devicename,
			           restypeid = :NEW.devicetypecode,
			           nodecodea = :NEW.nodecode,
			           nodecodeb = NULL,
			           ipaddressa = :NEW.loopaddress,
			           ipaddressb = NULL,
			           remark = :NEW.remark,
			           resmodelid = :NEW.devicemodelcode,
			           vendor = l_vendor,
			           resprop = :NEW.devicepropcode
			     WHERE resid = :NEW.deviceid;
			END;
		END IF ;

      /*?????????IP?????*/
      IF (l_caschange = 1)
      THEN
         /*??*/
         BEGIN
            SELECT 1
              INTO l_hastable
              FROM user_tables
             WHERE table_name = 'PATH';
         EXCEPTION
            WHEN NO_DATA_FOUND
            THEN
               l_hastable := 0;
         END;

         IF (l_hastable = 1)
         THEN
            OPEN l_rescur FOR 'select a.pathid resid from path a,endpoint b
                            where a.startpointid = b.endpointid  and a.changetype = 0
                                and b.changetype = 0  and b.deviceid = :1 '
            USING :NEW.deviceid;

            LOOP
               FETCH l_rescur
                INTO l_resid;

               EXIT WHEN l_rescur%NOTFOUND;

               UPDATE res
                  SET nodecodea = :NEW.nodecode,
                      ipaddressa = :NEW.loopaddress
                WHERE resid = l_resid;
            END LOOP;

            CLOSE l_rescur;

            OPEN l_rescur FOR 'select a.pathid resid from path a,endpoint b
                            where a.endpointid = b.endpointid  and a.changetype = 0
                                and b.changetype = 0  and b.deviceid = :1 '
            USING :NEW.deviceid;

            LOOP
               FETCH l_rescur
                INTO l_resid;

               EXIT WHEN l_rescur%NOTFOUND;

               UPDATE res
                  SET nodecodeb = :NEW.nodecode,
                      ipaddressb = :NEW.loopaddress
                WHERE resid = l_resid;
            END LOOP;
         END IF;

         /*bge??*/
         BEGIN
            SELECT 1
              INTO l_hastable
              FROM user_tables
             WHERE table_name = 'BGPNEICFG';
         EXCEPTION
            WHEN NO_DATA_FOUND
            THEN
               l_hastable := 0;
         END;

         IF (l_hastable = 1)
         THEN
            OPEN l_rescur FOR 'select a.neiid resid from bgpneicfg a
                            where a.changetype = 0 and a.deviceid = :1 '
            USING :NEW.deviceid;

            LOOP
               FETCH l_rescur
                INTO l_resid;

               EXIT WHEN l_rescur%NOTFOUND;

               UPDATE res
                  SET nodecodea = :NEW.nodecode,
                      ipaddressa = :NEW.loopaddress
                WHERE resid = l_resid;
            END LOOP;

            CLOSE l_rescur;
         END IF;

         /*traceroute*/
         BEGIN
            SELECT 1
              INTO l_hastable
              FROM user_tables
             WHERE table_name = 'TRACEROUTECFG';
         EXCEPTION
            WHEN NO_DATA_FOUND
            THEN
               l_hastable := 0;
         END;

         IF (l_hastable = 1)
         THEN
            OPEN l_rescur FOR 'select a.routeid resid from traceroutecfg a
                            where a.changetype = 0 and a.deviceid = :1 '
            USING :NEW.deviceid;

            LOOP
               FETCH l_rescur
                INTO l_resid;

               EXIT WHEN l_rescur%NOTFOUND;

               UPDATE res
                  SET nodecodea = :NEW.nodecode,
                      ipaddressa = :NEW.loopaddress
                WHERE resid = l_resid;
            END LOOP;

            CLOSE l_rescur;
         END IF;

         /*tunnel*/
         BEGIN
            SELECT 1
              INTO l_hastable
              FROM user_tables
             WHERE table_name = 'MPLSTETINFO';
         EXCEPTION
            WHEN NO_DATA_FOUND
            THEN
               l_hastable := 0;
         END;

         IF (l_hastable = 1)
         THEN
            OPEN l_rescur FOR 'select a.tetid from mplstetinfo a
                            where a.changetype = 0 and a.adeviceid = :1 '
            USING :NEW.deviceid;

            LOOP
               FETCH l_rescur
                INTO l_resid;

               EXIT WHEN l_rescur%NOTFOUND;

               UPDATE res
                  SET nodecodea = :NEW.nodecode
                WHERE resid = l_resid;
            END LOOP;

            CLOSE l_rescur;
         END IF;

         /*????*/
         BEGIN
            SELECT 1
              INTO l_hastable
              FROM user_tables
             WHERE table_name = 'AREATESTPATH';
         EXCEPTION
            WHEN NO_DATA_FOUND
            THEN
               l_hastable := 0;
         END;

         IF (l_hastable = 1)
         THEN
            OPEN l_rescur FOR 'select a.citycode resid from areatestpath a
                            where a.changetype = 0 and a.startroutercode = :1 '
            USING :NEW.deviceid;

            LOOP
               FETCH l_rescur
                INTO l_resid;

               EXIT WHEN l_rescur%NOTFOUND;

               UPDATE res
                  SET nodecodea = :NEW.nodecode,
                      ipaddressa = :NEW.loopaddress
                WHERE resid = l_resid;
            END LOOP;

            CLOSE l_rescur;
         END IF;

         /*??*/
         /*A?*/
         FOR l_rec IN (SELECT a.circuitid resid
                         FROM circuit a
                        WHERE a.changetype = 0 AND a.adeviceid = :NEW.deviceid)
         LOOP
            UPDATE res
               SET nodecodea = :NEW.nodecode
             WHERE resid = l_rec.resid;
         END LOOP;

         /*B?*/
         FOR l_rec IN (SELECT a.circuitid resid
                         FROM circuit a
                        WHERE a.changetype = 0 AND a.bdeviceid = :NEW.deviceid)
         LOOP
            UPDATE res
               SET nodecodeb = :NEW.nodecode
             WHERE resid = l_rec.resid;
         END LOOP;
      END IF;
   END IF;
END;
/
