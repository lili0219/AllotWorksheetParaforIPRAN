CREATE TRIGGER TRG_DEVICE_BDEVICE
BEFORE INSERT OR UPDATE OF DEVICEPROPCODE
  ON DEVICE
FOR EACH ROW
  DECLARE
  v_prop  VARCHAR2(100);
BEGIN
  SELECT NVL(paravalue,'null') INTO v_prop FROM syspara where paraname = 'IPRANBDevProp';
  IF v_prop LIKE '%'||:NEW.devicepropcode||'%' THEN
       :NEW.ismanager := 'Y';
  END IF;
END;
/
