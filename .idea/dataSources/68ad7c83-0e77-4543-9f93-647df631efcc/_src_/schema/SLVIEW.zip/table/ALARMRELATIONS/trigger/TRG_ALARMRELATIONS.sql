CREATE TRIGGER TRG_ALARMRELATIONS
AFTER INSERT OR DELETE
  ON ALARMRELATIONS
FOR EACH ROW
  declare
    l_pipename varchar2(40) ;
    l_result pls_integer ;

begin
    -- ???????PIPE??
    select 'AL_REF_ALARMRELA_'||username into l_pipename from user_users ;

    dbms_pipe.reset_buffer ;
    -- ????
    if deleting then
        dbms_pipe.pack_message('delete') ;
    else
        dbms_pipe.pack_message('add') ;
    end if;

    -- ??????
    if deleting then
        dbms_pipe.pack_message(to_char(:old.sumalarmid));
        dbms_pipe.pack_message(to_char(:old.fatheralarmid));
    else
        dbms_pipe.pack_message(to_char(:new.sumalarmid));
        dbms_pipe.pack_message(to_char(:new.fatheralarmid));
    end if;

    -- ????
    l_result := dbms_pipe.send_message(l_pipename,0,4096000) ;

    -- ?????????PIPE
    if (l_result = 1) then
        dbms_pipe.purge(l_pipename) ;
    end if;

exception
    when others then
        null ;
end ;
/
