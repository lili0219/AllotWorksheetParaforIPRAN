CREATE TRIGGER TRG_TOAREAMATRIXMONIHIS
AFTER INSERT
  ON AREAMATRIXMONICURDISPINFO
FOR EACH ROW
  BEGIN
insert into AreaMatrixMoniHisDispInfo
(AreaCode,Score,ScoreRGBColor,ScoreCheckResult,StatTime)
values
(:new.AreaCode,:new.Score,:new.ScoreRGBColor,:new.ScoreCheckResult,:new.StatTime)
END;
/
